# -*- mode: python ; coding: utf-8 -*-
# Especificação do PyInstaller. Gera uma PASTA (dist/Prospector) com Prospector.exe:
# inicia mais rápido e dispara menos alarmes falsos de antivírus do que o modo "arquivo único".
import sys
from pathlib import Path

ROOT = Path(SPECPATH).resolve().parent                      # SPECPATH é definido pelo PyInstaller
ICON = ROOT / "packaging" / "prospector.ico"

a = Analysis(
    [str(ROOT / "packaging" / "run_prospector.py")],
    pathex=[str(ROOT / "src")],
    datas=[(str(ROOT / "src" / "prospector" / "assets"), "prospector/assets")],
    hiddenimports=[],
    excludes=["tkinter", "pytest", "numpy", "PIL"],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz, a.scripts, [],
    exclude_binaries=True,
    name="Prospector",
    console=False,                                          # sem janela preta de terminal
    icon=str(ICON) if sys.platform == "win32" else None,
    upx=False,
)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name="Prospector")
