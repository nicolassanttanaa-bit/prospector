# -*- mode: python ; coding: utf-8 -*-
# Motor Python como UM executável (exigência do Tauri para binários externos). Sem Qt: é só a API local.
import sys
from pathlib import Path

ROOT = Path(SPECPATH).resolve().parent
ICON = ROOT / "packaging" / "prospector.ico"

a = Analysis(
    [str(ROOT / "packaging" / "run_api.py")],
    pathex=[str(ROOT / "src")],
    datas=[(str(ROOT / "src" / "prospector" / "api" / "ui"), "prospector/api/ui")],   # interface do "modo navegador"
    hiddenimports=[],
    excludes=["tkinter", "pytest", "numpy", "PIL", "PySide6", "shiboken6"],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz, a.scripts, a.binaries, a.datas, [],
    name="prospector-api",
    console=True,          # precisa de console para o Tauri ler a linha PROSPECTOR_READY (o Tauri o executa sem janela)
    icon=str(ICON) if sys.platform == "win32" else None,
    upx=False,
)
