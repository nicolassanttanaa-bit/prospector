"""Ponto de entrada usado pelo PyInstaller (também serve: python packaging/run_prospector.py)."""
import multiprocessing
import sys

from prospector.main import main

if __name__ == "__main__":
    multiprocessing.freeze_support()
    sys.exit(main())
