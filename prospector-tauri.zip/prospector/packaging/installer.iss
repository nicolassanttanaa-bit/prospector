; Instalador opcional (Inno Setup, gratuito: jrsoftware.org). Rode primeiro build.bat e depois compile este arquivo.
; Se mudar a versão do programa, mude também aqui (um teste confere).
#define MyAppName "Prospector"
#define MyAppVersion "1.1.0"

[Setup]
AppId={{8F2C0B7E-3B5A-4F0C-9A3D-6E1D2B7C9A11}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
DefaultDirName={autopf}\Prospector
DefaultGroupName=Prospector
OutputDir=..\dist
OutputBaseFilename=Prospector-Setup-{#MyAppVersion}
SetupIconFile=prospector.ico
Compression=lzma2
SolidCompression=yes
PrivilegesRequired=lowest
WizardStyle=modern

[Languages]
Name: "brazilianportuguese"; MessagesFile: "compiler:Languages\BrazilianPortuguese.isl"

[Tasks]
Name: "desktopicon"; Description: "Criar atalho na area de trabalho"; Flags: unchecked

[Files]
Source: "..\dist\Prospector\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs

[Icons]
Name: "{group}\Prospector"; Filename: "{app}\Prospector.exe"
Name: "{autodesktop}\Prospector"; Filename: "{app}\Prospector.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\Prospector.exe"; Description: "Abrir o Prospector"; Flags: nowait postinstall skipifsilent
