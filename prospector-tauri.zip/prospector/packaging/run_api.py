"""Ponto de entrada do motor empacotado (sidecar do Tauri): prospector-api.exe."""
import multiprocessing
import sys

from prospector.api.cli import main

if __name__ == "__main__":
    multiprocessing.freeze_support()
    sys.exit(main())
