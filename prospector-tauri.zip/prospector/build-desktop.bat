@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build-desktop.ps1" %*
if errorlevel 1 (
  echo.
  echo A construcao falhou. Leia a mensagem acima.
  pause
  exit /b 1
)
echo.
echo Pronto! Veja o caminho do instalador acima.
pause
