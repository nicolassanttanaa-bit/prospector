# Gera o programa de Windows. Uso (no PowerShell):  .\build.ps1   (ou dê dois cliques em build.bat)
# Opção: -SkipTests para pular os testes automáticos.
param([switch]$SkipTests)
$ErrorActionPreference = "Stop"
$root = $PSScriptRoot
Set-Location -Path $root

function Run($exe, $arguments) {
    & $exe @arguments
    if ($LASTEXITCODE -ne 0) { throw "Falhou (codigo $LASTEXITCODE): $exe $arguments" }
}

$systemPython = $null
foreach ($candidate in @("python", "py")) {
    if (Get-Command $candidate -ErrorAction SilentlyContinue) { $systemPython = $candidate; break }
}
if (-not $systemPython) { throw "Python nao encontrado. Instale o Python 3.10 ou mais novo em python.org e tente de novo." }

$venv = Join-Path $root ".build-venv"
$py = Join-Path $venv "Scripts\python.exe"
if (-not (Test-Path $py)) {
    Write-Host "1/5 Criando ambiente de construcao..."
    Run $systemPython @("-m", "venv", $venv)
}
Write-Host "2/5 Instalando dependencias (pode demorar na primeira vez)..."
Run $py @("-m", "pip", "install", "--quiet", "-e", ".", "pyinstaller>=6.15", "pytest")

if (-not $SkipTests) {
    Write-Host "3/5 Rodando os testes..."
    $env:QT_QPA_PLATFORM = "offscreen"
    try { Run $py @("-m", "pytest", "-q") } finally { Remove-Item Env:QT_QPA_PLATFORM -ErrorAction SilentlyContinue }
} else {
    Write-Host "3/5 Testes ignorados (-SkipTests)."
}

Write-Host "4/5 Empacotando com PyInstaller..."
Run $py @("-m", "PyInstaller", "packaging\prospector.spec", "--noconfirm", "--clean", "--distpath", "dist", "--workpath", "build\pyinstaller")

$exe = Join-Path $root "dist\Prospector\Prospector.exe"
Write-Host "5/5 Rodando o autoteste do programa empacotado..."
$proc = Start-Process -FilePath $exe -ArgumentList "--self-test" -Wait -PassThru
$report = Join-Path ([System.IO.Path]::GetTempPath()) "prospector-selftest.txt"
if (Test-Path $report) { Get-Content $report }
if ($proc.ExitCode -ne 0) { throw "O autoteste do programa empacotado falhou (veja o relatorio acima)." }

Copy-Item (Join-Path $root "docs\MANUAL.md") (Join-Path $root "dist\Prospector\MANUAL.md") -Force
$version = (Select-String -Path (Join-Path $root "src\prospector\__init__.py") -Pattern '__version__ = "(.+)"').Matches[0].Groups[1].Value
$zip = Join-Path $root "dist\Prospector-$version-windows.zip"
if (Test-Path $zip) { Remove-Item $zip }
Compress-Archive -Path (Join-Path $root "dist\Prospector") -DestinationPath $zip
Write-Host ""
Write-Host "Pronto! Programa: dist\Prospector\Prospector.exe"
Write-Host "Para compartilhar: $zip"
