import sqlite3

import pytest

from prospector.database.db import MIGRATIONS, connect
from prospector.database.repository import CompanyRepository
from prospector.integrations.base import SourceUnavailable
from prospector.integrations.site_checker import FetchResult, SiteState
from prospector.models.company import CompanyData, SiteStatus
from prospector.services.site_service import verify_companies


class FakeChecker:
    def __init__(self, internet=True):
        self.internet = internet

    def has_internet(self):
        return self.internet

    def domain_exists(self, host):
        return False

    def fetch(self, url):
        return FetchResult(SiteState.WORKING, url, 200, "")


@pytest.fixture
def repo(tmp_path):
    return CompanyRepository(connect(tmp_path / "t.db"))


def add(repo, sid, **kw):
    return repo.upsert(CompanyData(source="t", source_id=sid, name=kw.pop("name", "Lanchonete Sabor Caseiro"), **kw))


def test_verifica_e_grava_resultado(repo):
    a = add(repo, "1")                                           # sem site -> A
    b = add(repo, "2", website="https://meusite.com.br")         # site informado -> B
    c = add(repo, "3", website="https://instagram.com/lanche")   # só Instagram -> A + rede social
    res = verify_companies(repo, FakeChecker())
    assert (res.total, res.done, res.no_site, res.has_site) == (3, 3, 2, 1)
    assert repo.get(a)["site_status"] == SiteStatus.NO_SITE.value and repo.get(a)["site_evidence"]
    assert repo.get(b)["site_url"] == "https://meusite.com.br" and repo.get(b)["site_state"] == "funcionando"
    assert repo.get(c)["instagram"] == "https://instagram.com/lanche"
    s = repo.stats()
    assert (s["nao_verificadas"], s["sem_site"], s["com_site"]) == (0, 2, 1)


def test_so_verifica_pendentes_e_nao_perde_dados_do_usuario(repo):
    a = add(repo, "1")
    repo.set_notes(a, "ligar")
    verify_companies(repo, FakeChecker())
    add(repo, "2")
    assert verify_companies(repo, FakeChecker()).total == 1
    assert repo.get(a)["notes"] == "ligar"


def test_sem_internet_nao_classifica_nada(repo):
    a = add(repo, "1")
    with pytest.raises(SourceUnavailable, match="internet"):
        verify_companies(repo, FakeChecker(internet=False))
    assert repo.get(a)["site_checked_at"] is None   # continua pendente, não vira "sem site"


def test_cancelamento(repo):
    for i in range(5):
        add(repo, str(i))
    res = verify_companies(repo, FakeChecker(), cancelled=lambda: True, max_workers=1)
    assert res.cancelled and res.done == 0


def test_migracao_de_banco_antigo(tmp_path):
    path = tmp_path / "antigo.db"
    raw = sqlite3.connect(path)
    raw.executescript(MIGRATIONS[0]); raw.execute("PRAGMA user_version = 1")
    raw.execute("INSERT INTO companies (source, source_id, name, discovered_at, updated_at) VALUES ('t','1','Velha','x','x')")
    raw.commit(); raw.close()
    repo = CompanyRepository(connect(path))
    row = repo.search()[0]
    assert row["name"] == "Velha" and "site_evidence" in row.keys()
