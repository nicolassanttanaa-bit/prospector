import ast
import json
import re
from pathlib import Path

import pytest

from prospector import __version__
from prospector.api.cli import READY_PREFIX

ROOT = Path(__file__).resolve().parent.parent
TAURI = ROOT / "desktop" / "src-tauri"


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_configuracao_do_tauri():
    conf = json.loads((TAURI / "tauri.conf.json").read_text(encoding="utf-8"))
    assert conf["version"] == __version__ and conf["productName"] == "Prospector"
    assert not conf["identifier"].endswith(".app")                       # o Tauri recusa/avisa
    frontend = (TAURI / conf["build"]["frontendDist"]).resolve()
    assert (frontend / "index.html").is_file() and (frontend / "app.js").is_file()
    assert conf["app"]["withGlobalTauri"] is True
    assert conf["bundle"]["externalBin"] == ["binaries/prospector-api"]
    for icon in conf["bundle"]["icon"]:
        assert (TAURI / icon).is_file(), icon
    assert conf["bundle"]["windows"]["nsis"] == {"languages": ["PortugueseBR"], "installMode": "currentUser"}
    csp = conf["app"]["security"]["csp"]
    assert "connect-src 'self' ipc: http://ipc.localhost http://127.0.0.1:*" in csp
    assert "unsafe-eval" not in csp and "unsafe-inline" not in csp and "object-src 'none'" in csp
    assert conf["app"]["windows"][0]["label"] == "main"


def test_permissoes_minimas():
    cap = json.loads((TAURI / "capabilities" / "default.json").read_text(encoding="utf-8"))
    assert cap["permissions"] == ["core:default"] and cap["windows"] == ["main"]   # a página não executa programas nem lê arquivos


def test_cargo_toml():
    tomllib = pytest.importorskip("tomllib")
    cargo = tomllib.loads((TAURI / "Cargo.toml").read_text(encoding="utf-8"))
    assert cargo["package"]["version"] == __version__ and cargo["package"]["edition"] == "2021"
    assert set(cargo["dependencies"]) == {"tauri", "tauri-plugin-shell"}
    assert cargo["build-dependencies"]["tauri-build"]["version"] == "2"


def test_rust_combina_com_o_motor_python():
    rs = (TAURI / "src" / "main.rs").read_text(encoding="utf-8")
    assert re.search(r'const READY_PREFIX: &str = "(.*)";', rs).group(1) == READY_PREFIX     # mesma linha de "pronto"
    assert 'sidecar("prospector-api")' in rs and "backend_info" in rs and "RunEvent::Exit" in rs and "child.kill()" in rs
    assert "tauri_plugin_shell::init()" in rs and "windows_subsystem" in rs
    for a, b in ("{}", "()", "[]"):
        assert rs.count(a) == rs.count(b), f"{a}{b} desbalanceados"


def test_motor_empacotado_e_scripts():
    for rel in ("packaging/prospector-api.spec", "packaging/run_api.py"):
        ast.parse(read(rel))
    spec = read("packaging/prospector-api.spec")
    assert 'name="prospector-api"' in spec and "console=True" in spec and "api" in spec and "COLLECT" not in spec   # arquivo único
    ps1 = read("build-desktop.ps1")
    for proibido in ("&&", "||", "??", "Activate.ps1"):
        assert proibido not in ps1, proibido
    assert "$LASTEXITCODE" in ps1 and "--self-test" in ps1 and "rustc -Vv" in ps1 and "$triple" in ps1     # arquitetura detectada, não fixa
    bat = (ROOT / "build-desktop.bat").read_bytes().decode("ascii")
    assert "-ExecutionPolicy Bypass" in bat and "build-desktop.ps1" in bat


def test_sidecar_e_tauri_combinam_no_nome_do_binario():
    ps1 = read("build-desktop.ps1")
    assert 'prospector-api-$triple.exe' in ps1 and "prospector-api.exe" in ps1
    assert 'name="prospector-api"' in read("packaging/prospector-api.spec")
