import importlib.util
import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent


def _has_webengine() -> bool:
    try:
        return importlib.util.find_spec("PySide6.QtWebEngineWidgets") is not None
    except (ImportError, ValueError):
        return False


@pytest.mark.skipif(not _has_webengine() or os.environ.get("PROSPECTOR_SKIP_BROWSER_TEST"),
                    reason="precisa do QtWebEngine (pacote PySide6 completo)")
def test_interface_no_navegador_de_ponta_a_ponta():
    proc = subprocess.run([sys.executable, str(ROOT / "tests" / "ui_browser_check.py")], capture_output=True,
                          text=True, timeout=240, cwd=ROOT)
    lines = [ln for ln in proc.stdout.splitlines() if ln.startswith("{")]
    assert lines, f"sem resultado do navegador:\n{proc.stdout[-1500:]}\n{proc.stderr[-1500:]}"
    result = json.loads(lines[-1])
    assert result["ok"], "\n".join(result["failures"])
