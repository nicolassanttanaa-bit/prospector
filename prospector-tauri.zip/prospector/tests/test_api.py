import http.client
import json
import subprocess
import sys
import threading
import time

import pytest

from prospector.api.server import ApiServer
from prospector.integrations.site_checker import FetchResult, SiteState
from prospector.models.company import CompanyData

GATE = threading.Event()


class FakeSource:
    name, label = "osm", "Fake"

    def search(self, query, progress, cancelled):
        progress(10, "buscando…")
        if query.city == "Lenta":                      # simula uma pesquisa demorada e cancelável
            while not GATE.is_set() and not cancelled():
                time.sleep(0.01)
        rows = [("Ragazzo", None), ("Ragazzo", None), ("Ragazzo - Centro", None),
                ("Padaria Sol", None), ("Bar do Zé", "https://bardoze.com.br")]
        for i, (name, site) in enumerate(rows):
            yield CompanyData(source="osm", source_id=f"{query.city}/{i}", name=name, city=query.city,
                              state=query.state, phone="(19) 3000-000%d" % i if i < 4 else None, website=site)


class FakeChecker:
    def has_internet(self): return True
    def domain_exists(self, host): return False
    def fetch(self, url): return FetchResult(SiteState.WORKING, url, 200, "")
    def close(self): pass


@pytest.fixture
def api(tmp_path):
    GATE.clear()
    opened, revealed = [], []
    srv = ApiServer(tmp_path / "data", token="tok", export_dir=tmp_path / "exports",
                    source_factory=lambda prefs: [FakeSource()], checker_factory=FakeChecker,
                    opener=opened.append, revealer=revealed.append)
    srv.opened, srv.revealed = opened, revealed
    srv.start_background()
    yield srv
    GATE.set()
    srv.shutdown()


def call(srv, method, path, body=None, token="tok", headers=None, raw=None):
    conn = http.client.HTTPConnection("127.0.0.1", srv.port, timeout=10)
    h = dict(headers or {})
    if token:
        h["Authorization"] = f"Bearer {token}"
    data = raw if raw is not None else (json.dumps(body).encode() if body is not None else None)
    if data is not None:
        h["Content-Type"] = "application/json"
    conn.request(method, path, body=data, headers=h)
    r = conn.getresponse()
    text = r.read().decode("utf-8")
    conn.close()
    try:
        body_out = json.loads(text) if text else None
    except ValueError:
        body_out = text                                  # arquivos da interface (HTML, JS, CSS)
    return r.status, body_out, dict(r.getheaders())


def wait_job(srv, timeout=10):
    end = time.time() + timeout
    while time.time() < end:
        _, job, _ = call(srv, "GET", "/api/jobs/current")
        if job["status"] != "running":
            return job
        time.sleep(0.05)
    raise AssertionError("a tarefa não terminou")


def search(srv, city="Campinas", **kw):
    st, body, _ = call(srv, "POST", "/api/searches", {"city": city, "state": "SP", "category": "lanchonete", **kw})
    assert st == 202, body
    return body["search_id"]


# ---------- segurança ----------
def test_token_host_e_origem(api):
    assert call(api, "GET", "/api/health", token=None)[0] == 401
    assert call(api, "GET", "/api/health", token="errado")[0] == 401
    assert call(api, "GET", "/api/health")[0:2] == (200, {"ok": True, "version": call(api, "GET", "/api/health")[1]["version"]})
    assert call(api, "GET", "/api/health", headers={"Host": "evil.com"})[0] == 403          # DNS rebinding
    assert call(api, "GET", "/api/health", headers={"Origin": "https://evil.com"})[0] == 403
    st, _, h = call(api, "GET", "/api/health", headers={"Origin": "http://tauri.localhost"})
    assert st == 200 and h["Access-Control-Allow-Origin"] == "http://tauri.localhost"
    st, _, h = call(api, "OPTIONS", "/api/searches", token=None, headers={"Origin": "http://tauri.localhost"})
    assert st == 204 and h["Access-Control-Allow-Private-Network"] == "true" and "Authorization" in h["Access-Control-Allow-Headers"]
    assert call(api, "OPTIONS", "/api/searches", token=None, headers={"Origin": "https://evil.com"})[0] == 403


def test_corpo_invalido_e_grande(api):
    assert call(api, "POST", "/api/searches", raw=b"{nao json")[0] == 400
    assert call(api, "POST", "/api/searches", raw=b"[1,2]")[0] == 400
    assert call(api, "POST", "/api/searches", raw=b"x" * 1_000_001)[0] == 413
    st, body, _ = call(api, "GET", "/api/nao-existe")
    assert st == 404 and "error" in body
    assert call(api, "GET", "/index.html")[0] == 404                        # interface só no modo navegador


def test_o_motor_nao_importa_qt():
    code = "import sys, prospector.api.server; bad=[m for m in sys.modules if m.startswith('PySide6')]; sys.exit(1 if bad else 0)"
    assert subprocess.run([sys.executable, "-c", code], env={"PYTHONPATH": "src", "PATH": ""}, cwd=".").returncode == 0


# ---------- configuração ----------
def test_configuracao(api):
    st, cfg, _ = call(api, "GET", "/api/config")
    assert st == 200 and cfg["use_osm"] and "Lanchonetes" in cfg["categories"] and len(cfg["states"]) == 27
    assert cfg["receita_missing"]                                              # pasta ainda não configurada
    st, cfg, _ = call(api, "PUT", "/api/config", {"use_osm": False, "receita_dir": ' "C:\\dados" '})
    assert cfg["use_osm"] is False and cfg["receita_dir"] == "C:\\dados"
    assert call(api, "PUT", "/api/config", {"use_osm": "sim"})[0] == 400
    assert call(api, "PUT", "/api/config", {"receita_dir": "x\x00"})[0] == 400
    assert call(api, "GET", "/api/config")[1]["use_osm"] is False             # persistiu


# ---------- pesquisa: cada uma com os seus resultados, sem repetir lojas ----------
def test_fluxo_completo_sem_repetir_e_separado_por_cidade(api):
    for bad, msg in (({"city": "Campinas", "state": "", "category": "lanchonete"}, "estado"),
                     ({"city": "", "state": "SP", "category": "lanchonete"}, "cidade"),
                     ({"city": "Campinas", "state": "SP", "category": "xyzabc"}, "Categoria"),
                     ({"city": "Campinas", "state": "SP", "category": "lanchonete", "radius_km": "dez"}, "Raio"),
                     ({"city": "C" * 200, "state": "SP", "category": "lanchonete"}, "longa")):
        st, body, _ = call(api, "POST", "/api/searches", bad)
        assert st == 400 and msg in body["error"], body
    sid1 = search(api)
    job = wait_job(api)
    assert job["status"] == "done" and job["search_id"] == sid1 and job["percent"] == 100
    sid2 = search(api, city="Sorocaba")
    wait_job(api)
    st, data, _ = call(api, "GET", f"/api/searches/{sid1}")
    names = {c["name"]: c for c in data["companies"]}
    assert sorted(names) == ["Bar do Zé", "Padaria Sol", "Ragazzo"]              # 3 Ragazzo viraram 1
    assert names["Ragazzo"]["units"] == 3 and names["Padaria Sol"]["units"] == 1
    assert data["summary"] == {"total": 3, "sem_site": 2, "com_site": 1, "inconclusivas": 0}
    assert names["Bar do Zé"]["dots"] == {"site": "yes", "phone": "no", "instagram": "no", "facebook": "no"}
    assert names["Padaria Sol"]["dots"]["site"] == "no" and names["Padaria Sol"]["dots"]["phone"] == "yes"
    st, data2, _ = call(api, "GET", f"/api/searches/{sid2}")
    assert {c["city"] for c in data2["companies"]} == {"Sorocaba"}               # só a cidade pesquisada
    assert {c["city"] for c in data["companies"]} == {"Campinas"}
    lst = call(api, "GET", "/api/searches")[1]
    assert [s["id"] for s in lst] == [sid2, sid1] and lst[0]["status"] == "done" and lst[0]["found"] == 3


def test_uma_tarefa_por_vez_e_cancelamento(api):
    sid = search(api, city="Lenta")
    st, body, _ = call(api, "POST", "/api/searches", {"city": "Campinas", "state": "SP", "category": "lanchonete"})
    assert st == 409
    assert call(api, "DELETE", f"/api/searches/{sid}")[0] == 409               # não exclui pesquisa em andamento
    assert call(api, "POST", "/api/jobs/cancel", {})[0] == 200
    job = wait_job(api)
    assert job["status"] == "cancelled"
    assert call(api, "GET", f"/api/searches/{sid}")[1]["search"]["status"] == "cancelled"
    assert call(api, "DELETE", f"/api/searches/{sid}")[0] == 200 and call(api, "GET", f"/api/searches/{sid}")[0] == 404


def test_falha_de_fonte_vira_aviso(api, tmp_path):
    class Broken:
        name, label = "x", "Fonte X"
        def search(self, q, p, c):
            from prospector.integrations.base import SourceUnavailable
            raise SourceUnavailable("sem rede")
            yield
    api.source_factory = lambda prefs: [Broken()]
    search(api)
    job = wait_job(api)
    assert job["status"] == "done" and any("sem rede" in w for w in job["warnings"])


def test_verificacao_manual_de_uma_pesquisa(api):
    sid = search(api, auto_verify=False)
    wait_job(api)
    assert call(api, "GET", f"/api/searches/{sid}")[1]["summary"]["inconclusivas"] == 3   # ainda não verificadas
    assert call(api, "POST", f"/api/searches/{sid}/verify", {})[0] == 202
    wait_job(api)
    assert call(api, "GET", f"/api/searches/{sid}")[1]["summary"]["inconclusivas"] == 0
    assert call(api, "POST", "/api/searches/999/verify", {})[0] == 404


# ---------- empresa ----------
def test_detalhes_edicao_e_contatos(api):
    sid = search(api)
    wait_job(api)
    cid = next(c["id"] for c in call(api, "GET", f"/api/searches/{sid}")[1]["companies"] if c["name"] == "Padaria Sol")
    st, d, _ = call(api, "GET", f"/api/companies/{cid}")
    assert st == 200 and d["site"]["status"] == "sem_site_identificado" and d["site"]["evidence"]
    assert d["links"]["maps"].startswith("https://www.google.com/maps/search/") and d["units_list"][0]["source"] == "OpenStreetMap"
    st, d, _ = call(api, "PATCH", f"/api/companies/{cid}", {"favorite": True, "lead_status": "interessado", "notes": "  ligar  "})
    assert (d["favorite"], d["lead_status"], d["notes"]) == (True, "interessado", "ligar")
    st, d, _ = call(api, "PATCH", f"/api/companies/{cid}", {"links": {"instagram": "@padariasol", "website": "padariasol.com.br"}})
    assert d["instagram"] == "https://instagram.com/padariasol" and d["dots"]["site"] == "yes" and d["links_confirmed"]
    for bad in ({"lead_status": "xx"}, {"notes": "n" * 5001}, {"site_status": "x"}, {"favorite": "sim"},
                {"links": {"website": "javascript:alert(1)"}}, {"links": "x"}):
        assert call(api, "PATCH", f"/api/companies/{cid}", bad)[0] == 400, bad
    st, d, _ = call(api, "POST", f"/api/companies/{cid}/contacts", {"channel": "WhatsApp", "note": "pediu orçamento"})
    assert d["contacts"][0]["channel"] == "WhatsApp" and d["last_contact_at"]
    assert call(api, "GET", "/api/companies/99999")[0] == 404
    assert call(api, "PATCH", "/api/companies/99999", {"favorite": True})[0] == 404


# ---------- exportar e abrir ----------
def test_exportacao_e_abrir_links(api, tmp_path):
    sid = search(api)
    wait_job(api)
    st, out, _ = call(api, "POST", f"/api/searches/{sid}/export", {"format": "csv_semicolon"})
    assert st == 200 and out["count"] == 3 and out["path"].startswith(str(tmp_path / "exports"))
    import csv
    with open(out["path"], encoding="utf-8-sig", newline="") as fh:
        rows = list(csv.DictReader(fh, delimiter=";"))
    assert sorted(r["Nome"] for r in rows) == ["Bar do Zé", "Padaria Sol", "Ragazzo"]       # sem repetir
    assert next(r for r in rows if r["Nome"] == "Ragazzo")["Unidades (lojas)"] == "3"
    assert call(api, "POST", f"/api/searches/{sid}/export", {"format": "pdf"})[0] == 400
    assert call(api, "POST", "/api/searches/999/export", {"format": "json"})[0] == 404
    assert call(api, "POST", "/api/open", {"reveal": out["path"]})[0] == 200 and api.revealed
    assert call(api, "POST", "/api/open", {"reveal": str(tmp_path / "data" / "prospector.db")})[0] == 400
    assert call(api, "POST", "/api/open", {"reveal": "../../etc/passwd"})[0] == 400
    assert call(api, "POST", "/api/open", {"url": "https://exemplo.com.br"})[0] == 200
    assert api.opened == ["https://exemplo.com.br"]
    for bad in ("javascript:alert(1)", "file:///etc/passwd", "", 5):
        assert call(api, "POST", "/api/open", {"url": bad})[0] == 400
    assert call(api, "POST", "/api/open", {})[0] == 400


def test_encerra_sozinho_sem_atividade(tmp_path):
    srv = ApiServer(tmp_path / "d", token="t", idle_timeout=0.2)
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    t.join(timeout=8)
    assert not t.is_alive()


# ---------- modo navegador: arquivos da interface ----------
def test_modo_navegador_serve_a_interface_sem_vazar_arquivos(tmp_path):
    srv = ApiServer(tmp_path / "d", token="tok", serve_ui=True)
    srv.start_background()
    try:
        st, _, h = call(srv, "GET", "/", token=None)
        assert st == 200 and h["Content-Type"].startswith("text/html")
        assert call(srv, "GET", "/app.js", token=None)[2]["Content-Type"].startswith(("text/javascript", "application/javascript"))
        assert call(srv, "GET", "/styles.css", token=None)[2]["Content-Type"].startswith("text/css")
        for evil in ("/../../../pyproject.toml", "/%2e%2e/%2e%2e/pyproject.toml", "/..%2f..%2fpyproject.toml",
                     "/api/../../pyproject.toml", "/nao-existe.js", "/__init__.py"):
            assert call(srv, "GET", evil, token=None)[0] in (401, 404), evil          # sempre negado, nunca um arquivo
        assert call(srv, "POST", "/", {}, token=None)[0] == 404                  # só GET
        assert call(srv, "GET", "/api/config", token=None)[0] == 401              # a API continua protegida
    finally:
        srv.shutdown()


def test_arquivos_da_interface_e_regras_de_seguranca():
    from pathlib import Path
    ui = Path("src/prospector/api/ui")
    html = (ui / "index.html").read_text(encoding="utf-8")
    assert "Content-Security-Policy" in html and "script-src 'self'" in html and "object-src 'none'" in html
    assert "unsafe-inline" not in html and "unsafe-eval" not in html and "http://" not in html.replace("http://127.0.0.1:*", "")
    for js in ui.glob("*.js"):
        code = js.read_text(encoding="utf-8")
        for perigoso in ("innerHTML", "outerHTML", "insertAdjacentHTML", "document.write", "eval(", "new Function"):
            assert perigoso not in code, f"{js.name} usa {perigoso}"
    from prospector.models.company import LeadStatus
    util = (ui / "util.js").read_text(encoding="utf-8")
    assert all(f"'{s.value}'" in util for s in LeadStatus)                        # opções da interface = status do sistema
    from prospector.api.serializers import LEAD_LABELS
    assert all(label in util for label in LEAD_LABELS.values())                  # mesmos rótulos


def test_funcoes_da_interface_em_node():
    import shutil
    import subprocess
    node = shutil.which("node")
    if not node:
        pytest.skip("Node não instalado")
    r = subprocess.run([node, "tests/test_ui_util.mjs"], capture_output=True, text=True, timeout=60)
    assert r.returncode == 0 and "ok" in r.stdout, r.stdout + r.stderr
