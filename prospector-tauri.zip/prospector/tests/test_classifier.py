from prospector.integrations.site_checker import FetchResult, SiteState
from prospector.models.company import SiteStatus
from prospector.services.site_classifier import (Subject, candidate_domains, classify, classify_url,
                                                 distinctive_tokens)


class FakeChecker:
    def __init__(self, existing=(), pages=None, temp=False):
        self.existing, self.pages, self.temp, self.fetched = set(existing), pages or {}, temp, []

    def domain_exists(self, host):
        return None if self.temp else host in self.existing

    def fetch(self, url):
        self.fetched.append(url)
        host = url.split("://")[1].split("/")[0]
        if url in self.pages:
            return self.pages[url]
        return self.pages.get(host, FetchResult(SiteState.INVALID_DOMAIN, url))


def ok(text="", url="https://x"):
    return FetchResult(SiteState.WORKING, url, 200, text)


S = Subject("Lanchonete Sabor Caseiro Ltda", city="Campinas", phone="(19) 3456-7890")


def test_candidatos_de_dominio():
    c = candidate_domains("Lanchonete Sabor Caseiro Ltda")
    assert "saborcaseiro.com.br" in c and len(c) <= 6 and len(set(c)) == len(c)
    assert candidate_domains("Lanche do Zé") == []   # nome curto/genérico demais
    assert distinctive_tokens("Pizzaria do João ME") == ["JOAO"]


def test_classify_url():
    assert classify_url("instagram.com/lanche")[0] == "instagram"
    assert classify_url("https://www.facebook.com/x")[0] == "facebook"
    assert classify_url("https://linktr.ee/x")[0] == "aggregator"
    assert classify_url("wa.me/5519999999999")[0] == "aggregator"
    assert classify_url("https://meusite.com.br")[0] == "site"
    assert classify_url("sem ponto")[0] == "invalid"


def test_site_informado_funcionando_e_B():
    c = classify(Subject("X", website="meusite.com.br"), FakeChecker(pages={"https://meusite.com.br": ok()}))
    assert c.status == SiteStatus.HAS_SITE and c.confidence == 0.95


def test_site_informado_fora_do_ar_continua_B_com_confianca_menor():
    fr = FetchResult(SiteState.UNAVAILABLE, "https://m.com")
    c = classify(Subject("X", website="https://m.com"), FakeChecker(pages={"https://m.com": fr}))
    assert c.status == SiteStatus.HAS_SITE and c.confidence < 0.7


def test_dominio_informado_inexistente_e_inconclusivo():
    c = classify(Subject("X", website="https://morto.com.br"), FakeChecker())
    assert c.status == SiteStatus.INCONCLUSIVE


def test_so_instagram_e_sem_site_e_extrai_rede_social():
    c = classify(Subject("Lanchonete Sabor Caseiro", website="https://instagram.com/sabor"), FakeChecker())
    assert c.status == SiteStatus.NO_SITE and c.instagram == "https://instagram.com/sabor"
    assert c.confidence > 0.55 and any("rede social" in n.lower() for n in c.notes)


def test_dominio_adivinhado_com_nome_e_cidade_e_B_estimado():
    page = ok("Sabor Caseiro - a melhor lanchonete de Campinas", "https://saborcaseiro.com.br")
    c = classify(S, FakeChecker(existing={"saborcaseiro.com.br"}, pages={"https://saborcaseiro.com.br": page}))
    assert c.status == SiteStatus.HAS_SITE and c.confidence == 0.75 and "Estimado" in c.notes[0]


def test_dominio_com_so_o_nome_e_inconclusivo():
    page = ok("Sabor Caseiro - receitas de família", "https://saborcaseiro.com.br")
    c = classify(S, FakeChecker(existing={"saborcaseiro.com.br"}, pages={"https://saborcaseiro.com.br": page}))
    assert c.status == SiteStatus.INCONCLUSIVE and c.site_url == "https://saborcaseiro.com.br"


def test_dominio_estacionado_e_ignorado():
    page = ok("sabor caseiro campinas — este domínio está à venda", "https://saborcaseiro.com.br")
    c = classify(S, FakeChecker(existing={"saborcaseiro.com.br"}, pages={"https://saborcaseiro.com.br": page}))
    assert c.status == SiteStatus.NO_SITE


def test_nenhum_dominio_e_A_com_confianca_moderada():
    c = classify(S, FakeChecker())
    assert c.status == SiteStatus.NO_SITE and c.confidence == 0.55
    assert "não prova" in c.notes[-1]


def test_nome_generico_nao_testa_nada():
    fc = FakeChecker()
    c = classify(Subject("Lanche do Zé"), fc)
    assert c.status == SiteStatus.NO_SITE and c.confidence == 0.4 and fc.fetched == []


def test_falha_temporaria_de_dns_e_inconclusivo():
    assert classify(S, FakeChecker(temp=True)).status == SiteStatus.INCONCLUSIVE
