"""Teste de ponta a ponta da interface num navegador real (Chromium do Qt). Roda em processo separado:
python tests/ui_browser_check.py  ->  imprime um JSON {ok, failures, info}."""
import json
import os
import pathlib
import sys
import tempfile
import time

os.environ["QT_QPA_PLATFORM"] = "offscreen"
os.environ.setdefault("QTWEBENGINE_CHROMIUM_FLAGS", "--no-sandbox --disable-gpu")
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent / "src"))

from PySide6.QtCore import QEventLoop, QTimer, QUrl
from PySide6.QtWebEngineCore import QWebEnginePage
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWidgets import QApplication

from prospector.api.server import ApiServer
from prospector.integrations.site_checker import FetchResult, SiteState
from prospector.models.company import CompanyData

XSS_NAME = '<img src=x onerror="window.__xss=1">Loja Maliciosa'


class FakeSource:
    name, label = "osm", "Fake"

    def search(self, query, progress, cancelled):
        progress(20, "buscando…")
        if query.city == "Sorocaba":
            rows = [("Loja Sorocaba", None)]
        else:
            rows = [("Ragazzo", None), ("Ragazzo", None), ("Ragazzo - Centro", None), ("Padaria Sol", None),
                    ("Bar do Zé", "https://bardoze.com.br"), (XSS_NAME, None)]
        for i, (name, site) in enumerate(rows):
            yield CompanyData(source="osm", source_id=f"{query.city}/{i}", name=name, city=query.city, state=query.state,
                              phone="(19) 3000-000%d" % i if i != 3 else None, website=site)


class FakeChecker:
    def has_internet(self): return True
    def domain_exists(self, host): return False
    def fetch(self, url): return FetchResult(SiteState.WORKING, url, 200, "")
    def close(self): pass


failures, info = [], {}
last = {"code": ""}


def check(name, cond, detail=""):
    if not cond:
        failures.append(f"{name} {detail}".strip())


def main() -> int:
    tmp = pathlib.Path(tempfile.mkdtemp())
    srv = ApiServer(tmp / "data", token="tok", serve_ui=True, export_dir=tmp / "exp",
                    source_factory=lambda prefs: [FakeSource()], checker_factory=FakeChecker)
    srv.start_background()
    app = QApplication([])

    class Page(QWebEnginePage):
        def javaScriptConsoleMessage(self, level, msg, line, src):
            if level.value >= 2:
                failures.append(f"erro de JavaScript: {msg} (em {src.split('/')[-1] or 'script do teste'}:{line}; trecho: {last['code'][:110]})")

    view = QWebEngineView(); page = Page(view); view.setPage(page); view.resize(1360, 860)

    def js(code, timeout=5000):
        last['code'] = code
        out, loop = {}, QEventLoop()
        page.runJavaScript(code, lambda v: (out.update(v=v), loop.quit()))
        QTimer.singleShot(timeout, loop.quit); loop.exec()
        return out.get("v")

    def jsj(code):                      # listas/objetos: o Chromium só devolve valores simples, então vai como JSON
        raw = js(f"JSON.stringify({code})")
        return json.loads(raw) if raw else None

    def pause(ms):
        loop = QEventLoop(); QTimer.singleShot(ms, loop.quit); loop.exec()

    def wait_for(cond_js, what, timeout=20):
        end = time.time() + timeout
        while time.time() < end:
            if js(f"!!({cond_js})"):
                return True
            pause(150)
        failures.append(f"tempo esgotado esperando: {what}")
        return False

    def do_search(city, state="SP", category="lanchonete"):
        js(f"document.getElementById('f-city').value={json.dumps(city)};document.getElementById('f-state').value={json.dumps(state)};"
           f"document.getElementById('f-category').value={json.dumps(category)};document.getElementById('search-form').requestSubmit()")
        wait_for("document.getElementById('res-title').textContent.includes(" + json.dumps(city) + ")", f"título da pesquisa {city}")
        wait_for("document.getElementById('job-box').hidden && !document.getElementById('btn-search').disabled", f"fim da pesquisa {city}")
        pause(500)

    names = lambda: jsj("[...document.querySelectorAll('.card-name')].map(e=>e.textContent)")  # noqa: E731
    view.load(QUrl(f"http://127.0.0.1:{srv.port}/#token=tok")); view.show()
    wait_for("document.getElementById('sources-line')?.textContent.includes('OpenStreetMap')", "interface carregada")
    js("document.getElementById('f-state').options.length")
    check("estado vazio inicial", "Pesquise uma cidade" in (js("document.getElementById('empty').textContent") or ""))
    check("27 estados + UF", js("document.getElementById('f-state').options.length") == 28)
    check("categorias na lista", (js("document.getElementById('category-list').options.length") or 0) >= 10)

    # 1) pesquisa Campinas: lojas não se repetem; cada cartão tem as 4 bolinhas
    do_search("Campinas")
    n = names()
    info["campinas"] = n
    check("sem repetição (3 Ragazzo = 1)", sorted(n) == sorted(["Ragazzo", "Padaria Sol", "Bar do Zé", XSS_NAME]), str(n))
    check("selo de unidades", jsj("[...document.querySelectorAll('.badge')].map(e=>e.textContent)") == ["3 unidades"])
    check("título", js("document.getElementById('res-title').textContent") == "Lanchonetes em Campinas, SP")
    check("4 bolinhas por cartão", js("[...document.querySelectorAll('.card')].every(c=>c.querySelectorAll('.dot').length===4)"))
    check("botão ver mais em cada cartão", js("document.querySelectorAll('.card .more').length") == 4)
    check("bolinha verde do site (Bar do Zé)", js("[...document.querySelectorAll('.card')].find(c=>c.textContent.includes('Bar do Z')).querySelector('.dot').className") == "dot yes")
    check("bolinha vermelha do site (Padaria Sol)", js("[...document.querySelectorAll('.card')].find(c=>c.textContent.includes('Padaria')).querySelector('.dot').className") == "dot no")
    check("telefone vermelho quando não há (Padaria Sol)", js("[...document.querySelectorAll('.card')].find(c=>c.textContent.includes('Padaria')).querySelectorAll('.dot')[1].className") == "dot no")
    check("sem filtro com/sem site na tela", js("!document.querySelector('select option[value=possui_site]') && !document.body.innerText.includes('Empresas com site')"))
    # segurança: nome malicioso vira texto, nunca HTML
    check("XSS: nome é texto", js("!document.querySelector('.card img') && window.__xss === undefined"))
    check("XSS: texto literal visível", "<img" in (js("document.body.innerText") or ""))
    check("nenhum 'null' solto", js("!/\\bnull\\b/.test(document.body.innerText)"))

    # 2) outra cidade: só a cidade pesquisada; Campinas continua separada
    do_search("Sorocaba")
    check("Sorocaba mostra só Sorocaba", names() == ["Loja Sorocaba"], str(names()))
    check("duas pesquisas recentes", js("document.querySelectorAll('.recent-item').length") == 2)
    js("[...document.querySelectorAll('.recent-open')].find(b=>b.textContent.includes('Campinas')).click()"); pause(1200)
    check("voltar a Campinas não mistura", len(names() or []) == 4, str(names()))

    # 3) "ver mais": detalhes, edição e contato
    js("[...document.querySelectorAll('.card')].find(c=>c.textContent.includes('Padaria')).querySelector('.more').click()")
    wait_for("!document.getElementById('drawer').hidden && document.getElementById('d-notes')", "painel de detalhes")
    drawer = js("document.getElementById('drawer').innerText") or ""
    check("detalhes: seções", all(t in drawer for t in ("PRESENÇA ONLINE", "SITUAÇÃO DO SITE", "GESTÃO COMERCIAL")))
    check("detalhes: aviso de limite", "não prova" in drawer)
    check("detalhes: sem 'null'", "null" not in drawer)
    js("document.getElementById('d-notes').value='ligar na segunda';document.getElementById('d-fav').checked=true;"
       "document.getElementById('d-lead').value='interessado';"
       "[...document.querySelectorAll('.save-bar .btn.primary')][0].click()")
    wait_for("document.querySelector('.card .fav')", "estrela na lista após salvar")
    check("toast de salvo", "salvas" in (js("document.getElementById('toasts').textContent") or ""))
    js("document.getElementById('d-cnote').value='pediu orçamento';"
       "[...document.querySelectorAll('.drawer .btn')].find(b=>b.textContent.includes('Registrar contato')).click()")
    wait_for("document.querySelector('.hist li')", "histórico de contato")
    check("contato no histórico", "pediu orçamento" in (js("document.querySelector('.hist').textContent") or ""))
    js("document.getElementById('d-ig').value='@padariasol';[...document.querySelectorAll('.save-bar .btn.primary')][0].click()")
    wait_for("document.querySelectorAll('.card')[0] && [...document.querySelectorAll('.card')].find(c=>c.textContent.includes('Padaria')).querySelectorAll('.dot')[2].className==='dot yes'", "Instagram verde após salvar")
    js("document.getElementById('d-site').value='javascript:alert(1)';[...document.querySelectorAll('.save-bar .btn.primary')][0].click()")
    wait_for("!document.querySelector('.drawer .form-error').hidden", "erro de link inválido")
    js("document.getElementById('drawer-close').click()")

    # 4) erro de formulário vindo do servidor, configurações e exportação
    js("document.getElementById('f-state').value='';document.getElementById('search-form').dispatchEvent(new Event('submit',{cancelable:true}))")
    wait_for("!document.getElementById('form-error').hidden", "erro do formulário")
    check("mensagem pede o estado", "estado" in (js("document.getElementById('form-error').textContent") or ""))
    js("document.getElementById('btn-settings').click()")
    wait_for("!document.getElementById('modal').hidden", "janela de configurações")
    check("configurações: Receita indisponível", "Receita indisponível" in (js("document.getElementById('modal').innerText") or ""))
    js("document.getElementById('modal').click()")
    js("document.getElementById('btn-export').click()"); pause(200)
    check("menu de exportação", js("document.querySelectorAll('#export-menu button').length") == 4 and js("!document.getElementById('export-menu').hidden"))
    js("[...document.querySelectorAll('#export-menu button')][1].click()")
    wait_for("document.getElementById('toasts').textContent.includes('exportad')", "exportação")
    exported = list((tmp / "exp").glob("*.csv"))
    check("arquivo exportado só com a pesquisa atual", len(exported) == 1 and "Loja Sorocaba" not in exported[0].read_text(encoding="utf-8-sig"))

    view.grab().save(os.environ.get("UI_SHOT", "/tmp/ui_e2e.png"))
    srv.shutdown()
    print(json.dumps({"ok": not failures, "failures": failures, "info": info}, ensure_ascii=False))
    return 0 if not failures else 1


if __name__ == "__main__":
    code = main()
    sys.stdout.flush()
    os._exit(code)            # encerra sem passar pela destruição do Chromium (evita ruído no fim)
