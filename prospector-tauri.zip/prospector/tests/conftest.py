"""Descarta telas (widgets) criadas nos testes de forma segura.
Sem isso, o PySide6 pode travar ao encerrar o processo quando widgets sem janela-mãe são destruídos
pelo coletor de lixo do Python depois que a aplicação Qt já foi finalizada."""
import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest


@pytest.fixture(autouse=True)
def _dispose_qt_widgets(monkeypatch):
    from PySide6.QtCore import QCoreApplication, QEvent
    from prospector.interface.companies_page import CompaniesPage
    from prospector.interface.company_dialog import CompanyDialog
    from prospector.interface.search_page import SearchPage

    created = []
    for cls in (CompaniesPage, CompanyDialog, SearchPage):
        def make(orig):
            def init(self, *args, **kwargs):
                orig(self, *args, **kwargs)
                created.append(self)          # mantém referência até o fim do teste
            return init
        monkeypatch.setattr(cls, "__init__", make(cls.__init__))
    yield
    from shiboken6 import isValid
    for widget in created:
        if isValid(widget):               # telas filhas de outra janela já podem ter sido apagadas
            widget.deleteLater()
    created.clear()
    QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
    QCoreApplication.processEvents()
