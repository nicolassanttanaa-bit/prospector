import ast
import re
from pathlib import Path

import pytest

from prospector import __version__
from prospector.resources import asset
from prospector.selftest import run_self_test

ROOT = Path(__file__).resolve().parent.parent


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_versao_unica_em_todos_os_lugares():
    assert re.search(r'^version = "(.+)"', read("pyproject.toml"), re.M).group(1) == __version__
    assert f'#define MyAppVersion "{__version__}"' in read("packaging/installer.iss")
    assert f"Prospector_{__version__}_x64-setup.exe" in read("docs/MANUAL.md")        # nome que o Tauri/NSIS gera


def test_icones_sao_validos():
    assert asset("icon.png").read_bytes().startswith(b"\x89PNG")
    ico = (ROOT / "packaging" / "prospector.ico").read_bytes()
    assert ico[:4] == b"\x00\x00\x01\x00" and int.from_bytes(ico[4:6], "little") >= 4   # várias resoluções


def test_dependencias_e_dados_do_pacote():
    toml = read("pyproject.toml")
    assert "PySide6-Essentials" in toml and "pyinstaller>=6.15" in toml and '"api/ui/*"' in toml


def test_spec_e_ponto_de_entrada_sao_python_valido():
    for rel in ("packaging/prospector.spec", "packaging/run_prospector.py"):
        ast.parse(read(rel))
    spec = read("packaging/prospector.spec")
    assert "console=False" in spec and "prospector/assets" in spec and "onefile" not in spec


def test_build_ps1_roda_no_powershell_antigo_do_usuario():
    ps1 = read("build.ps1")
    for proibido in ("&&", "||", "??", "Activate.ps1"):          # PowerShell 5.1: sem esses recursos; e a ativação é bloqueada
        assert proibido not in ps1, proibido
    assert "$LASTEXITCODE" in ps1 and "--self-test" in ps1 and "Compress-Archive" in ps1


def test_build_bat_ignora_politica_de_execucao_e_e_ascii():
    bat = (ROOT / "build.bat").read_bytes().decode("ascii")      # acentos em .bat viram lixo no Windows
    assert "-ExecutionPolicy Bypass" in bat and "build.ps1" in bat


def test_autoteste_passa_e_gera_relatorio(tmp_path):
    report = tmp_path / "rel.txt"
    assert run_self_test(report) == 0
    text = report.read_text(encoding="utf-8")
    assert "RESULTADO: tudo certo" in text and text.count("OK ") == 4 and "FALHOU" not in text


def test_autoteste_detecta_falha(tmp_path, monkeypatch):
    import httpx

    def quebrado(*a, **k):
        raise RuntimeError("sem certificados")
    monkeypatch.setattr(httpx, "Client", quebrado)
    report = tmp_path / "rel.txt"
    assert run_self_test(report) == 1
    assert "FALHOU  HTTPS e certificados" in report.read_text(encoding="utf-8")


def test_main_com_self_test_nao_abre_a_interface_nem_toca_nos_dados(monkeypatch, tmp_path):
    import prospector.main as m
    monkeypatch.setattr("prospector.selftest.tempfile.gettempdir", lambda: str(tmp_path))
    monkeypatch.setattr(m.Settings, "load", classmethod(lambda cls: pytest.fail("não deveria ler as configurações")))
    assert m.main(["--self-test"]) == 0
