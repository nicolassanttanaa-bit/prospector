import pytest

from prospector.database.db import connect
from prospector.database.repository import CompanyFilter, CompanyRepository
from prospector.models.company import CompanyData, LeadStatus, SiteStatus


@pytest.fixture
def repo(tmp_path):
    return CompanyRepository(connect(tmp_path / "t.db"))


def make(sid="1", **kw):
    return CompanyData(source="teste", source_id=sid, name=kw.pop("name", "Lanche do Zé"), **kw)


def test_upsert_nao_duplica(repo):
    a = repo.upsert(make("1"))
    b = repo.upsert(make("1", phone="1999999999"))
    assert a == b and repo.stats()["total"] == 1
    assert repo.get(a)["phone"] == "1999999999"


def test_upsert_preserva_dados_do_usuario_e_nao_apaga_com_vazio(repo):
    cid = repo.upsert(make("1", phone="111"))
    repo.set_lead_status(cid, LeadStatus.INTERESTED)
    repo.set_notes(cid, "ligar segunda")
    repo.set_favorite(cid, True)
    repo.upsert(make("1", phone=None, city="Campinas"))
    row = repo.get(cid)
    assert row["phone"] == "111" and row["city"] == "Campinas"
    assert (row["lead_status"], row["notes"], row["favorite"]) == ("interessado", "ligar segunda", 1)


def test_filtros_combinados(repo):
    a = repo.upsert(make("1", name="A", phone="1", city="Campinas"))
    b = repo.upsert(make("2", name="B", city="Campinas"))
    c = repo.upsert(make("3", name="C", phone="3", city="Sorocaba"))
    for i in (a, b, c):
        repo.set_site_status(i, SiteStatus.NO_SITE, 0.6)
    repo.set_lead_status(c, LeadStatus.FIRST_CONTACT)
    f = CompanyFilter(site_status=SiteStatus.NO_SITE, only_with_phone=True, contacted=False)
    assert [r["name"] for r in repo.search(f)] == ["A"]
    assert [r["name"] for r in repo.search(CompanyFilter(contacted=True))] == ["C"]


def test_stats_vem_do_banco(repo):
    assert repo.stats()["total"] == 0
    a = repo.upsert(make("1")); b = repo.upsert(make("2"))
    repo.set_site_status(a, SiteStatus.HAS_SITE, 0.9)
    repo.set_lead_status(b, LeadStatus.NEGOTIATING)
    s = repo.stats()
    assert (s["total"], s["com_site"], s["inconclusivo"], s["contatadas"], s["em_andamento"]) == (2, 1, 0, 1, 1)
    assert s["nao_verificadas"] == 1   # empresa ainda não verificada não conta como "inconclusiva"


def test_historico_de_contato(repo):
    cid = repo.upsert(make("1"))
    repo.log_contact(cid, "whatsapp", "primeira mensagem")
    assert repo.get(cid)["last_contact_at"] is not None


def test_order_by_invalido_nao_quebra(repo):
    repo.upsert(make("1"))
    assert len(repo.search(order_by="name; DROP TABLE companies")) == 1
