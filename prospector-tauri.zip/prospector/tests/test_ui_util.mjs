// Testes das funções puras da interface (sem DOM). Rodam com: node tests/test_ui_util.mjs
import assert from 'node:assert/strict';
import { KINDS, LEAD_OPTIONS, dotInfo, plural, searchTitle, splitEvidence, fmtDate, debounce } from '../src/prospector/api/ui/util.js';

assert.deepEqual(dotInfo('site', 'yes'), { cls: 'yes', glyph: '✓', short: 'Site', title: 'Site: tem site' });
assert.equal(dotInfo('site', 'no').cls, 'no');
assert.equal(dotInfo('phone', 'no').title, 'Telefone: sem telefone');
assert.equal(dotInfo('instagram', 'qualquer-coisa').cls, 'unk');      // valor desconhecido nunca vira verde/vermelho
assert.equal(dotInfo('facebook', undefined).glyph, '?');
assert.deepEqual(Object.keys(KINDS), ['site', 'phone', 'instagram', 'facebook']);
assert.equal(plural(1, 'empresa', 'empresas'), '1 empresa');
assert.equal(plural(0, 'empresa', 'empresas'), '0 empresas');
assert.equal(plural(12, 'empresa', 'empresas'), '12 empresas');
assert.equal(searchTitle({ category: 'Lanchonetes', city: 'Campinas', state: 'SP' }), 'Lanchonetes em Campinas, SP');
assert.equal(searchTitle({ category: 'Pet shops', city: 'Santos', state: null }), 'Pet shops em Santos');
assert.deepEqual(splitEvidence('a | b |  | c '), ['a', 'b', 'c']);
assert.deepEqual(splitEvidence(null), []);
assert.equal(fmtDate(null), '—');
assert.equal(fmtDate('lixo'), 'lixo');
assert.match(fmtDate('2026-10-25T12:00:00+00:00', false), /^\d{2}\/\d{2}\/2026$/);
assert.equal(LEAD_OPTIONS.length, 8);
let calls = 0;
const d = debounce(() => { calls += 1; }, 20);
d(); d(); d();
await new Promise((r) => setTimeout(r, 80));
assert.equal(calls, 1);
console.log('ok');
