import sqlite3

import pytest

from prospector.database.db import MIGRATIONS, connect
from prospector.database.repository import CompanyRepository
from prospector.integrations.base import SearchQuery
from prospector.models.company import CompanyData, LeadStatus, SiteStatus
from prospector.models.names import brand_key
from prospector.services.search_service import SearchService


@pytest.fixture
def repo(tmp_path):
    return CompanyRepository(connect(tmp_path / "t.db"))


def cd(source, sid, name, city="Campinas", state="SP", **kw):
    return CompanyData(source=source, source_id=sid, name=name, city=city, state=state, **kw)


def test_chave_de_marca():
    same = ["Ragazzo", "RAGAZZO LTDA", "Ragazzo (Cambuí)", "Ragazzo - Shopping Iguatemi", "ragazzo  ME", "Ragazzo | Unidade 2"]
    assert len({brand_key(n) for n in same}) == 1
    assert brand_key("Pizzaria - Zé") != brand_key("Pizzaria - João")        # esquerda só tem palavra genérica
    assert brand_key("Auto Mecânica - Zé") != brand_key("Auto Mecânica - Pedro")
    assert brand_key("Bar do Zé") != brand_key("Bar do Zeca")
    assert brand_key("LTDA") is None and brand_key("") is None and brand_key(None) is None


def test_tres_ragazzo_viram_uma_empresa_com_tres_unidades(repo):
    ids = [repo.upsert_ex(cd("receita_cnpj", f"c{i}", "RAGAZZO", address=f"Rua {i}")) for i in range(3)]
    assert [created for _, created in ids] == [True, False, False]
    cid = ids[0][0]
    assert {i for i, _ in ids} == {cid} and repo.get(cid)["unit_count"] == 3
    assert [u["address"] for u in repo.list_units(cid)] == ["Rua 0", "Rua 1", "Rua 2"]
    assert repo.get(cid)["address"] == "Rua 0"                                # principal não é sobrescrito
    assert repo.stats()["total"] == 1


def test_mesma_loja_em_duas_fontes_conta_como_uma_unidade_e_se_complementa(repo):
    a = repo.upsert(cd("osm", "node/1", "Ragazzo", website="https://ragazzo.com.br", instagram="https://instagram.com/rag"))
    b = repo.upsert(cd("receita_cnpj", "123", "RAGAZZO LTDA", phone="(19) 3000-0000", address="Rua A, 10"))
    row = repo.get(a)
    assert a == b and row["unit_count"] == 1 and len(repo.list_units(a)) == 2
    assert row["phone"] == "(19) 3000-0000" and row["address"] == "Rua A, 10"     # preenchido pela outra fonte
    assert row["website"] == "https://ragazzo.com.br" and row["name"] == "Ragazzo"


def test_rede_com_varias_unidades_nas_duas_fontes(repo):
    for i in range(3):
        repo.upsert(cd("receita_cnpj", f"c{i}", "Ragazzo"))
        repo.upsert(cd("osm", f"node/{i}", "Ragazzo - Unidade %d" % i))
    assert repo.stats()["total"] == 1 and repo.search()[0]["unit_count"] == 3


def test_nao_junta_cidades_estados_ou_nomes_diferentes(repo):
    repo.upsert(cd("a", "1", "Ragazzo"))
    repo.upsert(cd("a", "2", "Ragazzo", city="Sorocaba"))                    # outra cidade
    repo.upsert(cd("a", "3", "Ragazzo", state="RJ"))                         # outro estado
    repo.upsert(cd("a", "4", "Ragazzo", city=None, state=None))              # sem cidade: nunca junta
    repo.upsert(cd("a", "5", "Ragazza"))
    assert repo.stats()["total"] == 5


def test_dados_do_usuario_e_links_confirmados_sobrevivem(repo):
    cid = repo.upsert(cd("receita_cnpj", "1", "Ragazzo"))
    repo.set_lead_status(cid, LeadStatus.INTERESTED); repo.set_notes(cid, "ligar"); repo.set_favorite(cid, True)
    repo.set_links(cid, None, "https://instagram.com/meu", None)
    repo.upsert(cd("osm", "n/1", "Ragazzo", instagram="https://instagram.com/outro", website="https://x.com.br"))
    row = repo.get(cid)
    assert (row["lead_status"], row["notes"], row["favorite"]) == ("interessado", "ligar", 1)
    assert row["instagram"] == "https://instagram.com/meu" and row["website"] is None   # usuário mandou: sem site


def test_cada_pesquisa_mostra_so_as_suas_empresas(repo):
    s1 = repo.create_search("Campinas", "SP", "Lanchonetes", None)
    s2 = repo.create_search("Sorocaba", "SP", "Lanchonetes", None)
    for sid, city, names in ((s1, "Campinas", ["Alfa", "Beta"]), (s2, "Sorocaba", ["Gama"])):
        for n in names:
            cid, _ = repo.upsert_ex(cd("osm", f"{city}{n}", n, city=city))
            repo.link_result(sid, cid)
    repo.conn.commit()
    assert [r["name"] for r in repo.search_companies(s1)] == ["Alfa", "Beta"]
    assert [r["name"] for r in repo.search_companies(s2)] == ["Gama"]
    assert [r["id"] for r in repo.companies_to_check(search_id=s2)] == [repo.search_companies(s2)[0]["id"]]
    repo.delete_search(s1)
    assert repo.get_search(s1) is None and repo.stats()["total"] == 3          # empresas continuam salvas


class Fake:
    name, label = "osm", "Fake"

    def search(self, q, progress, cancelled):
        for i, n in enumerate(["Ragazzo", "Ragazzo", "Ragazzo - Centro", "Outra Loja"]):
            yield CompanyData(source="osm", source_id=f"n/{i}", name=n, city="Campinas", state="SP")


def test_servico_conta_empresas_distintas_e_vincula_a_pesquisa(repo):
    q = SearchQuery.parse("Campinas, SP", "lanchonete")
    sid = repo.create_search("Campinas", "SP", "Lanchonetes", None)
    res = SearchService(repo, [Fake()]).run(q, search_id=sid)
    assert res.found == 2 and res.new == 2 and res.per_source["osm"] == 4       # 4 registros, 2 empresas
    assert sorted(r["name"] for r in repo.search_companies(sid)) == ["Outra Loja", "Ragazzo"]
    assert SearchService(repo, [Fake()]).run(q).new == 0                         # repetir a pesquisa não cria nada


def test_migracao_une_repetidas_do_banco_antigo_sem_perder_dados(tmp_path):
    path = tmp_path / "antigo.db"
    raw = sqlite3.connect(path); raw.row_factory = sqlite3.Row
    for script in MIGRATIONS[:3]:
        raw.executescript(script)
    raw.execute("PRAGMA user_version = 3")
    ins = ("INSERT INTO companies (source, source_id, name, city, state, phone, lead_status, notes, favorite, "
           "last_contact_at, discovered_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?, 'x', 'x')")
    raw.execute(ins, ("receita_cnpj", "1", "RAGAZZO", "Campinas", "SP", None, "novo_lead", "", 0, None))
    raw.execute(ins, ("receita_cnpj", "2", "Ragazzo LTDA", "Campinas", "SP", "(19) 1111-1111", "interessado", "ligar sexta", 1, "2026-01-02"))
    raw.execute(ins, ("osm", "n/3", "Ragazzo", "Campinas", "SP", None, "primeiro_contato", "", 0, "2026-01-05"))
    raw.execute(ins, ("osm", "n/4", "Padaria Sol", "Campinas", "SP", None, "novo_lead", "", 0, None))
    raw.execute("INSERT INTO contact_history (company_id, contacted_at, channel, note) VALUES (2, '2026-01-02', 'WhatsApp', 'oi')")
    raw.commit(); raw.close()

    repo = CompanyRepository(connect(path))
    rows = {r["name"]: r for r in repo.search()}
    assert len(rows) == 2 and "Padaria Sol" in rows
    main = rows["RAGAZZO"]                                                       # o registro mais antigo fica
    assert (main["lead_status"], main["notes"], main["favorite"]) == ("interessado", "ligar sexta", 1)
    assert main["phone"] == "(19) 1111-1111" and main["last_contact_at"] == "2026-01-05" and main["unit_count"] == 2
    assert len(repo.list_units(main["id"])) == 3 and len(repo.list_contacts(main["id"])) == 1
    assert repo.exists("receita_cnpj", "2")                                      # a próxima pesquisa reconhece o registro absorvido
    _, created = repo.upsert_ex(CompanyData(source="receita_cnpj", source_id="2", name="Ragazzo LTDA", city="Campinas", state="SP"))
    assert created is False and repo.stats()["total"] == 2
