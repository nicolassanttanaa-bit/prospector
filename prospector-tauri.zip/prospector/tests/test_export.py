import csv
import json
import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication

from prospector.database.db import connect
from prospector.database.repository import CompanyFilter, CompanyRepository
from prospector.exports.exporter import (HEADERS, ExportError, build_record, describe_filter, export_companies,
                                         neutralize)
from prospector.interface.companies_page import CompaniesPage
from prospector.models.company import CompanyData, LeadStatus, SiteStatus

app = QApplication.instance() or QApplication([])
EVIL = '=HYPERLINK("http://x.test","clique")'


@pytest.fixture
def repo(tmp_path):
    r = CompanyRepository(connect(tmp_path / "t.db"))
    a = r.upsert(CompanyData(source="osm", source_id="node/1", name="Alfa Lanches", category="Lanchonetes",
                             city="Campinas", state="SP", phone="+55 19 1234-5678", instagram="https://instagram.com/alfa"))
    b = r.upsert(CompanyData(source="receita_cnpj", source_id="123", name=EVIL, city="Campinas", state="SP"))
    c = r.upsert(CompanyData(source="receita_cnpj", source_id="456", name="Zeta Bar", city="Sorocaba", state="SP",
                             phone="(15) 3000-0000"))
    r.save_site_check(a, SiteStatus.NO_SITE, 0.65, None, None, "Nenhum site; \"aspas\" e ponto-e-vírgula;")
    r.save_site_check(c, SiteStatus.HAS_SITE, 0.95, "funcionando", "https://zeta.com.br", "ok")
    r.set_notes(a, "Linha 1\nLinha 2; com \"aspas\"")
    r.set_favorite(a, True)
    r.log_contact(a, "WhatsApp", "pediu orçamento", advance=True)
    return r                                                    # EVIL (b) fica sem verificar


def read_csv(path, delimiter):
    with open(path, encoding="utf-8-sig", newline="") as fh:
        return list(csv.reader(fh, delimiter=delimiter))


def test_csv_ponto_e_virgula_para_excel_brasileiro(repo, tmp_path):
    out = tmp_path / "e.csv"
    assert export_companies(repo, repo.search(), out, "csv_semicolon") == 3
    assert out.read_bytes().startswith(b"\xef\xbb\xbf")                       # BOM para acentos no Excel
    rows = read_csv(out, ";")
    header = rows[0]
    assert header[0] == "Nome" and "Situação do site" in header and "Status comercial" in header and len(rows) == 4
    alfa = dict(zip(header, next(r for r in rows if r[0] == "Alfa Lanches")))
    assert alfa["Telefone"] == "+55 19 1234-5678"                             # telefone não é alterado
    assert alfa["Notas"] == "Linha 1\nLinha 2; com \"aspas\""                 # quebras, ; e aspas preservados
    assert alfa["Favorita"] == "Sim" and alfa["Confiança (%)"] == "65"
    assert alfa["Status comercial"] == "Primeiro contato realizado" and alfa["Atribuição da fonte"].startswith("©")
    assert alfa["Instagram"] == "https://instagram.com/alfa"
    zeta = dict(zip(header, next(r for r in rows if r[0] == "Zeta Bar")))
    assert zeta["Atribuição da fonte"].startswith("Dados Abertos") and zeta["Avaliação no Google"] == ""


def test_csv_virgula(repo, tmp_path):
    out = tmp_path / "v.csv"
    export_companies(repo, repo.search(), out, "csv_comma")
    assert len(read_csv(out, ",")[0]) == len(HEADERS)


def test_injecao_de_formula_e_neutralizada(repo, tmp_path):
    assert neutralize(EVIL).startswith("'=") and neutralize("+55 19 1234-5678") == "+55 19 1234-5678"
    assert neutralize("@usuario") == "'@usuario" and neutralize("Normal") == "Normal"
    out = tmp_path / "e.csv"
    export_companies(repo, repo.search(), out, "csv_semicolon")
    assert not any(cell.startswith("=") for row in read_csv(out, ";") for cell in row)


def test_excel(repo, tmp_path):
    from openpyxl import load_workbook
    out = tmp_path / "e.xlsx"
    assert export_companies(repo, repo.search(CompanyFilter(site_status=SiteStatus.NO_SITE)), out, "xlsx",
                            "situação do site: Sem site identificado") == 1
    wb = load_workbook(out)
    assert wb.sheetnames == ["Empresas", "Contatos", "Avisos"]
    ws = wb["Empresas"]
    assert ws.max_row == 2 and ws["A1"].value == "Nome" and ws["A1"].font.bold and ws.freeze_panes == "A2"
    assert ws.auto_filter.ref and ws["A2"].value == "Alfa Lanches"
    assert [c.value for c in wb["Contatos"][2]][0] == "Alfa Lanches" and wb["Contatos"]["C2"].value == "WhatsApp"
    assert any("Sem site identificado" in (r[0].value or "") for r in wb["Avisos"].iter_rows())


def test_excel_nao_cria_formula_a_partir_do_nome(repo, tmp_path):
    from openpyxl import load_workbook
    out = tmp_path / "e.xlsx"
    export_companies(repo, repo.search(), out, "xlsx")
    ws = load_workbook(out)["Empresas"]
    cells = [c for row in ws.iter_rows() for c in row if c.value is not None]
    assert not any(c.data_type == "f" for c in cells)
    assert any(c.value == "'" + EVIL for c in cells)


def test_json_com_metadados_nulos_e_historico(repo, tmp_path):
    out = tmp_path / "e.json"
    export_companies(repo, repo.search(), out, "json", "sem filtros")
    doc = json.loads(out.read_text(encoding="utf-8"))
    assert doc["total"] == 3 and doc["filtros"] == "sem filtros" and doc["gerado_em"]
    assert any("não prova" in a for a in doc["avisos"]) and any("OpenStreetMap" in a for a in doc["avisos"])
    alfa = next(e for e in doc["empresas"] if e["nome"] == "Alfa Lanches")
    assert alfa["favorita"] is True and alfa["situacao_site_codigo"] == "sem_site_identificado"
    assert alfa["status_comercial_codigo"] == "primeiro_contato" and alfa["historico_de_contatos"][0]["canal"] == "WhatsApp"
    assert alfa["ultimo_contato"].startswith("20")                        # ISO, não formatado
    evil = next(e for e in doc["empresas"] if e["nome"] == EVIL)          # JSON guarda o texto original
    assert evil["telefone"] is None and evil["situacao_site_codigo"] == "nao_verificada" and evil["confianca_percentual"] is None


def test_erros_viram_mensagens_claras(repo, tmp_path, monkeypatch):
    with pytest.raises(ExportError, match="pasta de destino"):
        export_companies(repo, [], tmp_path / "nao" / "existe.csv", "csv_comma")
    with pytest.raises(ExportError, match="desconhecido"):
        export_companies(repo, [], tmp_path / "x.zzz", "zzz")
    out = tmp_path / "aberto.csv"
    out.write_text("conteúdo antigo", encoding="utf-8")

    def negado(*a, **k):
        raise PermissionError("em uso")
    monkeypatch.setattr("prospector.exports.exporter.os.replace", negado)
    with pytest.raises(ExportError, match="aberto no Excel"):
        export_companies(repo, repo.search(), out, "csv_comma")
    assert out.read_text(encoding="utf-8") == "conteúdo antigo"             # original intacto
    assert not (tmp_path / "aberto.csv.tmp").exists()                        # temporário removido


def test_descricao_do_filtro():
    assert describe_filter(CompanyFilter()) == "sem filtros"
    d = describe_filter(CompanyFilter(site_status=SiteStatus.NO_SITE, only_with_phone=True, contacted=False,
                                      lead_status=LeadStatus.NEW, city="Campinas"))
    assert all(x in d for x in ("Sem site identificado", "com telefone", "ainda não contatadas", "Campinas"))


def test_pagina_exporta_filtrados_na_ordem_da_tela(repo, tmp_path):
    page = CompaniesPage(repo, "Todas"); page.refresh()
    assert len(page.view_rows()) == 3
    page.city.setText("Sorocaba"); page.refresh()
    out = tmp_path / "f.csv"
    assert page._do_export(page.view_rows(), out, "csv_semicolon", "teste") == 1
    assert [r[0] for r in read_csv(out, ";")[1:]] == ["Zeta Bar"]
    page.city.setText(""); page.refresh()
    page.table.sortByColumn(0, Qt.DescendingOrder)
    assert [r["name"] for r in page.view_rows()][0] == "Zeta Bar"          # ordem da tela, não do banco
