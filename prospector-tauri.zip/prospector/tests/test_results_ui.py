import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest
from PySide6.QtWidgets import QApplication

from prospector.database.db import connect
from prospector.database.repository import CompanyFilter, CompanyRepository
from prospector.interface.companies_model import COL_CONFIDENCE, CompanyTableModel, cell_text, sort_key
from prospector.interface.companies_page import CompaniesPage
from prospector.interface.company_dialog import CompanyDialog
from prospector.interface.links import (google_search_url, instagram_search_url, maps_url, normalize_social,
                                        safe_url)
from prospector.models.company import CompanyData, SiteStatus

app = QApplication.instance() or QApplication([])


@pytest.fixture
def repo(tmp_path):
    r = CompanyRepository(connect(tmp_path / "t.db"))
    a = r.upsert(CompanyData(source="t", source_id="1", name="Alfa", city="Campinas", phone="(19) 1111-1111"))
    b = r.upsert(CompanyData(source="t", source_id="2", name="Beta", city="Campinas"))
    c = r.upsert(CompanyData(source="t", source_id="3", name="Gama", city="Sorocaba", website="https://gama.com.br"))
    r.save_site_check(a, SiteStatus.NO_SITE, 0.55, None, None, "nada encontrado")
    r.save_site_check(c, SiteStatus.HAS_SITE, 0.95, "funcionando", "https://gama.com.br", "ok")
    return r                                                   # Beta fica sem verificar


def test_links_seguros_e_urls():
    assert safe_url("meusite.com.br") == "https://meusite.com.br"
    for bad in ("javascript:alert(1)", "file:///etc/passwd", "ftp://x.com", "semponto", "", None):
        assert safe_url(bad) is None
    assert normalize_social("@lanche", "https://instagram.com") == "https://instagram.com/lanche"
    assert normalize_social("https://instagram.com/x", "https://instagram.com") == "https://instagram.com/x"
    assert normalize_social("lixo com espaço", "https://instagram.com") is None
    assert "query=Lanche+Zé+Campinas+SP" in maps_url("Lanche Zé", "Campinas", "SP").replace("%C3%A9", "é")
    assert "site%3Ainstagram.com" in instagram_search_url("X", "Y") and "google.com/search" in google_search_url("X", "Y")


def test_filtro_por_verificacao(repo):
    names = lambda f: sorted(r["name"] for r in repo.search(f))  # noqa: E731
    assert names(CompanyFilter(site_checked=False)) == ["Beta"]
    assert names(CompanyFilter(site_checked=True, site_status=SiteStatus.NO_SITE)) == ["Alfa"]


def test_links_do_usuario_nao_sao_sobrescritos_pela_fonte(repo):
    cid = repo.search(CompanyFilter(text="Beta"))[0]["id"]
    repo.set_links(cid, "https://beta.com.br", None, None)
    repo.upsert(CompanyData(source="t", source_id="2", name="Beta", website="https://outro.com"))
    assert repo.get(cid)["website"] == "https://beta.com.br"
    repo.set_site_manual(cid, SiteStatus.HAS_SITE)
    row = repo.get(cid)
    assert (row["site_status"], row["site_confidence"]) == ("possui_site", 1.0)


def test_modelo_textos_e_ordenacao(repo):
    rows = {r["name"]: r for r in repo.search()}
    assert cell_text(rows["Beta"], 3) == "Não encontrado" and cell_text(rows["Beta"], 6) == "Não disponível"
    assert cell_text(rows["Beta"], 7) == "Não verificada" and cell_text(rows["Alfa"], 7) == "Sem site identificado"
    assert sort_key(rows["Gama"], COL_CONFIDENCE) > sort_key(rows["Alfa"], COL_CONFIDENCE) > sort_key(rows["Beta"], COL_CONFIDENCE)
    m = CompanyTableModel(); m.set_rows(rows.values())
    assert m.rowCount() == 3 and m.columnCount() == 11


def test_pagina_com_filtros_combinados(repo):
    page = CompaniesPage(repo, "Sem site", {"site_status": SiteStatus.NO_SITE, "site_checked": True})
    page.refresh()
    assert page.model.rowCount() == 1                       # só Alfa
    page.search.setText("zzz"); page.refresh()
    assert page.model.rowCount() == 0 and "Nenhuma empresa" in page.count.text()
    page.search.setText(""); page.phone_chk.setChecked(True); page.refresh()
    assert page.model.rowCount() == 1                       # Alfa tem telefone
    todas = CompaniesPage(repo, "Todas"); todas.refresh()
    assert todas.model.rowCount() == 3
    todas.site_combo.setCurrentIndex(todas.site_combo.findData("unchecked")); todas.refresh()
    assert todas.model.rowCount() == 1


def test_dialogo_mostra_nao_encontrado_e_salva_links(repo):
    cid = repo.search(CompanyFilter(text="Beta"))[0]["id"]
    d = CompanyDialog(repo, cid)
    assert d.phone_label.text() == "Não encontrado"
    d.ig_edit.setText("@beta"); d.site_edit.setText("beta.com.br"); d._save()
    row = repo.get(cid)
    assert row["instagram"] == "https://instagram.com/beta" and row["website"] == "https://beta.com.br"
    assert row["links_confirmed"] == 1 and row["site_status"] == "possui_site"   # site informado => possui site


def test_dialogo_rejeita_link_invalido(repo):
    cid = repo.search(CompanyFilter(text="Beta"))[0]["id"]
    d = CompanyDialog(repo, cid)
    d.site_edit.setText("javascript:alert(1)"); d._save()
    assert "inválido" in d.error.text() and repo.get(cid)["links_confirmed"] == 0
