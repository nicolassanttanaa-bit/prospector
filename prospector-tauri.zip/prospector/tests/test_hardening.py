import io
import logging
import os
import sqlite3
import sys
import zipfile

import httpx
import pytest
from PySide6.QtCore import QObject, QThread, Signal, Slot
from PySide6.QtWidgets import QApplication

from prospector.config.logging_setup import install_excepthook, redact, setup_logging
from prospector.config.prefs import Prefs
from prospector.config.settings import Settings, load_dotenv
from prospector.database.db import connect
from prospector.database.repository import CompanyFilter, CompanyRepository
from prospector.integrations.base import SearchQuery, SourceError
from prospector.integrations.osm import OsmSource, parse_elements
from prospector.integrations.receita import ReceitaSource
from prospector.integrations.site_checker import SiteChecker, SiteState
from prospector.interface.main_window import MainWindow
from prospector.interface.search_page import SearchPage
from prospector.models.company import CompanyData

app = QApplication.instance() or QApplication([])
NOOP, NEVER = (lambda p, m: None), (lambda: False)
Q = SearchQuery.parse("Campinas, SP", "lanchonete")


# ---------- banco ----------
def test_banco_em_wal_permite_ler_durante_escrita(tmp_path):
    path = tmp_path / "t.db"
    writer, reader = connect(path), connect(path)
    assert writer.execute("PRAGMA journal_mode").fetchone()[0] == "wal"
    writer.execute("BEGIN")
    writer.execute("INSERT INTO companies (source, source_id, name, discovered_at, updated_at) VALUES ('t','1','A','x','x')")
    assert reader.execute("SELECT COUNT(*) FROM companies").fetchone()[0] == 0   # lê sem erro de "database is locked"
    writer.commit()
    assert reader.execute("SELECT COUNT(*) FROM companies").fetchone()[0] == 1


def test_curingas_digitados_pelo_usuario_sao_texto(tmp_path):
    repo = CompanyRepository(connect(tmp_path / "t.db"))
    for i, name in enumerate(["A_B Bar", "AxB Bar", "100% Fruta", "1000 Fruta"]):
        repo.upsert(CompanyData(source="t", source_id=str(i), name=name, city="São_Paulo" if i == 0 else "Santos"))
    names = lambda f: sorted(r["name"] for r in repo.search(f))  # noqa: E731
    assert names(CompanyFilter(text="A_B")) == ["A_B Bar"]
    assert names(CompanyFilter(text="100%")) == ["100% Fruta"]
    assert names(CompanyFilter(city="o_P")) == ["A_B Bar"]
    assert names(CompanyFilter(text="a\\b")) == []                     # barra invertida não quebra a consulta


# ---------- validação de entrada ----------
def test_entradas_invalidas_da_pesquisa():
    for bad in (("Campinas\nSP", "lanchonete"), ("x" * 121, "lanchonete"), ("Campinas", "y" * 61),
                ("Campinas", "lanchonete\x00")):
        with pytest.raises(ValueError):
            SearchQuery.parse(*bad)
    assert SearchQuery.parse("  Campinas , sp ", " lanchonete ").state == "SP"


# ---------- Receita: arquivos ruins ----------
def zip_with(path, lines):
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("d.csv", b"\n".join(lines) + b"\n")


def est(mun="6291", fantasia="LANCHE X"):
    row = [""] * 30
    row[0], row[1], row[2], row[4], row[5], row[11], row[19], row[20] = "11111111", "0001", "95", fantasia, "02", "5611203", "SP", mun
    return ";".join(f'"{c}"' for c in row).encode("latin-1")


def test_receita_arquivo_corrompido_ou_truncado_vira_mensagem_clara(tmp_path):
    zip_with(tmp_path / "Municipios.zip", [b'"6291";"CAMPINAS"'])
    zip_with(tmp_path / "Estabelecimentos0.zip", [est()])
    good = (tmp_path / "Estabelecimentos0.zip").read_bytes()
    (tmp_path / "Estabelecimentos0.zip").write_bytes(good[: len(good) // 2])        # truncado
    with pytest.raises(SourceError, match="corrompido"):
        list(ReceitaSource(tmp_path).search(Q, NOOP, NEVER))
    (tmp_path / "Estabelecimentos0.zip").write_bytes(b"isto nao e um zip")
    with pytest.raises(SourceError, match="corrompido"):
        list(ReceitaSource(tmp_path).search(Q, NOOP, NEVER))
    buf = io.BytesIO(); zipfile.ZipFile(buf, "w").close()                             # zip sem arquivos
    (tmp_path / "Estabelecimentos0.zip").write_bytes(buf.getvalue())
    with pytest.raises(SourceError, match="vazio"):
        list(ReceitaSource(tmp_path).search(Q, NOOP, NEVER))


def test_receita_linhas_malformadas_sao_ignoradas(tmp_path):
    zip_with(tmp_path / "Municipios.zip", [b'"6291";"CAMPINAS"', b"lixo", b"", b'"1"'])
    zip_with(tmp_path / "Estabelecimentos0.zip",
             [b'";"6291";', b'"a"b"c;"6291";"x', b"\x00\x01;\"6291\";", est(), est(fantasia="")])
    zip_with(tmp_path / "Empresas0.zip", [b'"11111111"', b'"11111111";"RAZAO SOCIAL LTDA"'])   # 1ª linha curta demais
    got = list(ReceitaSource(tmp_path).search(Q, NOOP, NEVER))
    assert sorted(c.name for c in got) == ["LANCHE X", "RAZAO SOCIAL LTDA"]


# ---------- OSM: respostas ruins ----------
def client(handler):
    return httpx.Client(transport=httpx.MockTransport(handler))


GEO = [{"lat": "-22.9", "lon": "-47.06", "osm_type": "relation", "osm_id": 1}]


def search_with(overpass_response, geo=GEO):
    def handler(req):
        return httpx.Response(200, json=geo) if "nominatim" in req.url.host else overpass_response
    return list(OsmSource(client(handler), sleep=lambda s: None).search(Q, NOOP, NEVER))


def test_osm_estouro_de_limite_nao_vira_zero_resultados():
    resp = httpx.Response(200, json={"elements": [], "remark": "runtime error: Query timed out in \"query\" at line 1"})
    with pytest.raises(SourceError, match="limite de tempo"):
        search_with(resp)


def test_osm_resposta_que_nao_e_json_ou_localizacao_invalida():
    with pytest.raises(SourceError, match="inválida"):
        search_with(httpx.Response(200, text="<html>erro</html>"))
    with pytest.raises(SourceError, match="localização inválida"):
        search_with(httpx.Response(200, json={"elements": []}), geo=[{"lat": "abc", "lon": "1"}])
    assert search_with(httpx.Response(200, json={"elements": "estranho"})) == []


def test_osm_ignora_elementos_malformados():
    q = SearchQuery.parse("Campinas", "lanchonete")
    els = ["texto", {"id": 1}, {"type": "node", "id": 2, "tags": "x"}, {"type": "node", "id": 3, "tags": {"name": "Ok"}}]
    assert [c.name for c in parse_elements(els, q)] == ["Ok"]


# ---------- verificador de sites: portas ----------
def test_so_portas_web_comuns():
    resolver = lambda h: ["93.184.216.34"]  # noqa: E731
    chk = SiteChecker(client(lambda r: httpx.Response(200, text="ok")), resolver)
    assert chk.fetch("http://exemplo.com.br:22/").state == SiteState.INVALID_DOMAIN
    assert chk.fetch("http://exemplo.com.br:abc/").state == SiteState.INVALID_DOMAIN
    assert chk.fetch("https://exemplo.com.br:8443/").state == SiteState.WORKING


# ---------- logs, configuração e erros globais ----------
def test_redacao_de_segredos():
    assert redact("GET /x?key=SEGREDO123&q=1") == "GET /x?key=***&q=1"
    assert "AIza" not in redact("chave AIza" + "A" * 35)
    assert redact("texto normal") == "texto normal"


@pytest.fixture
def clean_logging():
    yield
    root = logging.getLogger()
    for h in list(root.handlers):
        root.removeHandler(h); h.close()


def test_log_rotativo_sem_segredos_e_sem_ruido_de_rede(tmp_path, clean_logging):
    path = setup_logging(tmp_path)
    assert logging.getLogger("httpx").level == logging.WARNING
    log = logging.getLogger("prospector.teste")
    try:
        raise RuntimeError("falha em https://api.exemplo.com/x?key=SEGREDO123")
    except RuntimeError:
        log.exception("erro ao consultar")
    logging.getLogger("httpx").info("HTTP Request: GET https://empresa.com.br")
    for h in logging.getLogger().handlers:
        h.flush()
    text = path.read_text(encoding="utf-8")
    assert "erro ao consultar" in text and "SEGREDO123" not in text and "key=***" in text
    assert "empresa.com.br" not in text
    assert any(type(h).__name__ == "RotatingFileHandler" for h in logging.getLogger().handlers)


def test_dotenv_nao_sobrescreve_variaveis_do_sistema(tmp_path, monkeypatch):
    env = tmp_path / ".env"
    env.write_text('# comentário\nPROSPECTOR_T1="abc"\nPROSPECTOR_T2=def\nlinha sem igual\nPROSPECTOR_T3 = \'x y\'\n', encoding="utf-8")
    monkeypatch.setenv("PROSPECTOR_T2", "do-sistema")
    for k in ("PROSPECTOR_T1", "PROSPECTOR_T3"):
        monkeypatch.delenv(k, raising=False)
    load_dotenv(env)
    assert (os.environ["PROSPECTOR_T1"], os.environ["PROSPECTOR_T2"], os.environ["PROSPECTOR_T3"]) == ("abc", "do-sistema", "x y")
    monkeypatch.delenv("PROSPECTOR_T1"); monkeypatch.delenv("PROSPECTOR_T3")
    load_dotenv(tmp_path / "nao-existe.env")          # arquivo ausente é ignorado


def test_settings_le_env_da_pasta_de_dados(tmp_path, monkeypatch):
    (tmp_path / ".env").write_text("GOOGLE_PLACES_API_KEY=chave-teste\n", encoding="utf-8")
    monkeypatch.setenv("PROSPECTOR_DATA_DIR", str(tmp_path / "dados"))
    (tmp_path / "dados").mkdir(); (tmp_path / "dados" / ".env").write_text("GOOGLE_PLACES_API_KEY=chave-da-pasta\n", encoding="utf-8")
    monkeypatch.delenv("GOOGLE_PLACES_API_KEY", raising=False)
    monkeypatch.chdir(tmp_path)
    assert Settings.load().google_places_api_key == "chave-teste"      # .env da pasta atual vence o da pasta de dados
    monkeypatch.delenv("GOOGLE_PLACES_API_KEY", raising=False)


def test_excecao_nao_tratada_vai_para_o_log_e_avisa_uma_vez(tmp_path, clean_logging, monkeypatch):
    setup_logging(tmp_path)
    monkeypatch.setattr(sys, "excepthook", sys.excepthook)             # restaurado ao fim do teste
    avisos = []
    install_excepthook(avisos.append)
    for _ in range(2):
        sys.excepthook(ValueError, ValueError("boom key=SEGREDO9"), None)
    for h in logging.getLogger().handlers:
        h.flush()
    text = (tmp_path / "prospector.log").read_text(encoding="utf-8")
    assert len(avisos) == 1 and "Exceção não tratada" in text and "SEGREDO9" not in text


def test_main_mostra_erro_amigavel_se_nao_abre_o_banco(monkeypatch):
    import prospector.main as m
    mensagens = []
    monkeypatch.setattr(m.Settings, "load", classmethod(lambda cls: (_ for _ in ()).throw(PermissionError("sem permissão"))))
    monkeypatch.setattr(m.QMessageBox, "critical", lambda *a: mensagens.append(a[2]))
    assert m.main() == 1 and "PROSPECTOR_DATA_DIR" in mensagens[0] and "sem permissão" in mensagens[0]


# ---------- encerramento seguro ----------
class SlowWorker(QObject):
    progress = Signal(int, str, int)
    finished = Signal(object)
    failed = Signal(str)

    def __init__(self):
        super().__init__()
        self._cancel = False

    def cancel(self):
        self._cancel = True

    @Slot()
    def run(self):
        while not self._cancel:
            QThread.msleep(5)
        self.finished.emit(None)


def test_shutdown_cancela_e_espera_a_tarefa(tmp_path):
    page = SearchPage(tmp_path / "x.db", Prefs())
    assert page.shutdown() is True                                       # nada rodando
    page._launch(SlowWorker(), lambda r: None)
    assert page._thread.isRunning()
    assert page.shutdown(5000) is True and not page._thread.isRunning()


def test_fechar_janela_ociosa_funciona(tmp_path):
    repo = CompanyRepository(connect(tmp_path / "t.db"))
    win = MainWindow(repo, Settings(data_dir=tmp_path), Prefs())
    assert win.close() is True
