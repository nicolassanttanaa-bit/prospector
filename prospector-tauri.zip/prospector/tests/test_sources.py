import json
import urllib.parse
import zipfile

import httpx
import pytest

from prospector.integrations.base import SearchQuery, SourceError, SourceUnavailable
from prospector.integrations.cnae import find_category
from prospector.integrations.osm import OsmSource, parse_elements
from prospector.integrations.receita import ReceitaSource, clean_company_name, format_phone

NOOP = lambda p, m: None  # noqa: E731
NEVER = lambda: False  # noqa: E731


def est(basico="12345678", ordem="0001", dv="95", fantasia="LANCHE DO ZE", sit="02",
        cnae="5611203", uf="SP", mun="6291"):
    row = [""] * 30
    row[0], row[1], row[2], row[3], row[4], row[5], row[11] = basico, ordem, dv, "1", fantasia, sit, cnae
    row[13], row[14], row[15], row[17], row[18] = "RUA", "DAS FLORES", "100", "CENTRO", "13000000"
    row[19], row[20], row[21], row[22] = uf, mun, "19", "34567890"
    return ";".join(f'"{c}"' for c in row)


def make_zip(path, lines):
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("dados.csv", "\n".join(lines).encode("latin-1") + b"\n")


@pytest.fixture
def receita_dir(tmp_path):
    make_zip(tmp_path / "Municipios.zip", ['"6291";"CAMPINAS"', '"7107";"SAO PAULO"'])
    make_zip(tmp_path / "Estabelecimentos0.zip", [
        est(),                                         # casa com a busca
        est(basico="22222222", sit="08"),              # baixada
        est(basico="33333333", cnae="9602501"),        # outra atividade
        est(basico="44444444", mun="7107"),            # outro município
        est(basico="55555555", fantasia=""),           # sem nome fantasia
    ])
    make_zip(tmp_path / "Empresas0.zip", ['"55555555";"JOAO DA SILVA 12345678901";"2135";"50";"0";"01";""'])
    return tmp_path


def query(cat="lanchonete", state="SP", radius=None):
    return SearchQuery.parse(f"Campinas, {state}" if state else "Campinas", cat, radius)


def test_receita_filtra_e_resolve_nomes(receita_dir):
    got = list(ReceitaSource(receita_dir).search(query(), NOOP, NEVER))
    by_id = {c.source_id: c for c in got}
    assert set(by_id) == {"12345678000195", "55555555000195"}
    c = by_id["12345678000195"]
    assert c.name == "LANCHE DO ZE" and c.phone == "(19) 3456-7890" and c.state == "SP"
    assert "RUA DAS FLORES, 100" in c.address
    assert by_id["55555555000195"].name == "JOAO DA SILVA"   # CPF removido


def test_receita_sem_arquivos_da_mensagem_clara(tmp_path):
    with pytest.raises(SourceUnavailable, match="Municipios.zip"):
        list(ReceitaSource(tmp_path).search(query(), NOOP, NEVER))
    with pytest.raises(SourceUnavailable, match="configure"):
        list(ReceitaSource(None).search(query(), NOOP, NEVER))


def test_receita_cidade_inexistente(receita_dir):
    q = SearchQuery.parse("Narnia, SP", "lanchonete")
    with pytest.raises(SourceError, match="não encontrado"):
        list(ReceitaSource(receita_dir).search(q, NOOP, NEVER))


def test_helpers():
    assert format_phone("11", "987654321") == "(11) 98765-4321"
    assert format_phone("", "") is None
    assert clean_company_name("MARIA 12345678901") == "MARIA"
    assert clean_company_name("PADARIA LTDA") == "PADARIA LTDA"


def test_query_parse_e_categorias():
    q = SearchQuery.parse("Campinas, São Paulo", "Lanchonetes", 10)
    assert (q.city, q.state, q.category.name, q.radius_km) == ("Campinas", "SP", "Lanchonetes", 10)
    assert find_category("salão").name == "Salões de beleza"
    assert find_category("5611-2/03").cnaes == ("5611203",)
    for bad in (("", "lanchonete"), ("Campinas, XX", "lanchonete"), ("Campinas", "xyzabc")):
        with pytest.raises(ValueError):
            SearchQuery.parse(*bad)
    with pytest.raises(ValueError):
        SearchQuery.parse("Campinas", "lanchonete", 500)


def test_osm_parse_elements():
    q = query()
    els = [{"type": "node", "id": 1, "lat": -22.9, "lon": -47.0,
            "tags": {"name": "Lanche X", "phone": "+55 19 1234-5678", "contact:instagram": "@lanchex",
                     "addr:street": "Rua A", "addr:housenumber": "10"}},
           {"type": "way", "id": 2, "center": {"lat": -22.8, "lon": -47.1}, "tags": {"name": "Com Site", "website": "https://x.com.br"}},
           {"type": "node", "id": 3, "tags": {"amenity": "fast_food"}}]  # sem nome: ignorado
    a, b = parse_elements(els, q)
    assert a.source_id == "node/1" and a.instagram == "https://instagram.com/lanchex" and a.address == "Rua A 10"
    assert b.website == "https://x.com.br" and b.lat == -22.8 and b.city == "Campinas"


def _osm_client(handler):
    return httpx.Client(transport=httpx.MockTransport(handler))


def test_osm_busca_completa_com_servidor_simulado():
    seen = {}

    def handler(request):
        if "nominatim" in request.url.host:
            return httpx.Response(200, json=[{"lat": "-22.9", "lon": "-47.06", "osm_type": "relation", "osm_id": 123}])
        seen["q"] = urllib.parse.parse_qs(request.content.decode())["data"][0]
        return httpx.Response(200, json={"elements": [{"type": "node", "id": 9, "lat": 1, "lon": 2, "tags": {"name": "Z"}}]})

    got = list(OsmSource(_osm_client(handler), sleep=lambda s: None).search(query(), NOOP, NEVER))
    assert [c.name for c in got] == ["Z"]
    assert "3600000123" in seen["q"] and '"amenity"="fast_food"' in seen["q"]


def test_osm_com_raio_usa_around():
    seen = {}

    def handler(request):
        if "nominatim" in request.url.host:
            return httpx.Response(200, json=[{"lat": "-22.9", "lon": "-47.06", "osm_type": "relation", "osm_id": 123}])
        seen["q"] = urllib.parse.parse_qs(request.content.decode())["data"][0]
        return httpx.Response(200, json={"elements": []})

    list(OsmSource(_osm_client(handler), sleep=lambda s: None).search(query(radius=10), NOOP, NEVER))
    assert "around:10000,-22.9,-47.06" in seen["q"] and "area(" not in seen["q"]


def test_osm_limite_de_uso_vira_aviso_claro():
    src = OsmSource(_osm_client(lambda r: httpx.Response(429)), sleep=lambda s: None)
    with pytest.raises(SourceUnavailable, match="limite"):
        list(src.search(query(), NOOP, NEVER))


def test_osm_cidade_nao_encontrada():
    src = OsmSource(_osm_client(lambda r: httpx.Response(200, json=[])), sleep=lambda s: None)
    with pytest.raises(SourceError, match="não encontrada"):
        list(src.search(query(), NOOP, NEVER))
