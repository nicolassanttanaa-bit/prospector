import httpx
import pytest

from prospector.integrations.site_checker import DnsTemporaryError, SiteChecker, SiteState

PUBLIC = {"exemplo.com.br": ["93.184.216.34"], "www.exemplo.com.br": ["93.184.216.34"],
          "outro.com.br": ["93.184.216.35"], "interno.com.br": ["127.0.0.1"], "nuvem.com.br": ["10.0.0.5"]}


def resolver(host):
    if host == "dns-falha.com":
        raise DnsTemporaryError("timeout")
    return PUBLIC.get(host, [])


def checker(handler):
    return SiteChecker(httpx.Client(transport=httpx.MockTransport(handler)), resolver)


def test_site_funcionando():
    r = checker(lambda req: httpx.Response(200, text="<title>Olá</title>")).fetch("https://exemplo.com.br")
    assert r.state == SiteState.WORKING and "olá" in r.text


def test_redirecionamento():
    def h(req):
        if req.url.host == "exemplo.com.br":
            return httpx.Response(301, headers={"location": "https://outro.com.br/home"})
        return httpx.Response(200, text="ok")
    r = checker(h).fetch("https://exemplo.com.br")
    assert r.state == SiteState.REDIRECTED and r.final_url == "https://outro.com.br/home"


def test_bloqueia_enderecos_internos_inclusive_em_redirecionamento():
    assert checker(lambda r: httpx.Response(200)).fetch("https://interno.com.br").state == SiteState.INVALID_DOMAIN
    h = lambda req: httpx.Response(302, headers={"location": "http://nuvem.com.br/"})  # noqa: E731
    assert checker(h).fetch("https://exemplo.com.br").state == SiteState.INVALID_DOMAIN


def test_estados_de_erro():
    assert checker(lambda r: httpx.Response(500)).fetch("https://exemplo.com.br").state == SiteState.UNAVAILABLE
    assert checker(lambda r: httpx.Response(404)).fetch("https://exemplo.com.br").state == SiteState.INCONCLUSIVE
    assert checker(lambda r: httpx.Response(403, text="Please complete the CAPTCHA")).fetch(
        "https://exemplo.com.br").state == SiteState.INCONCLUSIVE   # não tenta contornar

    def timeout(req):
        raise httpx.ConnectTimeout("t")
    assert checker(timeout).fetch("https://exemplo.com.br").state == SiteState.UNAVAILABLE

    def refused(req):
        raise httpx.ConnectError("x")
    assert checker(refused).fetch("https://exemplo.com.br").state == SiteState.CONNECTION_ERROR
    assert checker(lambda r: httpx.Response(200)).fetch("https://nao-existe.com.br").state == SiteState.INVALID_DOMAIN
    assert checker(lambda r: httpx.Response(200)).fetch("https://dns-falha.com").state == SiteState.CONNECTION_ERROR
    assert checker(lambda r: httpx.Response(200)).fetch("ftp://exemplo.com.br").state == SiteState.INVALID_DOMAIN


def test_laco_de_redirecionamentos():
    h = lambda req: httpx.Response(302, headers={"location": "https://exemplo.com.br/x"})  # noqa: E731
    assert checker(h).fetch("https://exemplo.com.br").state == SiteState.INCONCLUSIVE


def test_domain_exists_e_internet():
    c = checker(lambda r: httpx.Response(200))
    assert c.domain_exists("exemplo.com.br") is True
    assert c.domain_exists("nao-existe.com.br") is False
    assert c.domain_exists("dns-falha.com") is None
    assert not c.has_internet()   # nenhum dos domínios-canário resolve neste resolver falso
