import os
import re

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest
from PySide6.QtWidgets import QApplication

from prospector.database.db import connect
from prospector.database.repository import MAX_NOTES, CompanyFilter, CompanyRepository
from prospector.interface.companies_model import cell_text
from prospector.interface.companies_page import CompaniesPage
from prospector.interface.company_dialog import CompanyDialog
from prospector.interface.labels import fmt_local
from prospector.models.company import CompanyData, LeadStatus

app = QApplication.instance() or QApplication([])


@pytest.fixture
def repo(tmp_path):
    return CompanyRepository(connect(tmp_path / "t.db"))


@pytest.fixture
def cid(repo):
    return repo.upsert(CompanyData(source="t", source_id="1", name="Lanche Teste", city="Campinas"))


def test_registrar_contato_avanca_so_status_iniciais(repo, cid):
    repo.log_contact(cid, "WhatsApp", "mandei proposta", advance=True)
    row = repo.get(cid)
    assert row["lead_status"] == "primeiro_contato" and row["last_contact_at"]
    repo.set_lead_status(cid, LeadStatus.INTERESTED)
    repo.log_contact(cid, "Ligação", advance=True)
    assert repo.get(cid)["lead_status"] == "interessado"          # não retrocede
    assert [c["channel"] for c in repo.list_contacts(cid)] == ["Ligação", "WhatsApp"]   # mais recente primeiro


def test_dialogo_salva_favorito_status_e_notas(repo, cid):
    d = CompanyDialog(repo, cid)
    d.fav_chk.setChecked(True)
    d.lead_combo.setCurrentIndex(d.lead_combo.findData("negociacao"))
    d.notes_edit.setPlainText("Retornar na próxima semana.")
    d._save()
    row = repo.get(cid)
    assert (row["favorite"], row["lead_status"], row["notes"]) == (1, "negociacao", "Retornar na próxima semana.")
    assert [r["id"] for r in repo.search(CompanyFilter(favorites_only=True))] == [cid]


def test_dialogo_registra_contato_na_hora_e_atualiza_historico(repo, cid):
    d = CompanyDialog(repo, cid)
    d.channel.setCurrentText("WhatsApp"); d.contact_note.setText("pediu orçamento")
    d._log_contact()
    assert "WhatsApp" in d.history.toPlainText() and "pediu orçamento" in d.history.toPlainText()
    assert d.lead_combo.currentData() == "primeiro_contato" and d.contact_note.text() == ""
    assert repo.get(cid)["last_contact_at"]


def test_notas_longas_demais_sao_recusadas(repo, cid):
    d = CompanyDialog(repo, cid)
    d.notes_edit.setPlainText("x" * (MAX_NOTES + 1)); d._save()
    assert "passam de" in d.error.text() and repo.get(cid)["notes"] == ""


def test_acoes_rapidas_da_tabela(repo, cid):
    page = CompaniesPage(repo, "Todas"); page.refresh()
    page._toggle_favorite(cid)
    assert repo.get(cid)["favorite"] == 1 and cell_text(repo.get(cid), 0).startswith("★")
    page._toggle_favorite(cid)
    assert repo.get(cid)["favorite"] == 0
    page._set_status(cid, LeadStatus.AWAITING)
    assert repo.get(cid)["lead_status"] == "aguardando_resposta"
    fav = CompaniesPage(repo, "Favoritas", {"favorites_only": True}); fav.refresh()
    assert fav.model.rowCount() == 0
    repo.set_favorite(cid, True); fav.refresh()
    assert fav.model.rowCount() == 1


def test_coluna_ultimo_contato_e_dashboard(repo, cid):
    assert cell_text(repo.get(cid), 10) == "—"
    repo.log_contact(cid, "E-mail", advance=True)
    assert re.fullmatch(r"\d\d/\d\d/\d{4}", cell_text(repo.get(cid), 10))
    s = repo.stats()
    assert s["contatadas"] == 1 and s["em_andamento"] == 1


def test_fmt_local():
    assert fmt_local(None) == "—" and fmt_local("lixo") == "lixo"
    assert re.fullmatch(r"\d\d/\d\d/2026 \d\d:\d\d", fmt_local("2026-10-25T12:00:00+00:00"))
