import pytest

from prospector.config.prefs import Prefs
from prospector.database.db import connect
from prospector.database.repository import CompanyRepository
from prospector.integrations.base import SearchQuery, SourceUnavailable
from prospector.models.company import CompanyData
from prospector.services.search_service import SearchService


class FakeSource:
    def __init__(self, name, items=(), error=None):
        self.name, self.label, self.items, self.error = name, name.upper(), items, error

    def search(self, query, progress, cancelled):
        for i in self.items:
            yield CompanyData(source=self.name, source_id=str(i), name=f"E{i}")
        if self.error:
            raise self.error


@pytest.fixture
def repo(tmp_path):
    return CompanyRepository(connect(tmp_path / "t.db"))


Q = SearchQuery.parse("Campinas, SP", "lanchonete")


def test_falha_parcial_nao_derruba_a_pesquisa(repo):
    svc = SearchService(repo, [FakeSource("a", [1, 2]), FakeSource("b", error=SourceUnavailable("sem rede")),
                               FakeSource("c", error=RuntimeError("bug"))])
    r = svc.run(Q)
    assert r.found == 2 and len(r.warnings) == 2 and "sem rede" in r.warnings[0]
    assert repo.stats()["total"] == 2 and len(repo.list_search_history()) == 3


def test_pesquisas_repetidas_nao_duplicam(repo):
    svc = SearchService(repo, [FakeSource("a", [1, 2])])
    assert svc.run(Q).new == 2
    r = svc.run(Q)
    assert r.new == 0 and r.found == 2 and repo.stats()["total"] == 2


def test_cancelamento(repo):
    calls = {"n": 0}

    def cancelled():
        calls["n"] += 1
        return calls["n"] > 1   # cancela depois da primeira fonte

    r = SearchService(repo, [FakeSource("a", [1]), FakeSource("b", [2])]).run(Q, cancelled=cancelled)
    assert r.cancelled and r.found == 1


def test_sem_fontes_ativas(repo):
    with pytest.raises(ValueError, match="Nenhuma fonte"):
        SearchService(repo, []).run(Q)


def test_prefs_roundtrip_e_arquivo_corrompido(tmp_path):
    p = tmp_path / "prefs.json"
    Prefs(receita_dir="C:/x", use_osm=False).save(p)
    assert Prefs.load(p) == Prefs(receita_dir="C:/x", use_osm=False)
    p.write_text("{lixo", encoding="utf-8")
    assert Prefs.load(p) == Prefs()
