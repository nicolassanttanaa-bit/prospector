import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")


def test_janela_abre_e_dashboard_le_o_banco(tmp_path):
    from PySide6.QtWidgets import QApplication
    from prospector.database.db import connect
    from prospector.database.repository import CompanyRepository
    from prospector.interface.main_window import MainWindow
    from prospector.models.company import CompanyData

    app = QApplication.instance() or QApplication([])
    repo = CompanyRepository(connect(tmp_path / "t.db"))
    repo.upsert(CompanyData(source="t", source_id="1", name="X"))
    from prospector.config.prefs import Prefs
    from prospector.config.settings import Settings
    win = MainWindow(repo, Settings(data_dir=tmp_path), Prefs())
    assert "1" in win.dashboard.cards["total"].text()
    assert win.sidebar.count() == 9
