# Gera o instalador do Prospector com interface Tauri (Windows). Uso:  .\build-desktop.ps1  (ou build-desktop.bat)
# Requisitos (uma vez): Python 3.10+, Rust (rustup.rs) e as "Ferramentas de Build do Visual Studio" com C++.
# Opção: -SkipTests pula os testes automáticos.
param([switch]$SkipTests)
$ErrorActionPreference = "Stop"
$root = $PSScriptRoot
Set-Location -Path $root

function Run($exe, $arguments) {
    & $exe @arguments
    if ($LASTEXITCODE -ne 0) { throw "Falhou (codigo $LASTEXITCODE): $exe $arguments" }
}
function Need($name, $help) {
    if (-not (Get-Command $name -ErrorAction SilentlyContinue)) { throw "$name nao encontrado. $help" }
}

$systemPython = $null
foreach ($candidate in @("python", "py")) {
    if (Get-Command $candidate -ErrorAction SilentlyContinue) { $systemPython = $candidate; break }
}
if (-not $systemPython) { throw "Python nao encontrado. Instale o Python 3.10 ou mais novo em python.org." }
Need "rustc" "Instale o Rust em https://rustup.rs e abra um novo terminal."
Need "cargo" "Instale o Rust em https://rustup.rs e abra um novo terminal."

$venv = Join-Path $root ".build-venv"
$py = Join-Path $venv "Scripts\python.exe"
if (-not (Test-Path $py)) {
    Write-Host "1/6 Criando ambiente de construcao..."
    Run $systemPython @("-m", "venv", $venv)
}
Write-Host "2/6 Instalando dependencias do motor (pode demorar na primeira vez)..."
Run $py @("-m", "pip", "install", "--quiet", "-e", ".", "pyinstaller>=6.15", "pytest")

if (-not $SkipTests) {
    Write-Host "3/6 Rodando os testes..."
    $env:QT_QPA_PLATFORM = "offscreen"
    try { Run $py @("-m", "pytest", "-q") } finally { Remove-Item Env:QT_QPA_PLATFORM -ErrorAction SilentlyContinue }
} else {
    Write-Host "3/6 Testes ignorados (-SkipTests)."
}

Write-Host "4/6 Empacotando o motor Python (prospector-api.exe)..."
Run $py @("-m", "PyInstaller", "packaging\prospector-api.spec", "--noconfirm", "--clean", "--distpath", "dist-sidecar", "--workpath", "build\sidecar")
$sidecar = Join-Path $root "dist-sidecar\prospector-api.exe"
Write-Host "    Autoteste do motor empacotado..."
& $sidecar --self-test
if ($LASTEXITCODE -ne 0) { throw "O autoteste do motor empacotado falhou (veja o relatorio acima)." }

# O Tauri exige o nome do binario externo com o sufixo da arquitetura (ex.: prospector-api-x86_64-pc-windows-msvc.exe).
$hostLine = rustc -Vv | Select-String -Pattern '^host: (.+)$'
$triple = $hostLine.Matches[0].Groups[1].Value
$binDir = Join-Path $root "desktop\src-tauri\binaries"
New-Item -ItemType Directory -Force -Path $binDir | Out-Null
Remove-Item (Join-Path $binDir "prospector-api-*") -Force -ErrorAction SilentlyContinue
Copy-Item $sidecar (Join-Path $binDir "prospector-api-$triple.exe") -Force

Write-Host "5/6 Conferindo a ferramenta de build do Tauri..."
cargo tauri --version | Out-Null
if ($LASTEXITCODE -ne 0) {
    Write-Host "    Instalando o tauri-cli (so na primeira vez; leva alguns minutos)..."
    Run "cargo" @("install", "tauri-cli", "--version", "^2", "--locked")
}

Write-Host "6/6 Gerando o instalador (a primeira compilacao do Rust demora)..."
Set-Location (Join-Path $root "desktop")
Run "cargo" @("tauri", "build")
Set-Location $root

$installer = Get-ChildItem (Join-Path $root "desktop\src-tauri\target\release\bundle\nsis") -Filter "*.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
Write-Host ""
if ($installer) { Write-Host "Pronto! Instalador: $($installer.FullName)" } else { Write-Host "Build concluido, mas o instalador nao foi encontrado em desktop\src-tauri\target\release\bundle\nsis." }
