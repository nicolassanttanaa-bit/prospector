# Prospector

Encontra empresas locais e ajuda a identificar as que **aparentemente não têm site**, para prospecção comercial.
Interface desktop em Python (PySide6) + SQLite. Funciona sem API paga.

## Instalação
```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -e ".[dev]"
```

## Executar
```bash
prospector            # ou: python -m prospector.main
```

## Testes
```bash
pytest
```

## Onde ficam os dados
`~/.prospector/` (banco `prospector.db` e `prospector.log`). Mude com a variável `PROSPECTOR_DATA_DIR`.

## Aviso sobre cobertura
Nenhuma fonte gratuita lista todas as empresas. "Sem site identificado" significa que nenhuma fonte consultada
mostrou um site, não que a empresa não tenha um.

## Status
Versão 1.1: interface nova em **Tauri** (painel de pesquisa à esquerda, cartões quadrados com bolinhas verde/vermelha,
botão "ver mais", resultados só da cidade pesquisada, sem lojas repetidas). A versão clássica em Qt continua no
repositório. Veja `docs/MANUAL.md` para instalação e uso.

## Arquitetura da interface nova
```
Tauri (Rust, ~60 linhas)  ──inicia/encerra──▶  prospector-api.exe (Python, sidecar)
  janela WebView2                                API HTTP em 127.0.0.1, porta aleatória, token a cada abertura
  src/prospector/api/ui  ◀──── fetch + token ───  pesquisa, classificação, banco SQLite, exportação
```
- `src/prospector/api/ui/`: interface (HTML/CSS/JS puro, sem build de front-end, sem `innerHTML`, CSP restrita).
- `src/prospector/api/`: motor local (servidor, tarefas em segundo plano, serializadores). Não importa Qt.
- `desktop/src-tauri/`: casca do Tauri (Cargo.toml, tauri.conf.json, permissões mínimas, `main.rs`).
- Banco: migração v4 junta lojas repetidas (mesma marca, cidade e estado) e liga cada pesquisa aos seus resultados.

## Como rodar a interface nova
- **Sem Rust (modo navegador):** `pip install -e .` e `python -m prospector.api --browser`.
- **Instalador de Windows:** `build-desktop.bat` (precisa de Rust e das Ferramentas de Build do Visual Studio).
- Desenvolvimento: `cargo tauri dev` dentro de `desktop`, depois de copiar o motor empacotado para
  `desktop/src-tauri/binaries/prospector-api-<arquitetura>.exe` (o `build-desktop.ps1` faz isso).
- O motor tem autoteste: `prospector-api --self-test`.

## Classificação de sites
- **A — Sem site identificado:** nenhuma fonte informou site e os domínios prováveis não existem (ou não conferem).
  Quem só tem Instagram/Facebook cai aqui, com a rede social registrada.
- **B — Possui site:** a fonte informou um site que responde, ou um domínio provável cujo conteúdo confere nome e cidade/telefone.
- **C — Inconclusivo:** domínio informado inexistente, domínio parecido sem confirmação, falha de DNS.
- Cada resultado traz **confiança** (0 a 1) e **evidências**. Falha de conexão nunca é tratada como prova de ausência de site.
- A verificação é segura: só http/https, bloqueia endereços internos, limita tempo e tamanho, e não tenta contornar CAPTCHA.

## Fontes de dados (gratuitas)
- **Receita Federal (CNPJ):** baixe em https://dados.gov.br/dados/conjuntos-dados/cadastro-nacional-da-pessoa-juridica---cnpj
  os arquivos `Estabelecimentos0..9.zip` e `Municipios.zip` (opcional: `Empresas0..9.zip`). Salve os .zip numa pasta,
  sem extrair, e escolha-a em Configurações. Cobre só empresas formais; a leitura pode levar alguns minutos.
- **OpenStreetMap:** automático (precisa de internet). Cobertura irregular; dados © contribuidores do OSM (ODbL).
- O raio só vale para o OpenStreetMap.

## Telas de resultados
Tabela com busca, ordenação por coluna e filtros combinados (categoria, cidade, situação do site, status comercial,
contatadas ou não, com telefone, com Instagram, favoritas). Dois cliques abrem os detalhes: evidências da classificação,
fonte e data dos dados, links (Google Maps, site, redes) e campos editáveis. Links que você informa passam a valer sobre
os das fontes e você pode definir manualmente a situação do site (confiança 100%).

## Gestão de oportunidades
Na tela de detalhes: favorita, status comercial (novo lead … cliente fechado), notas e registro de contatos com canal,
resumo e data (o primeiro contato registrado move "novo lead" para "primeiro contato"). Na tabela, clique direito
favorita a empresa ou muda o status. O sistema não envia mensagens automaticamente.

## Exportação
Em qualquer lista, **Exportar lista filtrada…** grava só o que está na tela (na ordem da tabela) e **Exportar todas as
empresas…** grava tudo. Formatos: Excel (.xlsx, com abas Empresas, Contatos e Avisos), CSV com ponto e vírgula (abre
direto no Excel brasileiro), CSV com vírgula e JSON (com histórico de contatos e metadados). Campos sem dado ficam vazios
(JSON: null). Células de texto que começam com = + - @ são neutralizadas contra injeção de fórmula, e o arquivo só
substitui o destino depois de gravado por completo. Os arquivos trazem a atribuição das fontes (OpenStreetMap, Receita).

## Limites e custos das fontes (todas gratuitas, sem chave de API)
- **Receita Federal (CNPJ):** arquivos públicos baixados por você. Só empresas formais; pode haver empresas já fechadas
  ou com telefone do contador. Dados de MEI podem conter dados pessoais: use para contato comercial pontual (LGPD).
- **OpenStreetMap — Nominatim:** política pública: no máximo 1 requisição por segundo, aplicativo identificado e
  atribuição visível. O Prospector faz 1 consulta por pesquisa.
- **OpenStreetMap — Overpass:** uso justo (ordem de 10 mil consultas e 1 GB por dia por IP). 1 consulta por pesquisa;
  em 429/502/503/504 há 2 novas tentativas. Se o serviço estourar tempo/memória, o app avisa em vez de mostrar "0 resultados".
- Cobertura: nenhuma fonte lista todas as empresas; "sem site identificado" não prova que o site não existe.
- Google Places (pago) não está implementado; a chave, se um dia for usada, vem de `GOOGLE_PLACES_API_KEY` no ambiente
  ou num arquivo `.env` (veja `.env.example`) e é removida dos logs.

## Segurança
- Entradas validadas (tamanho, caracteres de controle, raio, estado); `%` e `_` digitados na busca valem como texto.
- Verificação de sites: só http/https nas portas 80, 443, 8080 e 8443; bloqueia endereços internos em cada
  redirecionamento; limita tempo, redirecionamentos e tamanho; não contorna CAPTCHA. Limitação conhecida: o endereço é
  checado antes da conexão, então um servidor DNS malicioso ainda poderia trocar a resposta entre as duas etapas.
- Links abertos pelo app: só http/https. Exportação: neutraliza injeção de fórmula e grava de forma atômica.
- Logs em `prospector.log` (rotação de 1 MB x 3), sem chaves/senhas e sem o endereço de cada site consultado.
- O banco usa modo WAL: a tela continua respondendo enquanto a pesquisa grava em segundo plano.
- Fechar a janela com tarefa em andamento cancela a tarefa e espera a thread terminar.

## Limitações conhecidas
- A mesma empresa pode aparecer duas vezes se estiver na Receita **e** no OpenStreetMap (fontes diferentes não são unidas).
- A busca por texto ignora maiúsculas apenas em letras sem acento ("sao paulo" não acha "São Paulo").

## Empacotamento (Windows)
- `build.bat` (ou `.\build.ps1`): cria um ambiente isolado, roda os testes, gera `dist\Prospector\Prospector.exe` com o
  PyInstaller (modo pasta, sem janela de terminal), roda o autoteste do programa empacotado e cria
  `dist\Prospector-<versão>-windows.zip` com o manual incluído. Use `-SkipTests` para pular os testes.
- Autoteste: `Prospector.exe --self-test` confere banco, exportações, HTTPS/certificados, ícone e janela, usando uma
  pasta temporária (não toca nos seus dados). O relatório fica em `%TEMP%\prospector-selftest.txt`.
- Instalador opcional: `packaging\installer.iss` (Inno Setup). Ao mudar a versão em `src\prospector\__init__.py`,
  mude também em `pyproject.toml` e no `.iss` (um teste confere).
- O programa não é assinado digitalmente, então o SmartScreen do Windows pode avisar na primeira execução.
