// Evita a janela de terminal no Windows em builds de release.
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use std::sync::Mutex;

use tauri::{Manager, RunEvent, State};
use tauri_plugin_shell::process::{CommandChild, CommandEvent};
use tauri_plugin_shell::ShellExt;

/// Prefixo da linha que o motor Python imprime quando está pronto: PROSPECTOR_READY {"port":1234,"token":"..."}
const READY_PREFIX: &str = "PROSPECTOR_READY ";

#[derive(Default)]
struct Backend {
    /// JSON com porta e token, recebido do motor.
    info: Mutex<Option<String>>,
    /// Processo do motor, para encerrá-lo junto com a janela.
    child: Mutex<Option<CommandChild>>,
}

/// A página chama este comando até receber a porta e o token do motor.
#[tauri::command]
fn backend_info(state: State<'_, Backend>) -> Option<String> {
    state.info.lock().unwrap().clone()
}

fn main() {
    let app = tauri::Builder::default()
        .plugin(tauri_plugin_shell::init())
        .manage(Backend::default())
        .setup(|app| {
            // "prospector-api" = nome em bundle.externalBin, sem a pasta e sem o sufixo da arquitetura.
            let (mut rx, child) = app.shell().sidecar("prospector-api")?.spawn()?;
            *app.state::<Backend>().child.lock().unwrap() = Some(child);

            let handle = app.handle().clone();
            tauri::async_runtime::spawn(async move {
                while let Some(event) = rx.recv().await {
                    if let CommandEvent::Stdout(bytes) = event {
                        let line = String::from_utf8_lossy(&bytes);
                        if let Some(json) = line.trim().strip_prefix(READY_PREFIX) {
                            *handle.state::<Backend>().info.lock().unwrap() = Some(json.to_string());
                        }
                    }
                }
            });
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![backend_info])
        .build(tauri::generate_context!())
        .expect("erro ao iniciar o Prospector");

    app.run(|handle, event| {
        if let RunEvent::Exit = event {
            // Garante que o motor Python não fique rodando depois que a janela fecha.
            if let Some(child) = handle.state::<Backend>().child.lock().unwrap().take() {
                let _ = child.kill();
            }
        }
    });
}
