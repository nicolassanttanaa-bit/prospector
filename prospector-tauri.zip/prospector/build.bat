@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build.ps1" %*
if errorlevel 1 (
  echo.
  echo A construcao falhou. Leia a mensagem acima.
  pause
  exit /b 1
)
echo.
echo Pronto! O programa esta em dist\Prospector\Prospector.exe
pause
