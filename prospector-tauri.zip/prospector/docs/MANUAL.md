# Prospector — manual de instalação e uso (versão 1.1)

O Prospector ajuda a encontrar as empresas de uma cidade e destacar as que **aparentemente não têm site**, para você
oferecer seus serviços de desenvolvimento. Ele organiza o contato com cada empresa, mas **não envia mensagens sozinho**.

## 1. Instalação

### Opção A — instalador pronto (Windows)
Execute `Prospector_1.1.0_x64-setup.exe`. A instalação é só para o seu usuário (não pede administrador). Se o Windows
mostrar "O Windows protegeu o computador": o programa não tem assinatura digital paga, então o SmartScreen avisa para
qualquer programa novo. Clique em **Mais informações** e depois em **Executar assim mesmo**, **somente se você recebeu
o instalador de uma fonte em que confia** (ou se foi você quem o gerou).

### Opção B — gerar o instalador a partir do código
Requisitos (uma vez): Python 3.10+, [Rust](https://rustup.rs) e as *Ferramentas de Build do Visual Studio* com
"Desenvolvimento para desktop com C++" (veja https://v2.tauri.app/start/prerequisites/). O WebView2 já vem no Windows 10/11
atualizado. Depois, dê dois cliques em `build-desktop.bat`: ele roda os testes, empacota o motor Python, confere o motor
empacotado e gera o instalador em `desktop\src-tauri\target\release\bundle\nsis`. A primeira vez demora (o Rust compila tudo).

### Opção C — modo navegador (sem instalar Rust)
```
pip install -e .
python -m prospector.api --browser
```
Abre a **mesma interface** no seu navegador. Ao fechar a aba, o motor encerra sozinho em cerca de 2 minutos.

### Opção D — versão clássica (janela Qt)
`build.bat` gera a versão antiga em lista/tabela. Ela continua funcionando, mas não tem a interface nova.

## 2. Primeiros passos: configurar as fontes
Clique em **⚙ Configurações** (canto inferior esquerdo). O programa usa duas fontes gratuitas, sem chave de API:

- **OpenStreetMap:** funciona sozinho (precisa de internet). A cobertura de pequenos negócios varia por cidade.
- **Receita Federal (CNPJ):** cobre empresas formais, mas exige baixar arquivos uma vez (link na própria tela). Baixe
  **Estabelecimentos0 a 9** e **Municipios** (e, se quiser nomes de negócios sem nome fantasia, **Empresas0 a 9**),
  salve todos os `.zip` numa pasta, **sem extrair**, cole o caminho dela em Configurações e salve. São alguns GB.

## 3. Fazer uma pesquisa
No painel **à esquerda**, preencha **Cidade**, **Estado (UF)** e **Categoria** (escolha da lista ou digite; para outra
atividade, use o código CNAE, ex.: `5611-2/03`) e clique em **Pesquisar**. O **raio** (km) é opcional e só vale para o
OpenStreetMap; a Receita sempre pesquisa a cidade inteira. Dá para **cancelar** a qualquer momento.

- **Cada pesquisa mostra só a cidade pesquisada.** Pesquisas diferentes não se misturam.
- Ao terminar, os sites são verificados automaticamente (a barra mostra o andamento).
- Em **Pesquisas recentes** você reabre os resultados de qualquer pesquisa anterior. O **✕** exclui a pesquisa do
  histórico (clique duas vezes para confirmar); as empresas, suas notas e contatos continuam salvos.

## 4. Entender os cartões
Cada empresa é um cartão quadrado com quatro bolinhas:

| Bolinha | Verde ✓ | Vermelha ✕ | Cinza ? |
|---|---|---|---|
| **Site** | tem site | sem site identificado | ainda não verificado ou inconclusivo |
| **Tel.** | tem telefone | sem telefone | — |
| **Insta** | tem Instagram | sem Instagram | — |
| **Face** | tem Facebook | sem Facebook | — |

O botão **›** ao lado das bolinhas (ou um clique no cartão) abre o painel **Ver mais**. No topo, os números resumem a
pesquisa (não são filtros): total de empresas, sem site, com site e a confirmar.

**Atenção:** "sem site identificado" **não prova** que a empresa não tenha site. Confira antes de abordar (o painel tem
botões para o Google Maps, Google e busca do Instagram). Quanto menor a confiança, mais vale conferir.

## 5. Lojas repetidas
O programa **não repete lojas**: registros com o mesmo nome na mesma cidade e estado viram **um só cartão**, com o selo
"N unidades" (redes e franquias) — e o painel lista cada unidade. A mesma loja encontrada nas duas fontes (Receita e
OpenStreetMap) também vira um cartão só, com os dados das duas somados. Limite: dois negócios independentes com o
**mesmo nome** na mesma cidade também ficam juntos; o selo "unidades" avisa, e as unidades aparecem no painel.
Nomes diferentes para a mesma loja (ex.: "Lanchonete do Zé" e "Zé Lanches") não são unidos.

## 6. Painel "Ver mais"
Mostra telefone, links, **situação do site** (confiança, evidências, quando foi verificado) e as unidades. Aqui você
também pode:

- **Gestão comercial:** marcar **favorita**, definir o **status** (novo lead → … → cliente fechado), escrever **notas**
  e **registrar contatos** (canal, resumo e data). O primeiro contato muda "novo lead" para "primeiro contato".
- **Corrigir informações:** editar site, Instagram e Facebook e **definir a situação do site** (confiança de 100%).
  Links que você informa não são sobrescritos por pesquisas futuras.

Clique em **Salvar alterações** para guardar. "Registrar contato" grava na hora.

## 7. Exportar
**Exportar ▾** (no topo dos resultados) grava as empresas **da pesquisa aberta** em Excel, CSV (ponto e vírgula, abre
direto no Excel brasileiro, ou vírgula) ou JSON, na pasta `Downloads\Prospector`. O aviso mostra o caminho e o botão
**Mostrar na pasta**. Os arquivos trazem a fonte de cada dado e a atribuição exigida.

## 8. Onde ficam seus dados
Em `C:\Users\SEU_USUARIO\.prospector`: banco (`prospector.db`), preferências e o log (`prospector.log`). Para **backup**,
feche o programa e copie essa pasta. Para **desinstalar**, use "Aplicativos" do Windows e, se quiser, apague essa pasta.
Para mudar o local, defina a variável de ambiente `PROSPECTOR_DATA_DIR`.

## 9. Privacidade e uso responsável
- Os dados vêm de fontes públicas e abertas; o programa não usa scraping nem contorna proteções de sites.
- Telefones de empresas (principalmente MEI) podem ser dados pessoais. Use para **contato comercial pontual**,
  respeite pedidos de remoção e a LGPD, e evite disparos em massa.
- A internet é usada só para: OpenStreetMap, verificar se os sites respondem e abrir os links que você clicar.
- O motor local só aceita conexões do próprio computador e exige um código de acesso gerado a cada abertura.

## 10. Problemas comuns
| Sintoma | O que fazer |
|---|---|
| "O motor do Prospector não iniciou" | Feche e abra o programa. Se persistir, o antivírus pode estar bloqueando `prospector-api.exe` (na pasta de instalação): libere-o e veja o `prospector.log`. |
| "Escolha o estado (UF)" | O estado é obrigatório: evita misturar cidades com o mesmo nome. |
| Receita ✕ (configurar) | Abra Configurações e escolha a pasta com `Municipios.zip` e `Estabelecimentos*.zip`. |
| "arquivo … corrompido ou incompleto" | Baixe esse arquivo da Receita novamente. |
| OpenStreetMap: "limite de tempo" | Tente um raio menor ou aguarde alguns minutos. |
| Muitas bolinhas cinzas no Site | A verificação ainda está rodando ou faltou internet; refaça a pesquisa depois. |
| Qualquer outro problema | Veja `prospector.log` (Configurações mostra a pasta). O motor tem autoteste: `prospector-api.exe --self-test`. |

## 11. Limites
Nenhuma fonte lista todas as empresas, principalmente as informais. O Google Maps/Places (pago) não está incluído.
