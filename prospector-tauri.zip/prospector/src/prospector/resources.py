from __future__ import annotations

from pathlib import Path


def asset(name: str) -> Path:
    """Caminho de um arquivo em prospector/assets (funciona também no programa empacotado)."""
    return Path(__file__).resolve().parent / "assets" / name
