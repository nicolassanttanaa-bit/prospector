from __future__ import annotations

import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from typing import Callable

from prospector.database.repository import CompanyRepository
from prospector.integrations.base import SourceUnavailable
from prospector.integrations.site_checker import SiteChecker
from prospector.models.company import SiteStatus
from prospector.services.site_classifier import Subject, classify

log = logging.getLogger(__name__)


@dataclass
class VerifyResult:
    total: int = 0
    done: int = 0
    no_site: int = 0
    has_site: int = 0
    inconclusive: int = 0
    errors: int = 0
    cancelled: bool = False


def verify_companies(repo: CompanyRepository, checker: SiteChecker,
                     progress: Callable[[int, str, int], None] | None = None,
                     cancelled: Callable[[], bool] | None = None,
                     only_unchecked: bool = True, max_workers: int = 8, search_id: int | None = None) -> VerifyResult:
    progress = progress or (lambda p, m, d: None)
    cancelled = cancelled or (lambda: False)
    rows = repo.companies_to_check(only_unchecked, search_id)
    res = VerifyResult(total=len(rows))
    if not rows:
        return res
    progress(-1, "Verificando a conexão com a internet…", 0)
    if not checker.has_internet():
        raise SourceUnavailable("Sem conexão com a internet (ou DNS indisponível). "
                                "Sem isso, nenhuma empresa seria classificada corretamente. Tente novamente.")
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures = {ex.submit(classify, Subject(r["name"], r["city"], r["phone"], r["website"],
                                               r["instagram"], r["facebook"]), checker): r["id"] for r in rows}
        for fut in as_completed(futures):
            if cancelled():
                res.cancelled = True
                ex.shutdown(wait=False, cancel_futures=True)
                break
            try:
                c = fut.result()
            except Exception:  # noqa: BLE001 - uma empresa com erro não pára as demais
                log.exception("Erro ao verificar empresa %s", futures[fut])
                res.errors += 1
                continue
            repo.save_site_check(futures[fut], c.status, c.confidence, c.site_state.value if c.site_state else None,
                                 c.site_url, " | ".join(c.notes), c.instagram, c.facebook, commit=False)
            res.done += 1
            res.no_site += c.status == SiteStatus.NO_SITE
            res.has_site += c.status == SiteStatus.HAS_SITE
            res.inconclusive += c.status == SiteStatus.INCONCLUSIVE
            if res.done % 25 == 0:
                repo.conn.commit()
            progress(int(100 * (res.done + res.errors) / res.total),
                     f"Verificando sites… {res.done}/{res.total}", res.done)
    repo.conn.commit()
    progress(100, "Verificação cancelada." if res.cancelled else "Verificação concluída.", res.done)
    return res
