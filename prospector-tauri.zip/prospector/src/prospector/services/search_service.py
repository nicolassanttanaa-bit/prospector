from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Callable

from prospector.database.repository import CompanyRepository
from prospector.integrations.base import CompanySource, SearchQuery, SourceError
from prospector.integrations.osm import OsmSource
from prospector.integrations.receita import ReceitaSource

log = logging.getLogger(__name__)
# progress(percentual ou -1 se indeterminado, mensagem, total encontrado até agora)
SearchProgress = Callable[[int, str, int], None]


@dataclass
class SearchResult:
    found: int = 0
    new: int = 0
    per_source: dict[str, int] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)
    cancelled: bool = False


def build_sources(prefs) -> list[CompanySource]:
    sources: list[CompanySource] = []
    if prefs.use_receita:
        sources.append(ReceitaSource(prefs.receita_dir or None))
    if prefs.use_osm:
        sources.append(OsmSource())
    return sources


class SearchService:
    def __init__(self, repo: CompanyRepository, sources: list[CompanySource]):
        self.repo, self.sources = repo, sources

    def run(self, query: SearchQuery, progress: SearchProgress | None = None,
            cancelled: Callable[[], bool] | None = None, search_id: int | None = None) -> SearchResult:
        progress = progress or (lambda p, m, f: None)
        cancelled = cancelled or (lambda: False)
        if not self.sources:
            raise ValueError("Nenhuma fonte ativa. Ative ao menos uma em Configurações.")
        result, n = SearchResult(), len(self.sources)
        seen: set[int] = set()   # empresas distintas desta pesquisa
        for i, source in enumerate(self.sources):
            if cancelled():
                result.cancelled = True
                break
            base, last = 100 * i / n, [int(100 * i / n)]

            def cb(pct, msg, _b=base):
                last[0] = -1 if pct is None else int(_b + pct / n)
                progress(last[0], msg, len(seen))

            count = 0
            try:
                for data in source.search(query, cb, cancelled):
                    company_id, created = self.repo.upsert_ex(data, commit=False)
                    result.new += created
                    if search_id is not None:
                        self.repo.link_result(search_id, company_id)
                    seen.add(company_id)
                    count += 1
                    result.found = len(seen)
                    if count % 25 == 0:
                        progress(last[0], f"{source.label}: {count} registros, {len(seen)} empresas", len(seen))
            except SourceError as e:
                result.warnings.append(f"{source.label}: {e}")
            except Exception:  # noqa: BLE001 - a pesquisa continua com as outras fontes
                log.exception("Erro inesperado na fonte %s", source.name)
                result.warnings.append(f"{source.label}: erro inesperado (detalhes no arquivo de log).")
            finally:
                self.repo.conn.commit()
            result.per_source[source.name] = count
            self.repo.add_search_history(query.city, query.category.name, query.radius_km, source.name, count)
            if cancelled():
                result.cancelled = True
                break
        progress(100, "Pesquisa cancelada." if result.cancelled else "Concluído.", len(seen))
        return result
