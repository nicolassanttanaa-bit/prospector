"""Classifica uma empresa em A (sem site identificado), B (possui site) ou C (inconclusivo)."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from urllib.parse import urlsplit

from prospector.integrations.site_checker import FetchResult, SiteChecker, SiteState
from prospector.integrations.textutil import normalize
from prospector.models.company import SiteStatus
from prospector.models.names import GENERIC, STOP, distinctive_tokens  # noqa: F401

PARKED = ("DOMAIN IS FOR SALE", "DOMINIO A VENDA", "DOMINIO ESTA A VENDA", "COMPRE ESTE DOMINIO",
          "BUY THIS DOMAIN", "SEDOPARKING", "HUGEDOMAINS", "PARKED DOMAIN")
TLDS = (".com.br", ".com")
SOCIAL_HOSTS = {"instagram.com": "instagram", "facebook.com": "facebook", "fb.com": "facebook", "fb.me": "facebook"}
AGGREGATORS = ("linktr.ee", "linktree", "beacons.ai", "wa.me", "whatsapp.com", "ifood.com.br", "rappi.com",
               "tiktok.com", "youtube.com", "youtu.be", "x.com", "twitter.com", "linkedin.com", "tripadvisor",
               "maps.app.goo.gl", "goo.gl", "google.com", "olx.com.br", "mercadolivre.com.br", "bit.ly")


@dataclass
class Subject:
    name: str
    city: str | None = None
    phone: str | None = None
    website: str | None = None
    instagram: str | None = None
    facebook: str | None = None


@dataclass
class Classification:
    status: SiteStatus
    confidence: float
    site_state: SiteState | None = None
    site_url: str | None = None
    instagram: str | None = None
    facebook: str | None = None
    notes: list[str] = field(default_factory=list)


def classify_url(raw: str) -> tuple[str, str]:
    """-> (tipo, url normalizada). tipo: instagram | facebook | aggregator | site | invalid"""
    url = raw.strip()
    if not url:
        return "invalid", url
    if "://" not in url:
        url = "https://" + url
    host = (urlsplit(url).hostname or "").lower().removeprefix("www.")
    if "." not in host or " " in host:
        return "invalid", url
    for domain, kind in SOCIAL_HOSTS.items():
        if host == domain or host.endswith("." + domain):
            return kind, url
    if any(host == a or host.endswith("." + a) or a in host for a in AGGREGATORS):
        return "aggregator", url
    return "site", url


def candidate_domains(name: str, limit: int = 6) -> list[str]:
    tokens = [t for t in re.findall(r"[a-z0-9]+", normalize(name).lower()) if t not in {s.lower() for s in {"LTDA", "ME", "EPP", "EIRELI", "MEI", "SA"}}]
    stop, generic = {s.lower() for s in STOP}, {g.lower() for g in GENERIC}
    dist = [t.lower() for t in distinctive_tokens(name)]
    if not dist:
        return []
    slugs = ["".join(tokens), "".join(t for t in tokens if t not in stop), "".join(dist), "".join(dist[:2])]
    out: list[str] = []
    for slug in dict.fromkeys(s for s in slugs if len(s) >= 4):
        for tld in TLDS:
            out.append(slug + tld)
    return out[:limit]


def _evidence(subject: Subject, text: str) -> tuple[float, bool, bool, bool]:
    """-> (proporção do nome encontrada, cidade encontrada, telefone encontrado, página estacionada)"""
    norm = normalize(text)
    tokens = distinctive_tokens(subject.name)
    ratio = sum(t in norm for t in tokens) / len(tokens) if tokens else 0.0
    city = bool(subject.city) and len(subject.city) >= 3 and normalize(subject.city) in norm
    digits = re.sub(r"\D", "", subject.phone or "")
    phone = len(digits) >= 8 and digits[-8:] in re.sub(r"\D", "", text)
    return ratio, city, phone, any(p in norm for p in PARKED)


def _from_listed_site(url: str, fr: FetchResult, base: Classification) -> Classification:
    base.site_state, base.site_url = fr.state, url
    s = fr.state
    if s in (SiteState.WORKING, SiteState.REDIRECTED):
        base.status, base.confidence = SiteStatus.HAS_SITE, 0.95
        base.notes.append("Site informado pela fonte responde normalmente.")
    elif s in (SiteState.UNAVAILABLE, SiteState.CONNECTION_ERROR):
        base.status, base.confidence = SiteStatus.HAS_SITE, 0.6
        base.notes.append("Site informado pela fonte, mas fora do ar no momento da verificação (pode ser temporário).")
    elif s == SiteState.INCONCLUSIVE:
        base.status, base.confidence = SiteStatus.HAS_SITE, 0.7
        base.notes.append("Site informado pela fonte responde com erro ou proteção anti-robô; não foi possível verificar.")
    else:
        base.status, base.confidence = SiteStatus.INCONCLUSIVE, 0.4
        base.notes.append("O domínio informado pela fonte não existe ou é inválido — o dado pode estar desatualizado.")
    return base


def classify(subject: Subject, checker: SiteChecker) -> Classification:
    out = Classification(SiteStatus.INCONCLUSIVE, 0.0, instagram=None, facebook=None)
    own_site = None
    if subject.website and subject.website.strip():
        kind, url = classify_url(subject.website)
        if kind == "instagram":
            out.instagram = url; out.notes.append("O campo de site era um Instagram (rede social, não site próprio).")
        elif kind == "facebook":
            out.facebook = url; out.notes.append("O campo de site era um Facebook (rede social, não site próprio).")
        elif kind == "aggregator":
            out.notes.append(f"O campo de site aponta para {urlsplit(url).hostname} (rede social/agregador, não site próprio).")
        elif kind == "site":
            own_site = url
        else:
            out.status, out.confidence = SiteStatus.INCONCLUSIVE, 0.3
            out.notes.append("O endereço de site informado é inválido."); return out
    if own_site:
        return _from_listed_site(own_site, checker.fetch(own_site), out)

    has_social = bool(subject.instagram or subject.facebook or out.instagram or out.facebook or
                      any("rede social" in n for n in out.notes))
    tested = temp_fail = 0
    weak_url = None
    for host in candidate_domains(subject.name):
        exists = checker.domain_exists(host)
        if exists is None:
            temp_fail += 1; continue
        tested += 1
        if not exists:
            continue
        fr = checker.fetch("https://" + host)
        if fr.state in (SiteState.CONNECTION_ERROR, SiteState.INVALID_DOMAIN):
            fr = checker.fetch("http://" + host)
        if fr.state not in (SiteState.WORKING, SiteState.REDIRECTED):
            continue
        ratio, city, phone, parked = _evidence(subject, fr.text)
        if parked:
            out.notes.append(f"{host} parece ser um domínio estacionado/à venda (ignorado)."); continue
        if ratio >= 0.75 and (city or phone):
            out.status, out.confidence, out.site_state, out.site_url = SiteStatus.HAS_SITE, 0.75, fr.state, fr.final_url
            out.notes.append(f"Site provável encontrado por tentativa de domínio ({host}): nome e "
                             f"{'cidade' if city else 'telefone'} conferem. Estimado — confirme manualmente.")
            return out
        if ratio >= 0.75 and weak_url is None:
            weak_url = (fr.final_url, fr.state)
    if weak_url:
        out.status, out.confidence, out.site_url, out.site_state = SiteStatus.INCONCLUSIVE, 0.4, weak_url[0], weak_url[1]
        out.notes.append("Existe um domínio com nome parecido, mas sem confirmação de cidade/telefone. Confira manualmente.")
        return out
    if temp_fail and not tested:
        out.status, out.confidence = SiteStatus.INCONCLUSIVE, 0.3
        out.notes.append("Falha temporária de DNS; tente verificar novamente mais tarde."); return out
    out.status = SiteStatus.NO_SITE
    if tested:
        out.confidence = 0.55
        out.notes.append(f"Nenhum site informado pela fonte e {tested} domínios prováveis testados sem resultado.")
    else:
        out.confidence = 0.4
        out.notes.append("Nenhum site informado pela fonte; o nome é genérico demais para testar domínios prováveis.")
    if has_social:
        out.confidence = min(out.confidence + 0.1, 0.65)
        out.notes.append("Possui presença em rede social — bom sinal de que opera sem site próprio.")
    out.notes.append("Ausência de site nos dados não prova que ele não exista.")
    return out
