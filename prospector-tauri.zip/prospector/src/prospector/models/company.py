from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class SiteStatus(str, Enum):
    NO_SITE = "sem_site_identificado"   # Categoria A
    HAS_SITE = "possui_site"            # Categoria B
    INCONCLUSIVE = "inconclusivo"       # Categoria C


class LeadStatus(str, Enum):
    NEW = "novo_lead"
    NOT_CONTACTED = "nao_contatado"
    FIRST_CONTACT = "primeiro_contato"
    AWAITING = "aguardando_resposta"
    INTERESTED = "interessado"
    NEGOTIATING = "negociacao"
    CLOSED_WON = "cliente_fechado"
    NOT_INTERESTED = "nao_interessado"


# "Contatada" = qualquer status depois de ainda não contatado.
CONTACTED = (LeadStatus.FIRST_CONTACT, LeadStatus.AWAITING, LeadStatus.INTERESTED,
             LeadStatus.NEGOTIATING, LeadStatus.CLOSED_WON, LeadStatus.NOT_INTERESTED)
IN_PROGRESS = (LeadStatus.FIRST_CONTACT, LeadStatus.AWAITING,
               LeadStatus.INTERESTED, LeadStatus.NEGOTIATING)


@dataclass
class CompanyData:
    """Dados vindos de uma fonte. source + source_id identificam a empresa (sem duplicar)."""
    source: str            # ex.: "receita_cnpj", "osm", "manual"
    source_id: str         # ex.: CNPJ completo, id do OSM
    name: str
    category: str | None = None
    address: str | None = None
    city: str | None = None
    state: str | None = None
    phone: str | None = None
    website: str | None = None
    instagram: str | None = None
    facebook: str | None = None
    maps_url: str | None = None
    rating: float | None = None
    rating_count: int | None = None
    lat: float | None = None
    lng: float | None = None
