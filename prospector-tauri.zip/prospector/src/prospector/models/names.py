"""Normalização de nomes de empresas: palavras genéricas, palavras distintivas e a "chave de marca"
usada para não repetir a mesma loja (ou as várias unidades de uma rede) na lista."""
from __future__ import annotations

import re

from prospector.integrations.textutil import normalize

STOP = {"DE", "DO", "DA", "DOS", "DAS", "E", "LTDA", "ME", "EPP", "EIRELI", "MEI", "SA", "CIA", "O", "A"}
GENERIC = {"LANCHONETE", "LANCHE", "LANCHES", "RESTAURANTE", "PIZZARIA", "BARBEARIA", "SALAO", "BELEZA", "CLINICA",
           "ODONTOLOGIA", "ACADEMIA", "OFICINA", "MECANICA", "PET", "SHOP", "LOJA", "LOJAS", "IMOBILIARIA",
           "CONTABILIDADE", "ESCRITORIO", "ADVOCACIA", "ADVOGADOS", "AUTO", "CENTER", "CENTRO", "COMERCIO",
           "SERVICOS", "BAR", "STUDIO"}
LEGAL = {"LTDA", "ME", "EPP", "EIRELI", "MEI", "SA", "CIA"}
SEPARATORS = (" - ", " – ", " — ", " | ", " / ")


def distinctive_tokens(name: str) -> list[str]:
    seen: list[str] = []
    for t in re.findall(r"[A-Z0-9]+", normalize(name)):
        if t not in STOP and t not in GENERIC and len(t) >= 3 and t not in seen:
            seen.append(t)
    return seen


def brand_key(name: str | None) -> str | None:
    """Chave igual para "Ragazzo", "RAGAZZO LTDA", "Ragazzo (Cambuí)" e "Ragazzo - Shopping Iguatemi".
    Nomes só com palavras genéricas ou curtas demais mantêm o nome inteiro (evita juntar lojas diferentes)."""
    text = normalize(name or "")
    text = re.sub(r"\([^)]*\)", " ", text)
    for sep in SEPARATORS:
        if sep in text:
            left = text.split(sep, 1)[0]
            if distinctive_tokens(left):
                text = left
            break
    tokens = [t for t in re.findall(r"[A-Z0-9]+", text) if t not in LEGAL]
    return " ".join(tokens) or None
