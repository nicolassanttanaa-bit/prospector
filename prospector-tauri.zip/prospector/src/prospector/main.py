from __future__ import annotations

import sqlite3
import sys

from PySide6.QtCore import QCoreApplication, QEvent
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QApplication, QMessageBox

from prospector.config.logging_setup import install_excepthook, setup_logging
from prospector.config.prefs import Prefs
from prospector.config.settings import Settings
from prospector.database.db import connect
from prospector.database.repository import CompanyRepository
from prospector.interface.main_window import MainWindow
from prospector.resources import asset


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if "--self-test" in argv:                    # confere o programa empacotado, sem tocar nos dados do usuário
        from prospector.selftest import run_self_test
        return run_self_test()
    app = QApplication.instance() or QApplication(sys.argv)
    app.setWindowIcon(QIcon(str(asset("icon.png"))))
    try:
        settings = Settings.load()
        setup_logging(settings.data_dir)
        conn = connect(settings.db_path)
    except (OSError, sqlite3.Error) as e:
        QMessageBox.critical(None, "Prospector", "Não foi possível abrir a pasta de dados ou o banco de dados.\n\n"
                             f"{e}\n\nDefina a variável PROSPECTOR_DATA_DIR com uma pasta onde você tenha "
                             "permissão de escrita.")
        return 1
    install_excepthook(lambda msg: QMessageBox.critical(None, "Prospector", msg))
    window = MainWindow(CompanyRepository(conn), settings, Prefs.load(settings.prefs_path))
    window.show()
    code = app.exec()
    window.deleteLater()
    QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
    conn.close()
    return code


if __name__ == "__main__":
    sys.exit(main())
