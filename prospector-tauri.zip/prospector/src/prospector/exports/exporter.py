"""Exportação para CSV, Excel e JSON.
Segurança: células de texto que começam com = + - @ são neutralizadas (injeção de fórmula em planilhas) e o arquivo
é gravado primeiro num temporário e só então substitui o destino (nunca deixa um arquivo pela metade)."""
from __future__ import annotations

import csv
import json
import os
import re
from datetime import datetime
from pathlib import Path

from prospector.database.repository import CompanyFilter, CompanyRepository
from prospector.interface.labels import (LEAD_LABELS, SITE_LABELS, SITE_STATE_LABELS, SOURCE_LABELS, fmt_local,
                                         site_label)
from prospector.interface.links import maps_url

APP_NAME = "Prospector"
# (rótulo no diálogo de salvar, formato, extensão)
FORMATS = [("Excel (*.xlsx)", "xlsx", ".xlsx"),
           ("CSV — ponto e vírgula, abre direto no Excel brasileiro (*.csv)", "csv_semicolon", ".csv"),
           ("CSV — vírgula (*.csv)", "csv_comma", ".csv"),
           ("JSON (*.json)", "json", ".json")]
ATTRIBUTION = {"osm": "© contribuidores do OpenStreetMap (licença ODbL)",
               "receita_cnpj": "Dados Abertos do CNPJ — Receita Federal do Brasil"}
PHONE_RE = re.compile(r"\+?[\d\s().\-]{6,}")


class ExportError(Exception):
    """Falha de exportação com mensagem pronta para o usuário."""


def _dt(row, key: str, machine: bool):
    iso = row[key]
    return None if not iso else (iso if machine else fmt_local(iso))


def _yes_no(value: bool, machine: bool):
    return bool(value) if machine else ("Sim" if value else "Não")


# (chave JSON, cabeçalho CSV/Excel, função (linha, machine) -> valor)
FIELDS = [
    ("nome", "Nome", lambda r, m: r["name"]),
    ("categoria", "Categoria", lambda r, m: r["category"]),
    ("endereco", "Endereço", lambda r, m: r["address"]),
    ("cidade", "Cidade", lambda r, m: r["city"]),
    ("estado", "Estado", lambda r, m: r["state"]),
    ("unidades", "Unidades (lojas)", lambda r, m: r["unit_count"]),
    ("telefone", "Telefone", lambda r, m: r["phone"]),
    ("site_informado", "Site informado pela fonte", lambda r, m: r["website"]),
    ("site_verificado_ou_provavel", "Site verificado/provável", lambda r, m: r["site_url"]),
    ("instagram", "Instagram", lambda r, m: r["instagram"]),
    ("facebook", "Facebook", lambda r, m: r["facebook"]),
    ("link_google_maps", "Link Google Maps (busca)", lambda r, m: maps_url(r["name"], r["city"], r["state"])),
    ("avaliacao", "Avaliação no Google", lambda r, m: r["rating"]),
    ("qtde_avaliacoes", "Qtde. de avaliações", lambda r, m: r["rating_count"]),
    ("situacao_site", "Situação do site", lambda r, m: site_label(r)),
    ("confianca_percentual", "Confiança (%)",
     lambda r, m: round(r["site_confidence"] * 100) if r["site_checked_at"] and r["site_confidence"] is not None else None),
    ("estado_tecnico_site", "Estado técnico do site",
     lambda r, m: SITE_STATE_LABELS.get(r["site_state"], r["site_state"]) if r["site_state"] else None),
    ("evidencias", "Evidências", lambda r, m: r["site_evidence"]),
    ("ultima_verificacao_site", "Última verificação do site", lambda r, m: _dt(r, "site_checked_at", m)),
    ("fonte", "Fonte dos dados", lambda r, m: SOURCE_LABELS.get(r["source"], r["source"])),
    ("atribuicao", "Atribuição da fonte", lambda r, m: ATTRIBUTION.get(r["source"])),
    ("descoberta_em", "Descoberta em", lambda r, m: _dt(r, "discovered_at", m)),
    ("status_comercial", "Status comercial", lambda r, m: LEAD_LABELS.get(r["lead_status"], r["lead_status"])),
    ("favorita", "Favorita", lambda r, m: _yes_no(r["favorite"], m)),
    ("ultimo_contato", "Último contato", lambda r, m: _dt(r, "last_contact_at", m)),
    ("notas", "Notas", lambda r, m: r["notes"] or None),
    ("links_editados_pelo_usuario", "Links editados pelo usuário", lambda r, m: _yes_no(r["links_confirmed"], m)),
]
HEADERS = {key: header for key, header, _ in FIELDS}


def build_record(row, machine: bool = False) -> dict:
    """machine=True (JSON): datas ISO/UTC, booleanos reais e códigos internos de status."""
    rec = {key: fn(row, machine) for key, _, fn in FIELDS}
    if machine:
        rec["situacao_site_codigo"] = row["site_status"] if row["site_checked_at"] else "nao_verificada"
        rec["status_comercial_codigo"] = row["lead_status"]
    return rec


def describe_filter(f: CompanyFilter) -> str:
    parts = []
    if f.text: parts.append(f'busca "{f.text}"')
    if f.site_status: parts.append("situação do site: " + SITE_LABELS[f.site_status.value])
    if f.site_checked is not None: parts.append("site verificado" if f.site_checked else "site não verificado")
    if f.only_with_phone: parts.append("com telefone")
    if f.only_with_instagram: parts.append("com Instagram")
    if f.min_rating is not None: parts.append(f"avaliação mínima {f.min_rating:g}")
    if f.category: parts.append(f'categoria "{f.category}"')
    if f.city: parts.append(f'cidade "{f.city}"')
    if f.lead_status: parts.append("status: " + LEAD_LABELS[f.lead_status.value])
    if f.contacted is not None: parts.append("já contatadas" if f.contacted else "ainda não contatadas")
    if f.favorites_only: parts.append("só favoritas")
    return "; ".join(parts) if parts else "sem filtros"


def _notices(filter_description: str) -> list[str]:
    return [f"Gerado pelo {APP_NAME} em {datetime.now().strftime('%d/%m/%Y %H:%M')}.",
            f"Filtros aplicados: {filter_description}.",
            "Ausência de site nos dados não prova que a empresa não tenha um site: confira antes de abordar.",
            "Dados do OpenStreetMap: © contribuidores do OpenStreetMap, licença ODbL (https://www.openstreetmap.org/copyright).",
            "Dados da Receita Federal: Dados Abertos do CNPJ.",
            "Este arquivo contém telefones de empresas. Use só para contato comercial pontual, respeitando a LGPD "
            "e pedidos de remoção."]


def neutralize(text: str) -> str:
    """Impede que o Excel interprete o texto como fórmula (injeção de fórmula)."""
    if text and text[0] in "=+-@\t\r" and not PHONE_RE.fullmatch(text):
        return "'" + text
    return text


def _csv_cell(value, delimiter: str) -> str:
    if value is None:
        return ""
    if isinstance(value, bool):
        return "Sim" if value else "Não"
    if isinstance(value, float):
        s = repr(round(value, 2))
        return s.replace(".", ",") if delimiter == ";" else s   # Excel pt-BR usa vírgula decimal
    if isinstance(value, int):
        return str(value)
    return neutralize(str(value))


def _write_csv(rows, path: Path, delimiter: str) -> None:
    with open(path, "w", encoding="utf-8-sig", newline="") as fh:     # BOM: o Excel reconhece os acentos
        w = csv.writer(fh, delimiter=delimiter, lineterminator="\r\n")
        w.writerow([h for _, h, _ in FIELDS])
        for r in rows:
            rec = build_record(r)
            w.writerow([_csv_cell(rec[k], delimiter) for k, _, _ in FIELDS])


def _write_xlsx(repo: CompanyRepository, rows, path: Path, description: str) -> None:
    from openpyxl import Workbook
    from openpyxl.styles import Font
    wb = Workbook()
    ws = wb.active; ws.title = "Empresas"
    ws.append([h for _, h, _ in FIELDS])
    for cell in ws[1]:
        cell.font = Font(bold=True)
    contacts = wb.create_sheet("Contatos")
    contacts.append(["Empresa", "Data", "Canal", "Resumo"])
    for r in rows:
        rec = build_record(r)
        ws.append([neutralize(v) if isinstance(v, str) else ("Sim" if v is True else "Não" if v is False else v)
                   for v in (rec[k] for k, _, _ in FIELDS)])
        for c in repo.list_contacts(r["id"]):
            contacts.append([neutralize(r["name"]), fmt_local(c["contacted_at"]), neutralize(c["channel"] or ""),
                             neutralize(c["note"] or "")])
    for sheet in (ws, contacts):
        sheet.freeze_panes = "A2"
        sheet.auto_filter.ref = sheet.dimensions
        for col in sheet.columns:
            width = max((len(str(c.value)) for c in col if c.value is not None), default=8)
            sheet.column_dimensions[col[0].column_letter].width = min(max(width + 2, 10), 60)
        for cell in sheet[1]:
            cell.font = Font(bold=True)
    notices = wb.create_sheet("Avisos")
    for line in _notices(description):
        notices.append([line])
    notices.column_dimensions["A"].width = 120
    wb.save(path)


def _write_json(repo: CompanyRepository, rows, path: Path, description: str) -> None:
    companies = []
    for r in rows:
        rec = build_record(r, machine=True)
        rec["historico_de_contatos"] = [{"data": c["contacted_at"], "canal": c["channel"] or None,
                                         "resumo": c["note"] or None} for c in repo.list_contacts(r["id"])]
        companies.append(rec)
    doc = {"aplicativo": APP_NAME, "gerado_em": datetime.now().astimezone().isoformat(timespec="seconds"),
           "total": len(companies), "filtros": description, "avisos": _notices(description)[2:],
           "empresas": companies}
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(doc, fh, ensure_ascii=False, indent=2)


def export_companies(repo: CompanyRepository, rows, path: str | Path, fmt: str, filter_description: str = "sem filtros") -> int:
    """Exporta `rows` (linhas do banco) e devolve quantas empresas foram gravadas."""
    path, rows = Path(path), list(rows)
    writers = {"csv_semicolon": lambda p: _write_csv(rows, p, ";"), "csv_comma": lambda p: _write_csv(rows, p, ","),
               "xlsx": lambda p: _write_xlsx(repo, rows, p, filter_description),
               "json": lambda p: _write_json(repo, rows, p, filter_description)}
    if fmt not in writers:
        raise ExportError(f"Formato de exportação desconhecido: {fmt}.")
    if not path.parent.is_dir():
        raise ExportError("A pasta de destino não existe.")
    tmp = path.with_name(path.name + ".tmp")
    try:
        writers[fmt](tmp)
        os.replace(tmp, path)
    except PermissionError as e:
        raise ExportError("Sem permissão para gravar o arquivo. Se ele estiver aberto no Excel, feche-o e tente de novo.") from e
    except OSError as e:
        raise ExportError(f"Não foi possível gravar o arquivo ({e.strerror or e}).") from e
    finally:
        tmp.unlink(missing_ok=True)
    return len(rows)
