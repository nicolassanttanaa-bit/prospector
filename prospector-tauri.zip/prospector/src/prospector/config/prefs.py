"""Preferências do usuário (prefs.json). Não guarda segredos."""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, fields
from pathlib import Path


@dataclass
class Prefs:
    receita_dir: str = ""
    use_receita: bool = True
    use_osm: bool = True

    @classmethod
    def load(cls, path: Path) -> "Prefs":
        try:
            raw = json.loads(Path(path).read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return cls()
        defaults = cls()
        clean = {f.name: raw[f.name] for f in fields(cls)
                 if f.name in raw and isinstance(raw[f.name], type(getattr(defaults, f.name)))}
        return cls(**clean)

    def save(self, path: Path) -> None:
        Path(path).write_text(json.dumps(asdict(self), indent=2, ensure_ascii=False), encoding="utf-8")
