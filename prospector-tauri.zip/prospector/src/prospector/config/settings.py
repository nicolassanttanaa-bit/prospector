"""Configurações locais. Chaves ficam em variáveis de ambiente ou num arquivo .env, nunca no código."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


def load_dotenv(path: Path) -> None:
    """Lê linhas CHAVE=valor de um .env. Variáveis já definidas no sistema têm prioridade."""
    try:
        text = Path(path).read_text(encoding="utf-8")
    except OSError:
        return
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key, value = key.strip(), value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value


@dataclass(frozen=True)
class Settings:
    data_dir: Path
    google_places_api_key: str | None = None

    @property
    def db_path(self) -> Path:
        return self.data_dir / "prospector.db"

    @property
    def prefs_path(self) -> Path:
        return self.data_dir / "prefs.json"

    @classmethod
    def load(cls) -> "Settings":
        load_dotenv(Path.cwd() / ".env")
        data_dir = Path(os.environ.get("PROSPECTOR_DATA_DIR") or Path.home() / ".prospector")
        data_dir.mkdir(parents=True, exist_ok=True)
        load_dotenv(data_dir / ".env")
        return cls(data_dir=data_dir, google_places_api_key=os.environ.get("GOOGLE_PLACES_API_KEY") or None)
