"""Logs em arquivo com rotação, sem segredos e sem ruído de bibliotecas."""
from __future__ import annotations

import logging
import re
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Callable

_PATTERNS = [(re.compile(r"(?i)\b(key|token|apikey|api_key|password|senha|secret)=([^&\s'\"]+)"), r"\1=***"),
             (re.compile(r"AIza[0-9A-Za-z_\-]{30,}"), "***")]


def redact(text: str) -> str:
    """Esconde chaves de API e senhas que apareçam em mensagens ou tracebacks."""
    for pattern, repl in _PATTERNS:
        text = pattern.sub(repl, text)
    return text


class RedactingFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:   # inclui o traceback
        return redact(super().format(record))


def setup_logging(log_dir: Path) -> Path:
    path = Path(log_dir) / "prospector.log"
    handler = RotatingFileHandler(path, maxBytes=1_000_000, backupCount=3, encoding="utf-8")
    handler.setFormatter(RedactingFormatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
    root = logging.getLogger()
    for old in list(root.handlers):
        root.removeHandler(old); old.close()
    root.addHandler(handler)
    root.setLevel(logging.INFO)
    for noisy in ("httpx", "httpcore"):   # registrariam cada endereço consultado
        logging.getLogger(noisy).setLevel(logging.WARNING)
    return path


def install_excepthook(show_dialog: Callable[[str], None] | None = None) -> None:
    """Erros não tratados vão para o log e geram UM aviso na tela (em vez de falhar em silêncio)."""
    shown = {"done": False}

    def hook(exc_type, exc, tb) -> None:
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc, tb)
            return
        logging.getLogger("prospector").critical("Exceção não tratada", exc_info=(exc_type, exc, tb))
        if show_dialog and not shown["done"]:
            shown["done"] = True
            show_dialog("Ocorreu um erro inesperado. O programa continua aberto, mas se algo parecer errado, "
                        "feche e abra de novo. Os detalhes foram gravados no arquivo de log (prospector.log).")

    sys.excepthook = hook
