"""Prospector: prospecção comercial de empresas sem site identificado."""

__version__ = "1.1.0"
