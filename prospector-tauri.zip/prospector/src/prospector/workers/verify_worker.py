from __future__ import annotations

import logging
from pathlib import Path

from PySide6.QtCore import QObject, Signal, Slot

from prospector.database.db import connect
from prospector.database.repository import CompanyRepository
from prospector.integrations.base import SourceError
from prospector.integrations.site_checker import SiteChecker
from prospector.services.site_service import verify_companies

log = logging.getLogger(__name__)


class VerifyWorker(QObject):
    progress = Signal(int, str, int)
    finished = Signal(object)   # VerifyResult
    failed = Signal(str)

    def __init__(self, db_path: Path, only_unchecked: bool = True):
        super().__init__()
        self.db_path, self.only_unchecked, self._cancel = db_path, only_unchecked, False

    def cancel(self) -> None:
        self._cancel = True

    @Slot()
    def run(self) -> None:
        conn = checker = None
        try:
            conn, checker = connect(self.db_path), SiteChecker()
            res = verify_companies(CompanyRepository(conn), checker,
                                   lambda p, m, d: self.progress.emit(p, m, d), lambda: self._cancel,
                                   self.only_unchecked)
            self.finished.emit(res)
        except SourceError as e:
            self.failed.emit(str(e))
        except Exception:  # noqa: BLE001
            log.exception("Falha na verificação de sites")
            self.failed.emit("Erro inesperado na verificação. Detalhes no arquivo de log.")
        finally:
            if checker:
                checker.close()
            if conn:
                conn.close()
