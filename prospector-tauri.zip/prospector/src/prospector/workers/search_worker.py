from __future__ import annotations

import logging
from dataclasses import replace
from pathlib import Path

from PySide6.QtCore import QObject, Signal, Slot

from prospector.config.prefs import Prefs
from prospector.database.db import connect
from prospector.database.repository import CompanyRepository
from prospector.integrations.base import SearchQuery
from prospector.services.search_service import SearchService, build_sources

log = logging.getLogger(__name__)


class SearchWorker(QObject):
    """Roda a pesquisa fora da thread da interface. Abre a própria conexão SQLite (thread-safe)."""
    progress = Signal(int, str, int)   # percentual (-1 = indeterminado), mensagem, encontradas
    finished = Signal(object)          # SearchResult
    failed = Signal(str)

    def __init__(self, db_path: Path, query: SearchQuery, prefs: Prefs):
        super().__init__()
        self.db_path, self.query, self.prefs = db_path, query, replace(prefs)
        self._cancel = False

    def cancel(self) -> None:
        self._cancel = True

    @Slot()
    def run(self) -> None:
        conn = None
        try:
            conn = connect(self.db_path)
            service = SearchService(CompanyRepository(conn), build_sources(self.prefs))
            result = service.run(self.query, lambda p, m, f: self.progress.emit(p, m, f), lambda: self._cancel)
            self.finished.emit(result)
        except ValueError as e:
            self.failed.emit(str(e))
        except Exception:  # noqa: BLE001
            log.exception("Falha na pesquisa")
            self.failed.emit("Erro inesperado durante a pesquisa. Detalhes no arquivo de log.")
        finally:
            if conn:
                conn.close()
