from __future__ import annotations

from prospector.database.repository import CompanyRepository
from prospector.interface.labels import (LEAD_LABELS, SITE_STATE_LABELS, SOURCE_LABELS, confidence_label,
                                         site_label)
from prospector.interface.links import google_search_url, instagram_search_url, maps_url
from prospector.models.company import SiteStatus


def site_dot(row) -> str:
    """yes = tem site, no = sem site identificado, unknown = inconclusivo ou ainda não verificado."""
    if row["site_checked_at"] is None:
        return "unknown"
    return {SiteStatus.HAS_SITE.value: "yes", SiteStatus.NO_SITE.value: "no"}.get(row["site_status"], "unknown")


def _has(value) -> str:
    return "yes" if value and str(value).strip() else "no"


def card(row) -> dict:
    return {"id": row["id"], "name": row["name"], "category": row["category"], "city": row["city"],
            "state": row["state"], "units": row["unit_count"], "favorite": bool(row["favorite"]),
            "lead_status": row["lead_status"], "lead_label": LEAD_LABELS.get(row["lead_status"], row["lead_status"]),
            "dots": {"site": site_dot(row), "phone": _has(row["phone"]),
                     "instagram": _has(row["instagram"]), "facebook": _has(row["facebook"])}}


def summary(rows) -> dict:
    dots = [site_dot(r) for r in rows]
    return {"total": len(rows), "sem_site": dots.count("no"), "com_site": dots.count("yes"),
            "inconclusivas": dots.count("unknown")}


def search(row) -> dict:
    return {k: row[k] for k in ("id", "created_at", "city", "state", "category", "radius_km", "found", "status")}


def detail(repo: CompanyRepository, row) -> dict:
    checked = row["site_checked_at"] is not None
    return {
        **card(row),
        "address": row["address"], "phone": row["phone"], "website": row["website"],
        "instagram": row["instagram"], "facebook": row["facebook"],
        "rating": row["rating"], "rating_count": row["rating_count"],
        "notes": row["notes"] or "", "last_contact_at": row["last_contact_at"],
        "discovered_at": row["discovered_at"], "links_confirmed": bool(row["links_confirmed"]),
        "source": SOURCE_LABELS.get(row["source"], row["source"]),
        "site": {"label": site_label(row), "checked": checked,
                 "status": row["site_status"] if checked else "unchecked",
                 "confidence": row["site_confidence"] if checked else None,
                 "confidence_label": confidence_label(row["site_confidence"]) if checked else "—",
                 "state_label": SITE_STATE_LABELS.get(row["site_state"], row["site_state"]) if row["site_state"] else None,
                 "evidence": row["site_evidence"], "url": row["site_url"], "checked_at": row["site_checked_at"]},
        "units_list": [{"name": u["name"], "address": u["address"], "phone": u["phone"],
                        "source": SOURCE_LABELS.get(u["source"], u["source"])} for u in repo.list_units(row["id"])],
        "contacts": [{"at": c["contacted_at"], "channel": c["channel"], "note": c["note"]}
                     for c in repo.list_contacts(row["id"])],
        "links": {"maps": maps_url(row["name"], row["city"], row["state"]),
                  "google": google_search_url(row["name"], row["city"]),
                  "instagram_search": instagram_search_url(row["name"], row["city"])},
    }
