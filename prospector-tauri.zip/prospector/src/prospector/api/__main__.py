from prospector.api.cli import main

raise SystemExit(main())
