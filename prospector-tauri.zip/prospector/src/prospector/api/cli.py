"""Ponto de entrada do motor: `prospector-api` (usado como sidecar pelo Tauri) ou `python -m prospector.api`."""
from __future__ import annotations

import argparse
import http.client
import json
import os
import platform
import sys
import tempfile
import threading
import traceback
import webbrowser
from pathlib import Path

from prospector import __version__
from prospector.api.server import ApiServer, static_dir
from prospector.config.logging_setup import setup_logging
from prospector.config.settings import Settings

READY_PREFIX = "PROSPECTOR_READY "


def _self_test() -> int:
    lines = [f"Prospector motor {__version__} — autoteste",
             f"Python {platform.python_version()} em {platform.system()} | empacotado: {bool(getattr(sys, 'frozen', False))}"]
    ok = True

    def step(name, fn):
        nonlocal ok
        try:
            fn()
            lines.append(f"OK      {name}")
        except Exception as e:  # noqa: BLE001
            ok = False
            lines.append(f"FALHOU  {name}: {type(e).__name__}: {e}\n{traceback.format_exc()}")

    def https():
        import certifi
        import httpx
        httpx.Client().close()
        assert Path(certifi.where()).exists(), "pacote de certificados ausente"

    def interface_files():
        for name in ("index.html", "styles.css", "app.js"):
            assert (static_dir() / name).is_file(), f"arquivo da interface ausente: {name}"

    def exports_and_server():
        from openpyxl import Workbook  # noqa: F401  (confere que o módulo está empacotado)
        with tempfile.TemporaryDirectory() as tmp:
            srv = ApiServer(Path(tmp) / "data", token="t", export_dir=Path(tmp) / "exp")
            srv.start_background()
            try:
                def call(token):
                    c = http.client.HTTPConnection("127.0.0.1", srv.port, timeout=5)
                    c.request("GET", "/api/health", headers={"Authorization": f"Bearer {token}"} if token else {})
                    r = c.getresponse(); r.read(); c.close(); return r.status
                assert call(None) == 401 and call("t") == 200, "autenticação da API"
                with srv.repo() as repo:
                    from prospector.models.company import CompanyData
                    from prospector.exports.exporter import export_companies
                    cid = repo.upsert(CompanyData(source="autoteste", source_id="1", name="Registro de autoteste"))
                    sid = repo.create_search("Cidade", "SP", "Categoria", None)
                    repo.link_result(sid, cid); repo.conn.commit()
                    for fmt, ext in (("xlsx", "x.xlsx"), ("csv_semicolon", "x.csv"), ("json", "x.json")):
                        export_companies(repo, repo.search_companies(sid), Path(tmp) / ext, fmt)
                        assert (Path(tmp) / ext).stat().st_size > 0, ext
            finally:
                srv.shutdown()

    step("HTTPS e certificados", https)
    step("arquivos da interface", interface_files)
    step("API local, banco e exportações", exports_and_server)
    lines.append("RESULTADO: " + ("tudo certo." if ok else "HÁ FALHAS (veja acima)."))
    text = "\n".join(lines)
    try:
        (Path(tempfile.gettempdir()) / "prospector-api-selftest.txt").write_text(text, encoding="utf-8")
    except OSError:
        pass
    print(text)
    return 0 if ok else 1


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="prospector-api", description="Motor local do Prospector (API em 127.0.0.1).")
    ap.add_argument("--data-dir", help="Pasta dos dados (padrão: ~/.prospector ou PROSPECTOR_DATA_DIR).")
    ap.add_argument("--port", type=int, default=0, help="Porta (0 = aleatória).")
    ap.add_argument("--idle-timeout", type=float, default=120,
                    help="Encerra após N segundos sem a interface falar com o motor (0 = nunca).")
    ap.add_argument("--browser", action="store_true", help="Modo navegador: serve a interface e abre no navegador.")
    ap.add_argument("--self-test", action="store_true", help="Confere o programa empacotado e sai.")
    args = ap.parse_args(argv)
    if sys.stdout is None:                      # executável sem console: evita quebrar no print
        sys.stdout = open(os.devnull, "w")
    if args.self_test:
        return _self_test()
    data_dir = Path(args.data_dir) if args.data_dir else Settings.load().data_dir
    setup_logging(data_dir)
    server = ApiServer(data_dir, port=args.port, serve_ui=args.browser, idle_timeout=args.idle_timeout)
    print(READY_PREFIX + json.dumps({"port": server.port, "token": server.token}), flush=True)
    if args.browser:
        url = f"http://127.0.0.1:{server.port}/#token={server.token}"
        print(f"Interface em: {url}", flush=True)
        threading.Timer(0.3, webbrowser.open, args=(url,)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.httpd.server_close()
    return 0
