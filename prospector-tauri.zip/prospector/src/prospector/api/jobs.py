"""Uma tarefa em segundo plano por vez (pesquisa ou verificação), com progresso e cancelamento."""
from __future__ import annotations

import logging
import threading
import uuid
from typing import Callable

from prospector.integrations.base import SourceError

log = logging.getLogger(__name__)


class JobRunner:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._thread: threading.Thread | None = None
        self._cancel = threading.Event()
        self._state: dict = {"status": "idle"}

    @property
    def running(self) -> bool:
        with self._lock:
            return self._state.get("status") == "running"

    def snapshot(self) -> dict:
        with self._lock:
            return {**self._state, "warnings": list(self._state.get("warnings", []))}

    def cancel(self) -> None:
        self._cancel.set()

    def start(self, kind: str, fn: Callable, **meta) -> bool:
        """fn(update, cancelled) -> dict com 'warnings' e 'cancelled'. False se já há tarefa rodando."""
        with self._lock:
            if self._state.get("status") == "running":
                return False
            self._cancel.clear()
            self._state = {"id": uuid.uuid4().hex, "kind": kind, "status": "running", "percent": 0,
                           "message": "Iniciando…", "found": 0, "warnings": [], **meta}
        self._thread = threading.Thread(target=self._run, args=(fn,), daemon=True)
        self._thread.start()
        return True

    def _update(self, percent=None, message=None, found=None) -> None:
        with self._lock:
            if self._state.get("status") != "running":
                return
            self._state["percent"] = percent if percent is not None and percent >= 0 else None   # None = indeterminado
            if message is not None:
                self._state["message"] = message
            if found is not None:
                self._state["found"] = found

    def _run(self, fn: Callable) -> None:
        try:
            result = fn(self._update, self._cancel.is_set) or {}
            status = "cancelled" if result.get("cancelled") else "done"
            patch = {"status": status, "percent": 100, "warnings": result.get("warnings", []),
                     "message": "Cancelado." if status == "cancelled" else "Concluído."}
        except (ValueError, SourceError) as e:
            patch = {"status": "error", "message": str(e)}
        except Exception:  # noqa: BLE001
            log.exception("Falha na tarefa em segundo plano")
            patch = {"status": "error", "message": "Erro inesperado. Detalhes no arquivo de log."}
        with self._lock:
            self._state.update(patch)
