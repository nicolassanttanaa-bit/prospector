// Funções utilitárias. As puras (sem DOM) são testadas com Node em tests/test_ui_util.mjs.

/** Cria elementos pela API do DOM, sem montar HTML em texto: nomes vindos de fontes externas nunca são interpretados como HTML. */
export function h(tag, props = {}, ...children) {
  const el = document.createElement(tag);
  for (const [key, value] of Object.entries(props || {})) {
    if (value === false || value == null) continue;
    if (key === 'class') el.className = value;
    else if (key.startsWith('on') && typeof value === 'function') el.addEventListener(key.slice(2), value);
    else if (key === 'text') el.textContent = value;
    else el.setAttribute(key, value === true ? '' : String(value));
  }
  for (const child of children.flat()) {
    if (child == null || child === false) continue;
    el.append(child instanceof Node ? child : document.createTextNode(String(child)));
  }
  return el;
}

/** Troca o conteúdo de um elemento ignorando null/false (replaceChildren transformaria null no texto "null"). */
export function fill(el, ...nodes) {
  el.replaceChildren(...nodes.flat(Infinity).filter((n) => n != null && n !== false));
}

export const KINDS = {
  site: { label: 'Site', short: 'Site', yes: 'tem site', no: 'sem site identificado', unknown: 'não confirmado' },
  phone: { label: 'Telefone', short: 'Tel.', yes: 'tem telefone', no: 'sem telefone', unknown: 'não confirmado' },
  instagram: { label: 'Instagram', short: 'Insta', yes: 'tem Instagram', no: 'sem Instagram', unknown: 'não confirmado' },
  facebook: { label: 'Facebook', short: 'Face', yes: 'tem Facebook', no: 'sem Facebook', unknown: 'não confirmado' },
};

/** Estado de uma bolinha: verde (tem), vermelha (não tem) ou cinza (ainda não dá para afirmar). */
export function dotInfo(kind, state) {
  const k = KINDS[kind];
  const s = state === 'yes' || state === 'no' ? state : 'unknown';
  return { cls: { yes: 'yes', no: 'no', unknown: 'unk' }[s], glyph: { yes: '✓', no: '✕', unknown: '?' }[s],
           short: k.short, title: `${k.label}: ${k[s]}` };
}

export const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;

export function splitEvidence(text) {
  return (text || '').split(' | ').map((t) => t.trim()).filter(Boolean);
}

export function fmtDate(iso, withTime = true) {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  const opts = withTime ? { dateStyle: 'short', timeStyle: 'short' } : { dateStyle: 'short' };
  return d.toLocaleString('pt-BR', opts);
}

export function searchTitle(s) {
  return `${s.category} em ${s.city}${s.state ? ', ' + s.state : ''}`;
}

export function debounce(fn, ms) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

export const LEAD_OPTIONS = [
  ['novo_lead', 'Novo lead'], ['nao_contatado', 'Ainda não contatado'], ['primeiro_contato', 'Primeiro contato realizado'],
  ['aguardando_resposta', 'Aguardando resposta'], ['interessado', 'Interessado'], ['negociacao', 'Negociação em andamento'],
  ['cliente_fechado', 'Cliente fechado'], ['nao_interessado', 'Não interessado'],
];
export const CHANNELS = ['WhatsApp', 'Ligação', 'E-mail', 'Instagram', 'Presencial', 'Outro'];
