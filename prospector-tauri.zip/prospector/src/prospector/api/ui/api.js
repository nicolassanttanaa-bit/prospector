// Descobre onde o motor Python está e fala com ele. No Tauri, o Rust inicia o motor e guarda porta+token;
// no modo navegador (python -m prospector.api --browser), o token vem no #fragmento da URL.
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

let backend = null;
let onLost = () => {};
export const setOnLost = (fn) => { onLost = fn; };

export async function connect() {
  const tauriInvoke = window.__TAURI__?.core?.invoke ?? window.__TAURI_INTERNALS__?.invoke;
  if (tauriInvoke) {
    for (let i = 0; i < 400; i++) {                         // até ~60 s (primeira abertura pode ser lenta)
      const info = await tauriInvoke('backend_info');
      if (info) {
        const { port, token } = JSON.parse(info);
        backend = { base: `http://127.0.0.1:${port}`, token };
        return backend;
      }
      await sleep(150);
    }
    throw new Error('O motor do Prospector não iniciou. Feche e abra o programa; se persistir, veja o arquivo de log.');
  }
  const fromHash = /[#&]token=([^&]+)/.exec(location.hash);
  if (fromHash) sessionStorage.setItem('prospector-token', decodeURIComponent(fromHash[1]));
  const token = sessionStorage.getItem('prospector-token');
  if (!token) throw new Error('Abra pelo endereço completo exibido pelo programa (ele inclui o código de acesso).');
  history.replaceState(null, '', location.pathname);        // tira o token da barra de endereço
  backend = { base: location.origin, token };
  return backend;
}

export async function api(method, path, body) {
  let resp;
  try {
    resp = await fetch(backend.base + path, {
      method,
      headers: { Authorization: `Bearer ${backend.token}`, ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}) },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch (e) {
    onLost();
    throw new Error('Sem conexão com o motor do programa.');
  }
  const text = await resp.text();
  const data = text ? JSON.parse(text) : null;
  if (!resp.ok) throw new Error(data?.error || `Erro ${resp.status}`);
  return data;
}
