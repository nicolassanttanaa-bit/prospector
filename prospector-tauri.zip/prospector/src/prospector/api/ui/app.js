import { CHANNELS, KINDS, LEAD_OPTIONS, fill, fmtDate, h, dotInfo, plural, searchTitle, splitEvidence } from './util.js';
import { api, connect, setOnLost } from './api.js';

const $ = (id) => document.getElementById(id);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const LAST_KEY = 'prospector-last-search';
const S = { config: null, searches: [], view: null, activeId: null, job: null, lastFound: -1, polling: false,
            chain: Promise.resolve(), armedDelete: null };

// ---------- avisos ----------
function toast(message, { error = false, action = null } = {}) {
  const el = h('div', { class: `toast${error ? ' error' : ''}`, role: 'status' }, h('span', {}, message),
    action ? h('button', { class: 'link', type: 'button', onclick: () => { action.fn(); el.remove(); } }, action.label) : null);
  $('toasts').append(el);
  setTimeout(() => el.remove(), error ? 9000 : 6000);
}
function showBanner(message) { const b = $('conn-banner'); b.textContent = message; b.hidden = false; }
const safe = (fn) => async (...args) => { try { return await fn(...args); } catch (e) { toast(e.message, { error: true }); } };

// ---------- bolinhas ----------
function dotEl(kind, state, withLabel = true) {
  const d = dotInfo(kind, state);
  return h('div', { class: 'dot-item' },
    h('span', { class: `dot ${d.cls}`, role: 'img', 'aria-label': d.title, title: d.title }, d.glyph),
    withLabel ? h('span', { class: 'dot-label' }, d.short) : null);
}

// ---------- formulário e fontes ----------
function fillForm() {
  const sel = $('f-state');
  sel.append(h('option', { value: '', disabled: true, selected: true }, 'UF'),
             ...S.config.states.map((s) => h('option', { value: s.uf }, `${s.uf} — ${s.name}`)));
  fill($('category-list'), ...S.config.categories.map((c) => h('option', { value: c })));
  try {
    const last = JSON.parse(localStorage.getItem(LAST_KEY) || '{}');
    if (last.city) $('f-city').value = last.city;
    if (last.state) sel.value = last.state;
    if (last.category) $('f-category').value = last.category;
  } catch { /* sem preferências salvas */ }
}

function renderSources() {
  const c = S.config;
  const osm = c.use_osm ? h('span', { class: 'ok' }, 'OpenStreetMap ✓') : h('span', { class: 'muted' }, 'OpenStreetMap desligado');
  const rec = !c.use_receita ? h('span', { class: 'muted' }, 'Receita desligada')
    : c.receita_missing.length ? [h('span', { class: 'bad' }, 'Receita ✕ '), h('button', { class: 'link', type: 'button', onclick: openSettings }, '(configurar)')]
    : h('span', { class: 'ok' }, 'Receita Federal ✓');
  fill($('sources-line'), 'Fontes: ', osm, ' · ', ...[rec].flat());
}

async function submitSearch(ev) {
  ev.preventDefault();
  const err = $('form-error'); err.hidden = true;
  const body = { city: $('f-city').value.trim(), state: $('f-state').value, category: $('f-category').value.trim(),
                 radius_km: $('f-radius').value ? Number($('f-radius').value) : null, auto_verify: true };
  try {
    const { search_id } = await api('POST', '/api/searches', body);
    localStorage.setItem(LAST_KEY, JSON.stringify({ city: body.city, state: body.state, category: body.category }));
    S.activeId = search_id; S.lastFound = -1; S.view = null;
    $('job-warnings').hidden = true; closeDrawer();
    await refreshSearches();
    await loadSearch(search_id, true);
    pollJob();
  } catch (e) { err.textContent = e.message; err.hidden = false; }
}

// ---------- tarefa em segundo plano ----------
function renderJob(job) {
  const running = job.status === 'running';
  $('job-box').hidden = !running;
  $('btn-search').disabled = running;
  if (!running) return;
  const bar = $('job-bar');
  bar.classList.toggle('indeterminate', job.percent == null);
  if (job.percent != null) bar.style.width = `${job.percent}%`;
  $('job-title').textContent = job.kind === 'verify' ? 'Verificando sites…' : 'Pesquisando…';
  $('job-msg').textContent = job.message || '';
  $('job-count').textContent = job.found ? plural(job.found, 'empresa', 'empresas') : '';
}

async function pollJob() {
  if (S.polling) return;
  S.polling = true;
  try {
    for (;;) {
      const job = await api('GET', '/api/jobs/current');
      S.job = job; renderJob(job);
      if (job.search_id === S.activeId && job.found !== S.lastFound) { S.lastFound = job.found; await loadSearch(job.search_id, true); }
      if (job.status !== 'running') { await jobEnded(job); break; }
      await sleep(600);
    }
  } catch { /* a perda de conexão já foi avisada */ } finally { S.polling = false; }
}

async function jobEnded(job) {
  await refreshSearches();
  if (job.search_id === S.activeId) await loadSearch(job.search_id, true);
  const warns = $('job-warnings');
  warns.replaceChildren(...(job.warnings || []).map((w) => h('li', {}, w)));
  warns.hidden = !(job.warnings || []).length;
  if (job.status === 'error') toast(job.message, { error: true });
  else if (job.status === 'cancelled') toast('Cancelado.');
  else toast(job.kind === 'verify' ? 'Verificação concluída.' : `Pesquisa concluída: ${plural(job.found || 0, 'empresa', 'empresas')}.`);
}

// ---------- pesquisas recentes e resultados ----------
async function refreshSearches() {
  S.searches = await api('GET', '/api/searches');
  renderRecent();
}

function renderRecent() {
  $('recent-empty').hidden = S.searches.length > 0;
  fill($('recent-list'), ...S.searches.map((s) => {
    const armed = S.armedDelete === s.id;
    return h('li', { class: `recent-item${s.id === S.activeId ? ' active' : ''}` },
      h('button', { class: 'recent-open', type: 'button', onclick: () => { closeDrawer(); loadSearch(s.id); } },
        h('strong', {}, searchTitle(s)),
        h('span', {}, `${plural(s.found, 'empresa', 'empresas')} · ${fmtDate(s.created_at)}${s.status === 'running' ? ' · em andamento' : ''}`)),
      h('button', { class: `recent-del${armed ? ' armed' : ''}`, type: 'button', title: armed ? 'Clique de novo para excluir' : 'Excluir esta pesquisa',
        'aria-label': `Excluir a pesquisa ${searchTitle(s)}`, onclick: safe(() => deleteSearch(s.id)) }, armed ? 'Excluir?' : '✕'));
  }));
}

async function deleteSearch(id) {
  if (S.armedDelete !== id) { S.armedDelete = id; renderRecent(); setTimeout(() => { if (S.armedDelete === id) { S.armedDelete = null; renderRecent(); } }, 3000); return; }
  S.armedDelete = null;
  await api('DELETE', `/api/searches/${id}`);
  if (S.activeId === id) { S.activeId = null; S.view = null; renderResults(); }
  await refreshSearches();
  toast('Pesquisa excluída (as empresas continuam salvas).');
}

function loadSearch(id, silent = false) {          // serializa as cargas para não misturar respostas
  S.chain = S.chain.then(async () => {
    try {
      const v = await api('GET', `/api/searches/${id}`);
      if (S.activeId !== null && S.activeId !== id && silent) return;
      S.activeId = id; S.view = v; renderResults(); renderRecent();
    } catch (e) { if (!silent) toast(e.message, { error: true }); }
  });
  return S.chain;
}

function renderResults() {
  const v = S.view, head = $('results-head'), empty = $('empty'), grid = $('grid');
  if (!v) {
    head.hidden = true; fill(grid, );
    empty.hidden = false;
    fill(empty, h('div', { class: 'big' }, '🔎'), h('h3', {}, 'Pesquise uma cidade'),
      h('p', {}, 'Escolha a cidade, o estado e o tipo de negócio no painel à esquerda. Cada pesquisa mostra só as empresas daquela cidade, sem repetir lojas.'));
    return;
  }
  const { search, summary, companies } = v;
  head.hidden = false;
  $('res-title').textContent = searchTitle(search);
  const chip = (dot, label, n) => h('span', { class: 'chip' }, dot ? dotEl('site', dot, false) : null, h('b', {}, n), label);
  fill($('res-summary'), chip(null, ' empresas', summary.total), chip('no', ' sem site identificado', summary.sem_site),
    chip('yes', ' com site', summary.com_site), summary.inconclusivas ? chip('unknown', ' a confirmar', summary.inconclusivas) : null);
  fill(grid, ...companies.map(cardEl));
  const running = S.job?.status === 'running' && S.job.search_id === search.id;
  empty.hidden = companies.length > 0;
  if (!companies.length) {
    fill(empty, h('div', { class: 'big' }, running ? '⏳' : '🤷'),
      h('h3', {}, running ? 'Procurando empresas…' : 'Nenhuma empresa encontrada'),
      h('p', {}, running ? 'Os resultados aparecem aqui assim que as fontes responderem.'
        : 'Tente outra categoria ou confira, em Configurações, se as fontes estão ativas. O OpenStreetMap pode ter pouca cobertura em cidades pequenas.'));
  }
}

function cardEl(c) {
  const open = () => openDrawer(c.id);
  return h('article', { class: 'card', tabindex: 0, 'data-id': c.id, onclick: open,
    onkeydown: (e) => { if (e.key === 'Enter') open(); } },
    h('div', { class: 'card-top' }, c.favorite ? h('span', { class: 'fav', title: 'Favorita' }, '★') : h('span'),
      c.units > 1 ? h('span', { class: 'badge', title: 'Esta rede tem várias unidades na cidade; elas aparecem juntas.' }, `${c.units} unidades`) : null),
    h('h3', { class: 'card-name', title: c.name }, c.name),
    h('p', { class: 'card-sub' }, [c.category, c.city].filter(Boolean).join(' · ')),
    h('div', { class: 'card-bottom' },
      h('div', { class: 'dots' }, ...['site', 'phone', 'instagram', 'facebook'].map((k) => dotEl(k, c.dots[k]))),
      h('button', { class: 'more', type: 'button', title: 'Ver mais informações', 'aria-label': `Ver mais sobre ${c.name}`,
        onclick: (e) => { e.stopPropagation(); open(); } }, '›')));
}

// ---------- exportação ----------
const EXPORTS = [['xlsx', 'Excel (.xlsx)'], ['csv_semicolon', 'CSV para Excel brasileiro (;)'], ['csv_comma', 'CSV com vírgula'], ['json', 'JSON']];
function buildExportMenu() {
  fill($('export-menu'), ...EXPORTS.map(([fmt, label]) => h('li', { role: 'none' },
    h('button', { type: 'button', role: 'menuitem', onclick: safe(() => doExport(fmt)) }, label))));
}
function toggleMenu(open) { $('export-menu').hidden = !open; $('btn-export').setAttribute('aria-expanded', String(open)); }
async function doExport(fmt) {
  toggleMenu(false);
  const out = await api('POST', `/api/searches/${S.activeId}/export`, { format: fmt });
  toast(`${plural(out.count, 'empresa exportada', 'empresas exportadas')}: ${out.path}`,
    { action: { label: 'Mostrar na pasta', fn: safe(() => api('POST', '/api/open', { reveal: out.path })) } });
}

// ---------- detalhes ("ver mais") ----------
const openUrl = safe((url) => api('POST', '/api/open', { url }));
const linkBtn = (url, text) => h('button', { class: 'link', type: 'button', onclick: () => openUrl(url) }, text || url);

async function openDrawer(id) {
  try { renderDrawer(await api('GET', `/api/companies/${id}`)); } catch (e) { toast(e.message, { error: true }); }
}
function closeDrawer() { $('drawer').hidden = true; $('scrim').hidden = true; }

function renderDrawer(d) {
  const row = (kind, value, extra) => h('div', { class: 'row' }, dotEl(kind, d.dots[kind], false),
    h('div', {}, h('div', { class: 'what' }, KINDS[kind].label), h('div', { class: 'val' }, value), extra || null));
  const siteUrl = d.site.url || d.website;
  const f = { fav: h('input', { type: 'checkbox', id: 'd-fav', checked: d.favorite }),
              lead: h('select', { id: 'd-lead' }, LEAD_OPTIONS.map(([v, l]) => h('option', { value: v, selected: v === d.lead_status }, l))),
              notes: h('textarea', { id: 'd-notes', maxlength: 5000, placeholder: 'Ex.: Entrar em contato pelo WhatsApp. Propor um site institucional.' }, d.notes),
              site: h('input', { id: 'd-site', type: 'text', value: d.website || '', placeholder: 'https://…' }),
              ig: h('input', { id: 'd-ig', type: 'text', value: d.instagram || '', placeholder: '@usuario ou link' }),
              fb: h('input', { id: 'd-fb', type: 'text', value: d.facebook || '', placeholder: 'link da página' }),
              status: h('select', { id: 'd-status' }, [['', 'Manter a classificação atual'], ['sem_site_identificado', 'Confirmo: sem site'],
                ['possui_site', 'Confirmo: possui site'], ['inconclusivo', 'Marcar como inconclusivo']].map(([v, l]) => h('option', { value: v }, l))),
              channel: h('select', { id: 'd-channel' }, CHANNELS.map((c) => h('option', { value: c }, c))),
              cnote: h('input', { id: 'd-cnote', type: 'text', maxlength: 500, placeholder: 'Resumo do contato (opcional)' }) };
  const err = h('div', { class: 'form-error', role: 'alert', hidden: true });
  const meter = h('div', { class: 'meter-fill' });
  if (d.site.confidence != null) meter.style.width = `${Math.round(d.site.confidence * 100)}%`;

  const save = safe(async () => {
    err.hidden = true;
    const body = { favorite: f.fav.checked, lead_status: f.lead.value, notes: f.notes.value };
    const links = { website: f.site.value, instagram: f.ig.value, facebook: f.fb.value };
    if (links.website.trim() !== (d.website || '') || links.instagram.trim() !== (d.instagram || '') || links.facebook.trim() !== (d.facebook || '')) body.links = links;
    if (f.status.value) body.site_status = f.status.value;
    try { const upd = await api('PATCH', `/api/companies/${d.id}`, body); toast('Alterações salvas.'); renderDrawer(upd); loadSearch(S.activeId, true); }
    catch (e) { err.textContent = e.message; err.hidden = false; }
  });
  const logContact = safe(async () => {
    const upd = await api('POST', `/api/companies/${d.id}/contacts`, { channel: f.channel.value, note: f.cnote.value });
    toast('Contato registrado.'); renderDrawer(upd); loadSearch(S.activeId, true);
  });

  const el = $('drawer');
  fill(el, 
    h('div', { class: 'drawer-head' },
      h('div', {}, h('h2', {}, d.name), h('p', { class: 'muted' }, [d.category, d.city && `${d.city}${d.state ? ', ' + d.state : ''}`].filter(Boolean).join(' · ')),
        h('div', { class: 'pills' }, d.units > 1 ? h('span', { class: 'pill' }, `${d.units} unidades`) : null, h('span', { class: 'pill' }, d.lead_label),
          h('span', { class: 'pill' }, `Fonte: ${d.source}`))),
      h('button', { class: 'x', type: 'button', id: 'drawer-close', 'aria-label': 'Fechar', onclick: closeDrawer }, '✕')),

    h('section', { class: 'section' }, h('h3', {}, 'Presença online'),
      row('site', siteUrl ? linkBtn(siteUrl) : d.site.label, h('div', { class: 'what' }, d.site.checked ? `Confiança ${d.site.confidence_label}` : 'Site ainda não verificado')),
      row('phone', d.phone || 'Não encontrado'),
      row('instagram', d.instagram ? linkBtn(d.instagram) : 'Não encontrado'),
      row('facebook', d.facebook ? linkBtn(d.facebook) : 'Não encontrado'),
      h('div', { class: 'actions' },
        h('button', { class: 'btn', type: 'button', onclick: () => openUrl(d.links.maps) }, 'Abrir no Google Maps'),
        siteUrl ? h('button', { class: 'btn', type: 'button', onclick: () => openUrl(siteUrl) }, 'Abrir site') : null,
        h('button', { class: 'btn', type: 'button', onclick: () => openUrl(d.links.google) }, 'Pesquisar no Google'),
        h('button', { class: 'btn', type: 'button', onclick: () => openUrl(d.links.instagram_search) }, 'Procurar Instagram'))),

    h('section', { class: 'section' }, h('h3', {}, 'Situação do site'),
      h('div', {}, h('strong', {}, d.site.label), d.site.state_label ? h('span', { class: 'muted' }, ` — site ${d.site.state_label}`) : null),
      d.site.confidence != null ? h('div', { class: 'meter', title: `Confiança ${d.site.confidence_label}` }, meter) : null,
      d.site.evidence ? h('ul', { class: 'evidence' }, splitEvidence(d.site.evidence).map((t) => h('li', {}, t))) : null,
      h('p', { class: 'muted' }, 'Ausência de site nos dados não prova que a empresa não tenha um. Confira antes de abordar.'),
      d.site.checked_at ? h('p', { class: 'muted' }, `Última verificação: ${fmtDate(d.site.checked_at)}`) : null),

    d.units_list.length > 1 ? h('section', { class: 'section' }, h('h3', {}, `Unidades (${d.units_list.length} registros)`),
      d.units_list.map((u) => h('div', { class: 'unit' }, u.name, h('small', {}, [u.address, u.phone, u.source].filter(Boolean).join(' · '))))) : null,

    h('section', { class: 'section' }, h('h3', {}, 'Gestão comercial'),
      h('label', { class: 'check' }, f.fav, '★ Favorita'),
      h('label', {}, 'Status comercial', f.lead), h('label', {}, 'Notas', f.notes),
      h('p', { class: 'muted' }, d.last_contact_at ? `Último contato: ${fmtDate(d.last_contact_at)}` : 'Nenhum contato registrado.'),
      h('div', { class: 'actions' }, h('label', {}, 'Canal', f.channel), h('label', {}, 'Resumo', f.cnote)),
      h('button', { class: 'btn', type: 'button', onclick: logContact }, 'Registrar contato agora'),
      d.contacts.length ? h('ul', { class: 'hist' }, d.contacts.map((c) => h('li', {}, h('b', {}, fmtDate(c.at)), ` — ${c.channel || 'canal não informado'}${c.note ? ' — ' + c.note : ''}`))) : null),

    h('section', { class: 'section' }, h('h3', {}, 'Corrigir informações'),
      h('label', {}, 'Site', f.site), h('label', {}, 'Instagram', f.ig), h('label', {}, 'Facebook', f.fb),
      h('label', {}, 'Definir situação do site', f.status)),
    err,
    h('div', { class: 'save-bar' }, h('button', { class: 'btn primary', type: 'button', onclick: save }, 'Salvar alterações'),
      h('button', { class: 'btn', type: 'button', onclick: closeDrawer }, 'Fechar')));
  el.hidden = false; $('scrim').hidden = false; el.scrollTop = 0;
  $('drawer-close').focus();
}

// ---------- configurações ----------
function openSettings() {
  const c = S.config;
  const osm = h('input', { type: 'checkbox', checked: c.use_osm }), rec = h('input', { type: 'checkbox', checked: c.use_receita });
  const dir = h('input', { type: 'text', value: c.receita_dir, placeholder: 'Ex.: C:\\Dados\\Receita' });
  const status = h('p', { class: c.receita_missing.length ? 'bad' : 'ok' },
    c.receita_missing.length ? `Receita indisponível — faltando: ${c.receita_missing.join('; ')}` : '✔ Arquivos da Receita encontrados.');
  const err = h('div', { class: 'form-error', role: 'alert', hidden: true });
  const save = safe(async () => {
    try {
      S.config = await api('PUT', '/api/config', { use_osm: osm.checked, use_receita: rec.checked, receita_dir: dir.value });
      renderSources(); closeModal(); toast('Configurações salvas.');
    } catch (e) { err.textContent = e.message; err.hidden = false; }
  });
  fill($('modal'), h('div', { class: 'modal-card' }, h('h2', {}, 'Configurações'),
    h('label', { class: 'check' }, osm, 'Usar OpenStreetMap (precisa de internet)'),
    h('label', { class: 'check' }, rec, 'Usar Receita Federal (empresas com CNPJ)'),
    h('label', {}, 'Pasta com os arquivos .zip da Receita', dir), status,
    h('p', { class: 'muted' }, 'Baixe, uma vez, os arquivos Estabelecimentos0…9 e Municipios (e, opcionalmente, Empresas0…9) e salve todos os .zip numa pasta, sem extrair. Cole o caminho dela acima.'),
    h('button', { class: 'link', type: 'button', onclick: () => openUrl('https://dados.gov.br/dados/conjuntos-dados/cadastro-nacional-da-pessoa-juridica---cnpj') }, 'Abrir a página de download (dados.gov.br)'),
    h('p', { class: 'muted' }, `Prospector ${c.version} · dados e log: ${c.data_dir} · exportações: ${c.export_dir}`),
    h('p', { class: 'muted' }, 'Dados do OpenStreetMap: © contribuidores do OpenStreetMap (licença ODbL).'), err,
    h('div', { class: 'actions' }, h('button', { class: 'btn primary', type: 'button', onclick: save }, 'Salvar'),
      h('button', { class: 'btn', type: 'button', onclick: closeModal }, 'Fechar'))));
  $('modal').hidden = false;
}
function closeModal() { $('modal').hidden = true; }

// ---------- início ----------
async function init() {
  setOnLost(() => showBanner('A conexão com o motor do programa foi perdida. Feche e abra o Prospector.'));
  try { await connect(); S.config = await api('GET', '/api/config'); } catch (e) { showBanner(e.message); return; }
  fillForm(); renderSources(); buildExportMenu(); renderResults();
  $('search-form').addEventListener('submit', submitSearch);
  $('btn-cancel').addEventListener('click', safe(() => api('POST', '/api/jobs/cancel', {})));
  $('btn-settings').addEventListener('click', openSettings);
  $('btn-export').addEventListener('click', (e) => { e.stopPropagation(); toggleMenu($('export-menu').hidden); });
  document.addEventListener('click', () => toggleMenu(false));
  $('scrim').addEventListener('click', closeDrawer);
  $('modal').addEventListener('click', (e) => { if (e.target === $('modal')) closeModal(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') { closeModal(); closeDrawer(); toggleMenu(false); } });
  await refreshSearches();
  const job = await api('GET', '/api/jobs/current');
  if (job.status === 'running' && job.search_id) { S.activeId = job.search_id; await loadSearch(job.search_id, true); pollJob(); }
  else if (S.searches.length) await loadSearch(S.searches[0].id, true);
  setInterval(() => api('GET', '/api/health').catch(() => {}), 10000);   // "estou vivo": o motor encerra sozinho se a janela some
}
init();
