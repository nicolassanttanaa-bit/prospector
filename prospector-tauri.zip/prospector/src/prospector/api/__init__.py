"""API local (somente 127.0.0.1) usada pela interface Tauri. Não importa nada do Qt."""
