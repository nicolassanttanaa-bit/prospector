"""Servidor HTTP local da interface. Defesas: só escuta em 127.0.0.1; exige token em todas as chamadas /api;
confere o cabeçalho Host (anti DNS-rebinding) e a origem (CORS só para a janela do Tauri); limita o tamanho
do corpo; devolve erros sem detalhes internos."""
from __future__ import annotations

import hmac
import json
import logging
import mimetypes
import re
import secrets
import subprocess
import sys
import threading
import time
import webbrowser
from contextlib import contextmanager
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Callable
from urllib.parse import unquote, urlsplit

from prospector import __version__
from prospector.api import serializers as ser
from prospector.api.jobs import JobRunner
from prospector.config.prefs import Prefs
from prospector.database.db import connect
from prospector.database.repository import MAX_NOTES, CompanyRepository
from prospector.exports.exporter import FORMATS, ExportError, export_companies
from prospector.integrations.base import STATES, SearchQuery, SourceError
from prospector.integrations.cnae import CATEGORIES
from prospector.integrations.receita import ReceitaSource
from prospector.integrations.site_checker import SiteChecker
from prospector.interface.links import normalize_social, safe_url
from prospector.models.company import LeadStatus, SiteStatus
from prospector.services.search_service import SearchService, build_sources
from prospector.services.site_service import verify_companies

log = logging.getLogger(__name__)
TAURI_ORIGINS = {"http://tauri.localhost", "https://tauri.localhost", "tauri://localhost"}
MAX_BODY = 1_000_000
EXPORT_EXT = {fmt: ext for _, fmt, ext in FORMATS}
LEAD_VALUES = {s.value for s in LeadStatus}
SITE_VALUES = {s.value for s in SiteStatus}


class ApiError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status, self.message = status, message


def default_export_dir() -> Path:
    downloads = Path.home() / "Downloads"
    return (downloads if downloads.is_dir() else Path.home()) / "Prospector"


def reveal_in_file_manager(path: Path) -> None:
    if sys.platform == "win32":
        subprocess.Popen(["explorer", f"/select,{path}"])
    elif sys.platform == "darwin":
        subprocess.Popen(["open", "-R", str(path)])
    else:
        subprocess.Popen(["xdg-open", str(path.parent)])


def static_dir() -> Path:
    return Path(__file__).resolve().parent / "ui"


def _slug(text: str) -> str:
    from prospector.integrations.textutil import normalize
    return re.sub(r"[^a-z0-9]+", "-", normalize(text).lower()).strip("-")[:30] or "x"


class ApiServer:
    def __init__(self, data_dir: Path, token: str | None = None, port: int = 0, serve_ui: bool = False,
                 idle_timeout: float = 0, export_dir: Path | None = None,
                 source_factory: Callable = build_sources, checker_factory: Callable = SiteChecker,
                 opener: Callable[[str], object] = webbrowser.open,
                 revealer: Callable[[Path], None] = reveal_in_file_manager):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.db_path, self.prefs_path = self.data_dir / "prospector.db", self.data_dir / "prefs.json"
        self.token = token or secrets.token_urlsafe(32)
        self.serve_ui, self.idle_timeout = serve_ui, idle_timeout
        self.export_dir = Path(export_dir) if export_dir else default_export_dir()
        self.source_factory, self.checker_factory = source_factory, checker_factory
        self.opener, self.revealer = opener, revealer
        self.jobs = JobRunner()
        self.last_seen = time.monotonic()
        connect(self.db_path).close()                       # cria/migra o banco já na inicialização
        self.httpd = ThreadingHTTPServer(("127.0.0.1", port), self._make_handler())
        self.port = self.httpd.server_address[1]
        self.routes = self._routes()

    # ---- ciclo de vida ----
    def serve_forever(self) -> None:
        if self.idle_timeout > 0:
            threading.Thread(target=self._watchdog, daemon=True).start()
        self.httpd.serve_forever(poll_interval=0.2)

    def start_background(self) -> threading.Thread:
        t = threading.Thread(target=self.httpd.serve_forever, kwargs={"poll_interval": 0.1}, daemon=True)
        t.start()
        return t

    def shutdown(self) -> None:
        self.jobs.cancel()
        self.httpd.shutdown()
        self.httpd.server_close()

    def _watchdog(self) -> None:
        """Encerra sozinho se a janela sumiu (ninguém fala com a API há `idle_timeout` s e não há tarefa rodando)."""
        while True:
            time.sleep(2)
            if not self.jobs.running and time.monotonic() - self.last_seen > self.idle_timeout:
                log.info("Sem atividade da interface; encerrando o motor.")
                threading.Thread(target=self.httpd.shutdown, daemon=True).start()
                return

    @contextmanager
    def repo(self):
        conn = connect(self.db_path)
        try:
            yield CompanyRepository(conn)
        finally:
            conn.close()

    # ---- HTTP ----
    def _make_handler(self):
        api = self

        class Handler(BaseHTTPRequestHandler):
            server_version = "ProspectorAPI"
            protocol_version = "HTTP/1.1"

            def log_message(self, fmt, *args):      # silencioso: sem endereços nos logs
                pass

            def _send(self, status: int, body: bytes = b"", ctype: str = "application/json; charset=utf-8", extra=None):
                self.send_response(status)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.send_header("X-Content-Type-Options", "nosniff")
                for k, v in (extra or {}).items():
                    self.send_header(k, v)
                self.end_headers()
                if body and self.command != "HEAD":
                    self.wfile.write(body)

            def _json(self, status: int, payload, extra=None):
                self._send(status, json.dumps(payload, ensure_ascii=False).encode("utf-8"), extra=extra)

            def _handle(self):
                api.last_seen = time.monotonic()
                cors: dict = {}
                try:
                    allowed_hosts = {f"127.0.0.1:{api.port}", f"localhost:{api.port}"}
                    if self.headers.get("Host", "") not in allowed_hosts:
                        raise ApiError(403, "Host não permitido.")
                    origin = self.headers.get("Origin")
                    if origin:
                        if origin not in TAURI_ORIGINS | {f"http://{h}" for h in allowed_hosts}:
                            raise ApiError(403, "Origem não permitida.")
                        cors = {"Access-Control-Allow-Origin": origin, "Vary": "Origin"}
                    path = urlsplit(self.path).path
                    if self.command == "OPTIONS":
                        return self._send(204, extra={**cors, "Access-Control-Allow-Methods": "GET, POST, PUT, PATCH, DELETE",
                                                      "Access-Control-Allow-Headers": "Authorization, Content-Type",
                                                      "Access-Control-Allow-Private-Network": "true",
                                                      "Access-Control-Max-Age": "600"})
                    if not path.startswith("/api/"):
                        return self._static(path)
                    expected = "Bearer " + api.token
                    if not hmac.compare_digest(self.headers.get("Authorization", ""), expected):
                        raise ApiError(401, "Não autorizado.")
                    body = self._body() if self.command in ("POST", "PUT", "PATCH") else {}
                    for method, pattern, fn in api.routes:
                        m = pattern.fullmatch(path)
                        if m and method == self.command:
                            status, payload = fn(body, *[int(g) if g.isdigit() else g for g in m.groups()])
                            return self._send(204, extra=cors) if payload is None else self._json(status, payload, cors)
                    raise ApiError(404, "Rota não encontrada.")
                except ApiError as e:
                    self._json(e.status, {"error": e.message}, cors)
                except Exception:  # noqa: BLE001
                    log.exception("Erro ao tratar %s %s", self.command, urlsplit(self.path).path)
                    self._json(500, {"error": "Erro interno. Detalhes no arquivo de log."}, cors)

            def _body(self) -> dict:
                length = int(self.headers.get("Content-Length") or 0)
                if length > MAX_BODY:
                    raise ApiError(413, "Requisição grande demais.")
                if not length:
                    return {}
                try:
                    data = json.loads(self.rfile.read(length).decode("utf-8"))
                except (ValueError, UnicodeDecodeError):
                    raise ApiError(400, "Corpo da requisição inválido (JSON esperado).")
                if not isinstance(data, dict):
                    raise ApiError(400, "Corpo da requisição inválido (objeto JSON esperado).")
                return data

            def _static(self, path: str):
                if not api.serve_ui or self.command != "GET":
                    raise ApiError(404, "Não encontrado.")
                root = static_dir().resolve()
                target = (root / unquote(path).lstrip("/")).resolve() if path not in ("", "/") else root / "index.html"
                if root not in target.parents and target != root / "index.html" or not target.is_file():
                    raise ApiError(404, "Não encontrado.")
                ctype = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
                if ctype.startswith("text/") or ctype in ("application/javascript", "application/json"):
                    ctype += "; charset=utf-8"
                self._send(200, target.read_bytes(), ctype)

            do_GET = do_POST = do_PUT = do_PATCH = do_DELETE = do_OPTIONS = do_HEAD = _handle

        return Handler

    # ---- rotas ----
    def _routes(self):
        n = r"(\d+)"
        return [
            ("GET", re.compile("/api/health"), self.health),
            ("GET", re.compile("/api/config"), self.get_config),
            ("PUT", re.compile("/api/config"), self.put_config),
            ("GET", re.compile("/api/searches"), self.list_searches),
            ("POST", re.compile("/api/searches"), self.start_search),
            ("GET", re.compile(f"/api/searches/{n}"), self.get_search),
            ("DELETE", re.compile(f"/api/searches/{n}"), self.delete_search),
            ("POST", re.compile(f"/api/searches/{n}/verify"), self.start_verify),
            ("POST", re.compile(f"/api/searches/{n}/export"), self.export_search),
            ("GET", re.compile("/api/jobs/current"), lambda body: (200, self.jobs.snapshot())),
            ("POST", re.compile("/api/jobs/cancel"), self.cancel_job),
            ("GET", re.compile(f"/api/companies/{n}"), self.get_company),
            ("PATCH", re.compile(f"/api/companies/{n}"), self.patch_company),
            ("POST", re.compile(f"/api/companies/{n}/contacts"), self.add_contact),
            ("POST", re.compile("/api/open"), self.open_external),
        ]

    def health(self, body):
        return 200, {"ok": True, "version": __version__}

    def _config(self) -> dict:
        p = Prefs.load(self.prefs_path)
        return {"receita_dir": p.receita_dir, "use_receita": p.use_receita, "use_osm": p.use_osm,
                "receita_missing": ReceitaSource.missing_files(p.receita_dir or None),
                "categories": [c.name for c in CATEGORIES], "states": [{"uf": k, "name": v} for k, v in STATES.items()],
                "version": __version__, "data_dir": str(self.data_dir), "export_dir": str(self.export_dir)}

    def get_config(self, body):
        return 200, self._config()

    def put_config(self, body):
        p = Prefs.load(self.prefs_path)
        for key in ("use_receita", "use_osm"):
            if key in body:
                if not isinstance(body[key], bool):
                    raise ApiError(400, f"Valor inválido para {key}.")
                setattr(p, key, body[key])
        if "receita_dir" in body:
            d = body["receita_dir"]
            if not isinstance(d, str) or len(d) > 500 or "\x00" in d:
                raise ApiError(400, "Caminho da pasta inválido.")
            p.receita_dir = d.strip().strip('"')
        try:
            p.save(self.prefs_path)
        except OSError:
            raise ApiError(500, "Não foi possível salvar as configurações.")
        return 200, self._config()

    def list_searches(self, body):
        with self.repo() as r:
            return 200, [ser.search(s) for s in r.list_searches()]

    def _find_search(self, r: CompanyRepository, search_id: int):
        s = r.get_search(search_id)
        if s is None:
            raise ApiError(404, "Pesquisa não encontrada.")
        return s

    def get_search(self, body, search_id):
        with self.repo() as r:
            s = self._find_search(r, search_id)
            rows = r.search_companies(search_id)
            return 200, {"search": ser.search(s), "summary": ser.summary(rows), "companies": [ser.card(x) for x in rows]}

    def delete_search(self, body, search_id):
        snap = self.jobs.snapshot()
        if snap.get("status") == "running" and snap.get("search_id") == search_id:
            raise ApiError(409, "Esta pesquisa ainda está em andamento. Cancele antes de excluir.")
        with self.repo() as r:
            self._find_search(r, search_id)
            r.delete_search(search_id)
        return 200, {"ok": True}

    def start_search(self, body):
        city = str(body.get("city", "")).split(",")[0]
        state = str(body.get("state", "")).strip()
        if not state:
            raise ApiError(400, "Escolha o estado (UF) da cidade.")
        radius = body.get("radius_km")
        radius = None if radius in (None, "", 0) else radius
        if radius is not None and not isinstance(radius, (int, float)):
            raise ApiError(400, "Raio inválido.")
        try:
            query = SearchQuery.parse(f"{city}, {state}", str(body.get("category", "")), radius)
        except ValueError as e:
            raise ApiError(400, str(e))
        auto_verify = body.get("auto_verify", True) is not False
        if self.jobs.running:
            raise ApiError(409, "Já existe uma tarefa em andamento. Aguarde ou cancele.")
        with self.repo() as r:
            search_id = r.create_search(query.city, query.state, query.category.name, query.radius_km)
        started = self.jobs.start("search", lambda up, cancelled: self._run_search(search_id, query, auto_verify, up, cancelled),
                                  search_id=search_id)
        if not started:
            with self.repo() as r:
                r.delete_search(search_id)
            raise ApiError(409, "Já existe uma tarefa em andamento. Aguarde ou cancele.")
        return 202, {"search_id": search_id}

    def _run_search(self, search_id, query, auto_verify, update, cancelled):
        conn = connect(self.db_path)
        repo = CompanyRepository(conn)
        found, status = 0, "error"
        try:
            split = 60 if auto_verify else 100
            service = SearchService(repo, self.source_factory(Prefs.load(self.prefs_path)))
            res = service.run(query, lambda p, m, f: update(None if p < 0 else p * split // 100, m, f), cancelled, search_id)
            found, status = res.found, "cancelled" if res.cancelled else "done"
            warnings = list(res.warnings)
            if auto_verify and not res.cancelled and res.found:
                warnings += self._verify_into(repo, search_id, update, cancelled, base=60)
            return {"warnings": warnings, "cancelled": res.cancelled or cancelled()}
        finally:
            repo.finish_search(search_id, found, status)
            conn.close()

    def _verify_into(self, repo, search_id, update, cancelled, base=0) -> list[str]:
        checker = self.checker_factory()
        try:
            verify_companies(repo, checker, lambda p, m, d: update(None if p < 0 else base + p * (100 - base) // 100, m, d),
                             cancelled, search_id=search_id)
            return []
        except SourceError as e:
            return [str(e)]
        finally:
            checker.close()

    def start_verify(self, body, search_id):
        with self.repo() as r:
            self._find_search(r, search_id)

        def job(update, cancelled):
            conn = connect(self.db_path)
            try:
                return {"warnings": self._verify_into(CompanyRepository(conn), search_id, update, cancelled),
                        "cancelled": cancelled()}
            finally:
                conn.close()
        if not self.jobs.start("verify", job, search_id=search_id):
            raise ApiError(409, "Já existe uma tarefa em andamento. Aguarde ou cancele.")
        return 202, {"search_id": search_id}

    def cancel_job(self, body):
        self.jobs.cancel()
        return 200, {"ok": True}

    def export_search(self, body, search_id):
        fmt = body.get("format")
        if fmt not in EXPORT_EXT:
            raise ApiError(400, "Formato de exportação inválido.")
        with self.repo() as r:
            s = self._find_search(r, search_id)
            rows = r.search_companies(search_id)
            if not rows:
                raise ApiError(400, "Não há empresas para exportar nesta pesquisa.")
            try:
                self.export_dir.mkdir(parents=True, exist_ok=True)
                name = f"prospector_{_slug(s['city'])}_{_slug(s['category'])}_{datetime.now():%Y%m%d-%H%M%S}{EXPORT_EXT[fmt]}"
                path = self.export_dir / name
                count = export_companies(r, rows, path, fmt, f"{s['category']} em {s['city']}, {s['state'] or ''}".strip(", "))
            except (ExportError, OSError) as e:
                raise ApiError(500, str(e) if isinstance(e, ExportError) else "Não foi possível gravar o arquivo de exportação.")
        return 200, {"path": str(path), "count": count}

    def get_company(self, body, company_id):
        with self.repo() as r:
            return 200, self._company(r, company_id)

    def _company(self, r: CompanyRepository, company_id: int) -> dict:
        row = r.get(company_id)
        if row is None:
            raise ApiError(404, "Empresa não encontrada.")
        return ser.detail(r, row)

    def patch_company(self, body, company_id):
        with self.repo() as r:
            self._company(r, company_id)                      # 404 se não existir
            row = r.get(company_id)
            if "lead_status" in body:
                if body["lead_status"] not in LEAD_VALUES:
                    raise ApiError(400, "Status comercial inválido.")
            if "notes" in body:
                if not isinstance(body["notes"], str) or len(body["notes"].strip()) > MAX_NOTES:
                    raise ApiError(400, f"As notas passam de {MAX_NOTES} caracteres.")
            if "site_status" in body and body["site_status"] not in SITE_VALUES:
                raise ApiError(400, "Situação do site inválida.")
            if "favorite" in body and not isinstance(body["favorite"], bool):
                raise ApiError(400, "Valor inválido para favorita.")
            links = body.get("links")
            if links is not None:
                if not isinstance(links, dict):
                    raise ApiError(400, "Links inválidos.")
                site = self._link(links.get("website"), "site", safe_url)
                ig = self._link(links.get("instagram"), "Instagram", lambda v: normalize_social(v, "https://instagram.com"))
                fb = self._link(links.get("facebook"), "Facebook", lambda v: normalize_social(v, "https://facebook.com"))
                r.set_links(company_id, site, ig, fb)
                if "site_status" not in body and site and not (row["website"] or "").strip():
                    r.set_site_manual(company_id, SiteStatus.HAS_SITE)        # o usuário informou um site
            if "site_status" in body:
                r.set_site_manual(company_id, SiteStatus(body["site_status"]))
            if "lead_status" in body:
                r.set_lead_status(company_id, LeadStatus(body["lead_status"]))
            if "favorite" in body:
                r.set_favorite(company_id, body["favorite"])
            if "notes" in body:
                r.set_notes(company_id, body["notes"].strip())
            return 200, self._company(r, company_id)

    @staticmethod
    def _link(value, label: str, parse) -> str | None:
        if value is None or (isinstance(value, str) and not value.strip()):
            return None
        parsed = parse(value) if isinstance(value, str) else None
        if not parsed:
            raise ApiError(400, f"Endereço de {label} inválido. Use um link http(s) ou, no Instagram, @usuario.")
        return parsed

    def add_contact(self, body, company_id):
        channel, note = str(body.get("channel", "")).strip()[:40], str(body.get("note", "")).strip()[:500]
        with self.repo() as r:
            self._company(r, company_id)
            r.log_contact(company_id, channel, note, advance=True)
            return 200, self._company(r, company_id)

    def open_external(self, body):
        if "url" in body:
            url = safe_url(body["url"]) if isinstance(body["url"], str) else None
            if not url:
                raise ApiError(400, "Endereço inválido (só http/https).")
            self.opener(url)
            return 200, {"ok": True}
        if "reveal" in body:
            try:
                path = Path(str(body["reveal"])).resolve()
                inside = self.export_dir.resolve() in path.parents and path.is_file()
            except (OSError, ValueError):
                inside = False
            if not inside:
                raise ApiError(400, "Só é possível mostrar arquivos exportados pelo programa.")
            self.revealer(path)
            return 200, {"ok": True}
        raise ApiError(400, "Informe 'url' ou 'reveal'.")
