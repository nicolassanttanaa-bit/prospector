from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (QCheckBox, QFileDialog, QHBoxLayout, QLabel, QLineEdit, QPushButton,
                               QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget)

from prospector import __version__
from prospector.config.prefs import Prefs
from prospector.config.settings import Settings
from prospector.database.repository import CompanyRepository
from prospector.integrations.receita import ReceitaSource

DADOS_GOV = "https://dados.gov.br/dados/conjuntos-dados/cadastro-nacional-da-pessoa-juridica---cnpj"


class SettingsPage(QWidget):
    changed = Signal()

    def __init__(self, settings: Settings, prefs: Prefs):
        super().__init__()
        self.settings, self.prefs = settings, prefs
        title = QLabel("Configurações"); title.setObjectName("title")
        self.use_receita = QCheckBox("Usar Receita Federal (CNPJ)"); self.use_receita.setChecked(prefs.use_receita)
        self.use_osm = QCheckBox("Usar OpenStreetMap"); self.use_osm.setChecked(prefs.use_osm)
        self.folder = QLineEdit(prefs.receita_dir); self.folder.setPlaceholderText("Pasta com Estabelecimentos*.zip e Municipios.zip")
        browse = QPushButton("Escolher pasta…"); browse.clicked.connect(self._browse)
        row = QHBoxLayout(); row.addWidget(self.folder, 1); row.addWidget(browse)
        save = QPushButton("Salvar"); save.clicked.connect(self._save)
        self.status = QLabel(); self.status.setWordWrap(True)
        help_ = QLabel(f'<b>Como obter os dados da Receita (gratuito):</b> baixe em '
                       f'<a href="{DADOS_GOV}">dados.gov.br — Cadastro Nacional da Pessoa Jurídica</a> os arquivos '
                       f'<i>Estabelecimentos0…9</i> e <i>Municipios</i> (e, opcionalmente, <i>Empresas0…9</i>, para '
                       f'achar o nome de negócios sem nome fantasia). Salve todos os .zip numa pasta, sem extrair, '
                       f'e escolha-a acima. Os arquivos são grandes (alguns GB) e a leitura pode levar minutos.<br><br>'
                       f'Dados do OpenStreetMap: © contribuidores do OpenStreetMap (licença ODbL).')
        help_.setWordWrap(True); help_.setOpenExternalLinks(True)
        root = QVBoxLayout(self)
        for w in (title, self.use_receita, self.use_osm, QLabel("Pasta dos arquivos da Receita:")):
            root.addWidget(w)
        root.addLayout(row); root.addWidget(save); root.addWidget(self.status); root.addWidget(help_)
        about = QLabel(f"Prospector {__version__} — pasta de dados e log: {settings.data_dir}")
        about.setWordWrap(True); about.setTextInteractionFlags(Qt.TextSelectableByMouse)
        root.addWidget(about); root.addStretch()
        self._update_status()

    def _browse(self) -> None:
        d = QFileDialog.getExistingDirectory(self, "Pasta dos arquivos da Receita", self.folder.text())
        if d:
            self.folder.setText(d); self._update_status()

    def _update_status(self) -> None:
        missing = ReceitaSource.missing_files(self.folder.text().strip() or None)
        self.status.setText("✔ Arquivos da Receita encontrados." if not missing
                            else "⚠ Receita indisponível — faltando: " + "; ".join(missing))

    def _save(self) -> None:
        self.prefs.use_receita, self.prefs.use_osm = self.use_receita.isChecked(), self.use_osm.isChecked()
        self.prefs.receita_dir = self.folder.text().strip()
        try:
            self.prefs.save(self.settings.prefs_path)
            self._update_status(); self.changed.emit()
        except OSError:
            self.status.setText("⚠ Não foi possível salvar as configurações.")


class HistoryPage(QWidget):
    HEADERS = ["Data (UTC)", "Cidade", "Categoria", "Raio", "Fonte", "Encontradas"]

    def __init__(self, repo: CompanyRepository):
        super().__init__()
        self.repo = repo
        title = QLabel("Histórico de pesquisas"); title.setObjectName("title")
        self.table = QTableWidget(0, len(self.HEADERS)); self.table.setHorizontalHeaderLabels(self.HEADERS)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.horizontalHeader().setStretchLastSection(True)
        root = QVBoxLayout(self); root.addWidget(title); root.addWidget(self.table)

    def refresh(self) -> None:
        rows = self.repo.list_search_history()
        self.table.setRowCount(len(rows))
        for i, r in enumerate(rows):
            vals = [r["created_at"].replace("T", " ")[:19], r["city"], r["category"],
                    f"{r['radius_km']:g} km" if r["radius_km"] else "cidade inteira", r["source"], str(r["found"])]
            for j, v in enumerate(vals):
                self.table.setItem(i, j, QTableWidgetItem(v))
