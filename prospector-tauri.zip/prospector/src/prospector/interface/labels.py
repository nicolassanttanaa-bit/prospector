from __future__ import annotations

from datetime import datetime, timezone

from prospector.models.company import LeadStatus, SiteStatus

NA = "Não encontrado"
SITE_LABELS = {SiteStatus.NO_SITE.value: "Sem site identificado", SiteStatus.HAS_SITE.value: "Possui site",
               SiteStatus.INCONCLUSIVE.value: "Inconclusiva"}
LEAD_LABELS = {LeadStatus.NEW.value: "Novo lead", LeadStatus.NOT_CONTACTED.value: "Ainda não contatado",
               LeadStatus.FIRST_CONTACT.value: "Primeiro contato realizado",
               LeadStatus.AWAITING.value: "Aguardando resposta", LeadStatus.INTERESTED.value: "Interessado",
               LeadStatus.NEGOTIATING.value: "Negociação em andamento", LeadStatus.CLOSED_WON.value: "Cliente fechado",
               LeadStatus.NOT_INTERESTED.value: "Não interessado"}
SITE_STATE_LABELS = {"funcionando": "funcionando", "redirecionado": "funcionando (com redirecionamento)",
                     "indisponivel": "indisponível no momento", "erro_de_conexao": "erro de conexão",
                     "dominio_invalido": "domínio inválido", "inconclusivo": "inconclusivo"}
SOURCE_LABELS = {"receita_cnpj": "Receita Federal (CNPJ)", "osm": "OpenStreetMap", "manual": "Cadastro manual"}


def site_label(row) -> str:
    if row["site_checked_at"] is None:
        return "Não verificada"
    return SITE_LABELS.get(row["site_status"], row["site_status"])


def confidence_label(value: float | None) -> str:
    if value is None:
        return "—"
    level = "alta" if value >= 0.9 else "média" if value >= 0.6 else "baixa"
    return f"{value:.0%} ({level})"


def short_social(url: str | None) -> str:
    if not url:
        return NA
    for host in ("instagram.com/", "facebook.com/"):
        if host in url:
            handle = url.split(host, 1)[1].strip("/").split("/")[0].split("?")[0]
            return ("@" + handle) if host.startswith("insta") and handle else (handle or url)
    return url


def fmt_local(iso: str | None, date_only: bool = False) -> str:
    """Converte o horário UTC guardado no banco para o horário local do computador."""
    if not iso:
        return "—"
    try:
        dt = datetime.fromisoformat(iso)
    except ValueError:
        return iso
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone().strftime("%d/%m/%Y" if date_only else "%d/%m/%Y %H:%M")
