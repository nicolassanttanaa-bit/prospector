from __future__ import annotations

from PySide6.QtCore import QAbstractTableModel, QModelIndex, Qt
from PySide6.QtGui import QBrush, QColor

from prospector.interface.labels import LEAD_LABELS, NA, confidence_label, fmt_local, short_social, site_label

HEADERS = ["Nome", "Categoria", "Cidade", "Telefone", "Site", "Instagram", "Avaliação",
           "Situação do site", "Confiança", "Status comercial", "Último contato"]
COL_RATING, COL_SITE_STATUS, COL_CONFIDENCE = 6, 7, 8
STATUS_COLORS = {"Sem site identificado": "#4ade80", "Possui site": "#9aa3b2",
                 "Inconclusiva": "#fbbf24", "Não verificada": "#7c8396"}


def cell_text(row, col: int) -> str:
    if col == 0:
        return ("★ " if row["favorite"] else "") + row["name"]
    if col in (1, 2):
        return row["category" if col == 1 else "city"] or NA
    if col == 3:
        return row["phone"] or NA
    if col == 4:
        return row["site_url"] or row["website"] or NA
    if col == 5:
        return short_social(row["instagram"])
    if col == COL_RATING:
        if row["rating"] is None:
            return "Não disponível"
        return f"{row['rating']:.1f}" + (f" ({row['rating_count']})" if row["rating_count"] else "")
    if col == COL_SITE_STATUS:
        return site_label(row)
    if col == COL_CONFIDENCE:
        return confidence_label(row["site_confidence"]) if row["site_checked_at"] else "—"
    if col == 9:
        return LEAD_LABELS.get(row["lead_status"], row["lead_status"])
    return fmt_local(row["last_contact_at"], date_only=True)


def sort_key(row, col: int):
    if col == 0:
        return row["name"].lower()      # sem a estrela das favoritas, para ordenar só pelo nome
    if col == COL_RATING:
        return row["rating"] if row["rating"] is not None else -1.0
    if col == COL_CONFIDENCE:
        return row["site_confidence"] if row["site_checked_at"] and row["site_confidence"] is not None else -1.0
    return cell_text(row, col).lower()


class CompanyTableModel(QAbstractTableModel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._rows: list = []

    def set_rows(self, rows) -> None:
        self.beginResetModel(); self._rows = list(rows); self.endResetModel()

    @property
    def rows(self) -> list:
        return self._rows

    def company_id(self, row: int) -> int:
        return self._rows[row]["id"]

    def rowCount(self, parent=QModelIndex()) -> int:
        return 0 if parent.isValid() else len(self._rows)

    def columnCount(self, parent=QModelIndex()) -> int:
        return 0 if parent.isValid() else len(HEADERS)

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if role == Qt.DisplayRole and orientation == Qt.Horizontal:
            return HEADERS[section]
        return None

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid():
            return None
        row, col = self._rows[index.row()], index.column()
        if role == Qt.DisplayRole:
            return cell_text(row, col)
        if role == Qt.UserRole:
            return sort_key(row, col)
        if role == Qt.ForegroundRole and col == COL_SITE_STATUS:
            return QBrush(QColor(STATUS_COLORS.get(cell_text(row, col), "#e6e8ee")))
        return None
