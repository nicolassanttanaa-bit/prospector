from __future__ import annotations

from datetime import date
from pathlib import Path

from PySide6.QtCore import QSortFilterProxyModel, Qt, QTimer
from PySide6.QtWidgets import QApplication, QFileDialog, QMessageBox, QPushButton
from PySide6.QtWidgets import (QAbstractItemView, QCheckBox, QComboBox, QDoubleSpinBox, QHBoxLayout, QLabel,
                               QLineEdit, QMenu, QTableView, QVBoxLayout, QWidget)

from prospector.database.repository import CompanyFilter, CompanyRepository
from prospector.exports.exporter import FORMATS, ExportError, describe_filter, export_companies
from prospector.interface.companies_model import COL_CONFIDENCE, CompanyTableModel
from prospector.interface.company_dialog import CompanyDialog
from prospector.interface.labels import LEAD_LABELS
from prospector.models.company import LeadStatus, SiteStatus

SITE_CHOICES = [("Todas as situações", None), ("Sem site identificado", SiteStatus.NO_SITE.value),
                ("Possui site", SiteStatus.HAS_SITE.value), ("Inconclusiva", SiteStatus.INCONCLUSIVE.value),
                ("Não verificada", "unchecked")]


class CompaniesPage(QWidget):
    """Lista filtrável. `fixed` fixa critérios da tela (site_status, site_checked, favorites_only)."""

    def __init__(self, repo: CompanyRepository, title: str, fixed: dict | None = None, sort_confidence: bool = False):
        super().__init__()
        self.repo, self.fixed = repo, fixed or {}
        self.title_text = title
        heading = QLabel(title); heading.setObjectName("title")
        self.search = QLineEdit(); self.search.setPlaceholderText("Buscar por nome, categoria ou cidade…")
        self.category = QLineEdit(); self.category.setPlaceholderText("Categoria")
        self.city = QLineEdit(); self.city.setPlaceholderText("Cidade")
        self.site_combo = QComboBox()
        for label, value in SITE_CHOICES:
            self.site_combo.addItem(label, value)
        self.site_combo.setVisible("site_status" not in self.fixed and "site_checked" not in self.fixed)
        self.lead_combo = QComboBox(); self.lead_combo.addItem("Qualquer status comercial", None)
        for s in LeadStatus:
            self.lead_combo.addItem(LEAD_LABELS[s.value], s.value)
        self.contact_combo = QComboBox()
        for label, value in (("Contatadas ou não", None), ("Ainda não contatadas", False), ("Já contatadas", True)):
            self.contact_combo.addItem(label, value)
        self.phone_chk = QCheckBox("Com telefone"); self.ig_chk = QCheckBox("Com Instagram")
        self.fav_chk = QCheckBox("Só favoritas"); self.fav_chk.setVisible("favorites_only" not in self.fixed)
        self.rating = QDoubleSpinBox(); self.rating.setRange(0, 5); self.rating.setSingleStep(0.5)
        self.rating.setSpecialValueText("Qualquer avaliação"); self.rating.setPrefix("Mín. ")
        self.rating.setToolTip("As fontes atuais (Receita e OpenStreetMap) não trazem avaliações.")
        self.count = QLabel()
        # Os modelos pertencem à tabela: o Qt destrói a tabela primeiro e os modelos depois (evita crash ao fechar).
        self.table = QTableView()
        self.model, self.proxy = CompanyTableModel(self.table), QSortFilterProxyModel(self.table)
        self.proxy.setSourceModel(self.model); self.proxy.setSortRole(Qt.UserRole)
        self.table.setModel(self.proxy)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows); self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers); self.table.setAlternatingRowColors(True)
        self.table.setSortingEnabled(True); self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.doubleClicked.connect(self._open_details)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._context_menu)
        if sort_confidence:
            self.table.sortByColumn(COL_CONFIDENCE, Qt.DescendingOrder)
        self._timer = QTimer(self); self._timer.setSingleShot(True); self._timer.setInterval(250)
        self._timer.timeout.connect(self.refresh)
        for w in (self.search, self.category, self.city):
            w.textChanged.connect(self._timer.start)
        for w in (self.site_combo, self.lead_combo, self.contact_combo):
            w.currentIndexChanged.connect(self.refresh)
        for w in (self.phone_chk, self.ig_chk, self.fav_chk):
            w.toggled.connect(self.refresh)
        self.rating.valueChanged.connect(self.refresh)
        row1, row2 = QHBoxLayout(), QHBoxLayout()
        for w in (self.search, self.category, self.city):
            row1.addWidget(w)
        for w in (self.site_combo, self.lead_combo, self.contact_combo, self.rating, self.phone_chk, self.ig_chk, self.fav_chk):
            row2.addWidget(w)
        row2.addStretch()
        root = QVBoxLayout(self)
        root.addWidget(heading); root.addLayout(row1); root.addLayout(row2)
        self.export_view_btn = QPushButton("Exportar lista filtrada…"); self.export_all_btn = QPushButton("Exportar todas as empresas…")
        self.export_view_btn.clicked.connect(lambda: self._export_clicked(False))
        self.export_all_btn.clicked.connect(lambda: self._export_clicked(True))
        row3 = QHBoxLayout(); row3.addWidget(self.count, 1)
        row3.addWidget(self.export_view_btn); row3.addWidget(self.export_all_btn)
        root.addLayout(row3); root.addWidget(self.table, 1)

    def current_filter(self) -> CompanyFilter:
        site = self.fixed.get("site_status")
        checked = self.fixed.get("site_checked")
        choice = self.site_combo.currentData()
        if choice == "unchecked":
            checked = False
        elif choice:
            site = SiteStatus(choice)
        lead = self.lead_combo.currentData()
        return CompanyFilter(
            text=self.search.text().strip() or None, site_status=site, site_checked=checked,
            only_with_phone=self.phone_chk.isChecked(), only_with_instagram=self.ig_chk.isChecked(),
            min_rating=self.rating.value() or None, category=self.category.text().strip() or None,
            city=self.city.text().strip() or None, contacted=self.contact_combo.currentData(),
            favorites_only=self.fixed.get("favorites_only", False) or self.fav_chk.isChecked(),
            lead_status=LeadStatus(lead) if lead else None)

    def refresh(self) -> None:
        rows = self.repo.search(self.current_filter())
        self.model.set_rows(rows)
        self.table.resizeColumnsToContents()
        self.table.setColumnWidth(0, max(self.table.columnWidth(0), 240))
        total = len(rows)
        self.count.setText(f"{total} empresa(s). Dois cliques abrem os detalhes; clique direito para favoritar ou mudar o status." if total
                           else "Nenhuma empresa para estes filtros. Faça uma pesquisa em “Nova pesquisa” ou ajuste os filtros.")

    def showEvent(self, event) -> None:  # noqa: N802
        super().showEvent(event)
        self.refresh()

    def _open_details(self, proxy_index) -> None:
        company_id = self.model.company_id(self.proxy.mapToSource(proxy_index).row())
        if CompanyDialog(self.repo, company_id, self).exec():
            self.refresh()

    # --- ações rápidas (clique direito) ---
    def _toggle_favorite(self, company_id: int) -> None:
        self.repo.set_favorite(company_id, not self.repo.get(company_id)["favorite"])
        self.refresh()

    def _set_status(self, company_id: int, status: LeadStatus) -> None:
        self.repo.set_lead_status(company_id, status)
        self.refresh()

    def _context_menu(self, pos) -> None:
        index = self.table.indexAt(pos)
        if not index.isValid():
            return
        company_id = self.model.company_id(self.proxy.mapToSource(index).row())
        row = self.repo.get(company_id)
        menu = QMenu(self)
        fav = menu.addAction("Desmarcar favorita" if row["favorite"] else "★ Marcar como favorita")
        status_menu = menu.addMenu("Alterar status comercial")
        status_actions = {status_menu.addAction(LEAD_LABELS[s.value]): s for s in LeadStatus}
        details = menu.addAction("Ver detalhes…")
        chosen = menu.exec(self.table.viewport().mapToGlobal(pos))
        if chosen is fav:
            self._toggle_favorite(company_id)
        elif chosen in status_actions:
            self._set_status(company_id, status_actions[chosen])
        elif chosen is details:
            self._open_details(index)

    # --- exportação ---
    def view_rows(self) -> list:
        """Linhas na ordem em que aparecem na tabela (respeita a ordenação por coluna)."""
        return [self.model.rows[self.proxy.mapToSource(self.proxy.index(i, 0)).row()]
                for i in range(self.proxy.rowCount())]

    def _do_export(self, rows, path, fmt: str, description: str) -> int:
        return export_companies(self.repo, rows, path, fmt, description)

    def _export_clicked(self, all_companies: bool) -> None:
        rows = self.repo.search() if all_companies else self.view_rows()
        if not rows:
            QMessageBox.information(self, "Exportar", "Não há empresas para exportar com os filtros atuais.")
            return
        description = ("todas as empresas (sem filtros)" if all_companies
                       else f"{self.title_text} — {describe_filter(self.current_filter())}")
        slug = "todas" if all_companies else "".join(c if c.isalnum() else "_" for c in self.title_text.lower())[:30]
        default = str(Path.home() / f"prospector_{slug}_{date.today():%Y%m%d}.xlsx")
        path, selected = QFileDialog.getSaveFileName(self, "Exportar empresas", default, ";;".join(f[0] for f in FORMATS))
        if not path:
            return
        _, fmt, ext = next((f for f in FORMATS if f[0] == selected), FORMATS[0])
        if not path.lower().endswith(ext):
            path += ext
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            count = self._do_export(rows, path, fmt, description)
        except ExportError as e:
            QMessageBox.warning(self, "Exportar", str(e)); return
        finally:
            QApplication.restoreOverrideCursor()
        QMessageBox.information(self, "Exportar", f"{count} empresa(s) exportada(s) para:\n{path}")
