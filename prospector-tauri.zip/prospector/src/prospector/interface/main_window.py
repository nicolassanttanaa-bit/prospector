from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QApplication, QMessageBox, QGridLayout, QHBoxLayout, QLabel, QListWidget, QMainWindow, QStackedWidget,
                               QVBoxLayout, QWidget)

from prospector import __version__
from prospector.config.prefs import Prefs
from prospector.config.settings import Settings
from prospector.database.repository import CompanyRepository
from prospector.interface.companies_page import CompaniesPage
from prospector.interface.search_page import SearchPage
from prospector.interface.settings_pages import HistoryPage, SettingsPage
from prospector.models.company import SiteStatus

SECTIONS = ["Dashboard", "Nova pesquisa", "Empresas encontradas", "Empresas sem site",
            "Empresas com site", "Situação inconclusiva", "Empresas favoritas",
            "Histórico de pesquisas", "Configurações"]

STYLE = """
QMainWindow, QWidget, QDialog { background: #14161c; color: #e6e8ee; font-size: 14px; }
QListWidget { background: #0f1116; border: none; padding: 8px; min-width: 210px; }
QListWidget::item { padding: 10px 12px; border-radius: 6px; }
QListWidget::item:selected { background: #2f6df6; color: white; }
QLabel#card { background: #1d2029; border-radius: 10px; padding: 16px; font-size: 15px; }
QLabel#title { font-size: 22px; font-weight: 600; }
QTableView, QPlainTextEdit { background: #1d2029; alternate-background-color: #191c24; gridline-color: #2a2e3a;
    border: 1px solid #2a2e3a; selection-background-color: #2f6df6; }
QHeaderView::section { background: #0f1116; color: #aab0c0; padding: 6px; border: none; }
QLineEdit, QComboBox, QDoubleSpinBox { background: #1d2029; border: 1px solid #2a2e3a; border-radius: 4px; padding: 5px; }
QPushButton { background: #2f6df6; color: white; border: none; border-radius: 6px; padding: 7px 14px; }
QPushButton:disabled { background: #2a2e3a; color: #6b7285; }
QCheckBox::indicator { width: 16px; height: 16px; border: 1px solid #6b7285; border-radius: 3px; background: #1d2029; }
QCheckBox::indicator:checked { background: #2f6df6; border-color: #2f6df6; }
QProgressBar { border: 1px solid #2a2e3a; border-radius: 4px; text-align: center; }
QProgressBar::chunk { background: #2f6df6; }
"""


class DashboardPage(QWidget):
    LABELS = [("total", "Empresas encontradas"), ("sem_site", "Sem site identificado"),
              ("com_site", "Com site"), ("inconclusivo", "Situação inconclusiva"),
              ("nao_verificadas", "Aguardando verificação de site"), ("contatadas", "Contatadas"),
              ("em_andamento", "Oportunidades em andamento")]

    def __init__(self, repo: CompanyRepository):
        super().__init__()
        self.repo = repo
        self.cards: dict[str, QLabel] = {}
        layout = QVBoxLayout(self)
        title = QLabel("Dashboard"); title.setObjectName("title")
        layout.addWidget(title)
        grid = QGridLayout(); layout.addLayout(grid); layout.addStretch()
        for i, (key, _) in enumerate(self.LABELS):
            card = QLabel(); card.setObjectName("card")
            self.cards[key] = card
            grid.addWidget(card, i // 3, i % 3)
        self.refresh()

    def refresh(self) -> None:
        stats = self.repo.stats()
        for key, label in self.LABELS:
            self.cards[key].setText(f"{label}\n\n{stats[key]}")


class MainWindow(QMainWindow):
    def __init__(self, repo: CompanyRepository, settings: Settings, prefs: Prefs):
        super().__init__()
        self.setWindowTitle(f"Prospector {__version__}")
        self.resize(1280, 800)
        self.setStyleSheet(STYLE)
        self.sidebar = QListWidget()
        self.sidebar.addItems(SECTIONS)
        self.pages = QStackedWidget()
        self.dashboard = DashboardPage(repo)
        self.search = SearchPage(settings.db_path, prefs)
        self.history = HistoryPage(repo)
        self.settings_page = SettingsPage(settings, prefs)
        self.search.search_finished.connect(self.dashboard.refresh)
        self.settings_page.changed.connect(self.search.refresh_note)
        self.company_pages = {
            "Empresas encontradas": CompaniesPage(repo, "Empresas encontradas"),
            "Empresas sem site": CompaniesPage(repo, "Empresas sem site identificado",
                                               {"site_status": SiteStatus.NO_SITE, "site_checked": True}, sort_confidence=True),
            "Empresas com site": CompaniesPage(repo, "Empresas com site", {"site_status": SiteStatus.HAS_SITE}),
            "Situação inconclusiva": CompaniesPage(repo, "Situação inconclusiva",
                                                   {"site_status": SiteStatus.INCONCLUSIVE, "site_checked": True}),
            "Empresas favoritas": CompaniesPage(repo, "Empresas favoritas", {"favorites_only": True}),
        }
        special = {"Dashboard": self.dashboard, "Nova pesquisa": self.search,
                   "Histórico de pesquisas": self.history, "Configurações": self.settings_page, **self.company_pages}
        for name in SECTIONS:
            self.pages.addWidget(special[name])
        self.sidebar.currentRowChanged.connect(self._change_page)
        self.sidebar.setCurrentRow(0)
        root = QWidget(); row = QHBoxLayout(root); row.setContentsMargins(0, 0, 0, 0)
        row.addWidget(self.sidebar); row.addWidget(self.pages, 1)
        self.setCentralWidget(root)

    def closeEvent(self, event) -> None:  # noqa: N802
        """Não deixa o programa fechar com pesquisa/verificação rodando (isso derrubaria o processo)."""
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            stopped = self.search.shutdown()
        finally:
            QApplication.restoreOverrideCursor()
        if stopped:
            super().closeEvent(event)
        else:
            QMessageBox.information(self, "Prospector", "Ainda finalizando a tarefa em segundo plano. "
                                                        "Tente fechar novamente em instantes.")
            event.ignore()

    def _change_page(self, index: int) -> None:
        self.pages.setCurrentIndex(index)
        if SECTIONS[index] == "Dashboard":
            self.dashboard.refresh()
        elif SECTIONS[index] == "Histórico de pesquisas":
            self.history.refresh()
