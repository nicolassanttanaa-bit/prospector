from __future__ import annotations

from PySide6.QtCore import Qt, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFormLayout, QGridLayout, QLabel,
                               QLineEdit, QPlainTextEdit, QPushButton, QScrollArea, QVBoxLayout, QWidget)

from prospector.database.repository import MAX_NOTES, CompanyRepository
from prospector.interface.labels import (LEAD_LABELS, NA, SITE_STATE_LABELS, SOURCE_LABELS, confidence_label,
                                         fmt_local, site_label)
from prospector.interface.links import (google_search_url, instagram_search_url, maps_url, normalize_social,
                                        safe_url)
from prospector.models.company import LeadStatus, SiteStatus

CHANNELS = ["WhatsApp", "Ligação", "E-mail", "Instagram", "Presencial", "Outro"]


def open_external(url: str | None) -> None:
    if url and (checked := safe_url(url)):
        QDesktopServices.openUrl(QUrl(checked))


def _label(text: str | None) -> QLabel:
    lbl = QLabel(text or NA); lbl.setWordWrap(True)
    lbl.setTextInteractionFlags(Qt.TextSelectableByMouse)
    return lbl


class CompanyDialog(QDialog):
    def __init__(self, repo: CompanyRepository, company_id: int, parent=None):
        super().__init__(parent)
        self.repo, self.company_id = repo, company_id
        self.row = r = repo.get(company_id)
        self.setWindowTitle(r["name"]); self.resize(780, 860)
        title = QLabel(r["name"]); title.setObjectName("title"); title.setWordWrap(True)

        info = QFormLayout()
        self.phone_label = _label(r["phone"])
        info.addRow("Categoria:", _label(r["category"])); info.addRow("Endereço:", _label(r["address"]))
        info.addRow("Cidade / UF:", _label(" / ".join(x for x in (r["city"], r["state"]) if x)))
        info.addRow("Telefone:", self.phone_label)
        rating = "Não disponível nas fontes atuais" if r["rating"] is None else f"{r['rating']:.1f} ({r['rating_count'] or 0} avaliações)"
        info.addRow("Avaliação no Google:", _label(rating))
        info.addRow("Situação do site:", _label(self._site_summary()))
        self.evidence = _label(r["site_evidence"] or "Site ainda não verificado.")
        info.addRow("Evidências:", self.evidence)
        info.addRow("Fonte dos dados:", _label(SOURCE_LABELS.get(r["source"], r["source"])
                                               + " — dados não verificados por você, salvo os campos que você editar."))
        info.addRow("Descoberta em:", _label(fmt_local(r["discovered_at"])))
        info.addRow("Última verificação do site:", _label(fmt_local(r["site_checked_at"]) if r["site_checked_at"] else "Nunca"))

        edit = QFormLayout()
        self.site_edit = QLineEdit(r["website"] or ""); self.ig_edit = QLineEdit(r["instagram"] or "")
        self.fb_edit = QLineEdit(r["facebook"] or "")
        for w, ph in ((self.site_edit, "https://…"), (self.ig_edit, "@usuario ou link"), (self.fb_edit, "link da página")):
            w.setPlaceholderText(ph)
        edit.addRow("Site:", self.site_edit); edit.addRow("Instagram:", self.ig_edit); edit.addRow("Facebook:", self.fb_edit)
        self.status_combo = QComboBox(); self.status_combo.addItem("Manter a classificação atual", None)
        for s, label in ((SiteStatus.NO_SITE, "Confirmo: sem site"), (SiteStatus.HAS_SITE, "Confirmo: possui site"),
                         (SiteStatus.INCONCLUSIVE, "Marcar como inconclusiva")):
            self.status_combo.addItem(label, s)
        edit.addRow("Definir situação do site:", self.status_combo)

        grid = QGridLayout()
        links = [("Abrir no Google Maps", maps_url(r["name"], r["city"], r["state"])),
                 ("Abrir site", r["site_url"] or r["website"]), ("Abrir Instagram", r["instagram"]),
                 ("Abrir Facebook", r["facebook"]), ("Pesquisar no Google", google_search_url(r["name"], r["city"])),
                 ("Procurar Instagram", instagram_search_url(r["name"], r["city"]))]
        for i, (text, url) in enumerate(links):
            btn = QPushButton(text); btn.setEnabled(bool(safe_url(url)))
            btn.clicked.connect(lambda _=False, u=url: open_external(u))
            grid.addWidget(btn, i // 3, i % 3)

        # --- gestão comercial (Etapa 7)
        crm = QFormLayout()
        self.fav_chk = QCheckBox("★ Favorita"); self.fav_chk.setChecked(bool(r["favorite"]))
        self.lead_combo = QComboBox()
        for s in LeadStatus:
            self.lead_combo.addItem(LEAD_LABELS[s.value], s.value)
        self.lead_combo.setCurrentIndex(self.lead_combo.findData(r["lead_status"]))
        self.last_contact = _label(fmt_local(r["last_contact_at"]) if r["last_contact_at"] else "Nenhum contato registrado")
        self.notes_edit = QPlainTextEdit(r["notes"] or ""); self.notes_edit.setFixedHeight(100)
        self.notes_edit.setPlaceholderText("Ex.: Entrar em contato pelo WhatsApp. Apresentar proposta de site institucional.")
        crm.addRow("", self.fav_chk); crm.addRow("Status comercial:", self.lead_combo)
        crm.addRow("Último contato:", self.last_contact); crm.addRow("Notas:", self.notes_edit)
        self.channel = QComboBox(); self.channel.addItems(CHANNELS)
        self.contact_note = QLineEdit(); self.contact_note.setMaxLength(500); self.contact_note.setPlaceholderText("Resumo do contato (opcional)")
        log_btn = QPushButton("Registrar contato agora"); log_btn.clicked.connect(self._log_contact)
        contact_row = QFormLayout()
        contact_row.addRow("Canal:", self.channel); contact_row.addRow("Resumo:", self.contact_note)
        self.history = QPlainTextEdit(); self.history.setReadOnly(True); self.history.setFixedHeight(110)
        self._reload_history()

        content = QWidget(); cl = QVBoxLayout(content)
        cl.addWidget(title); cl.addLayout(info)
        cl.addWidget(self._section("Links e verificação"))
        cl.addLayout(edit); cl.addLayout(grid)
        cl.addWidget(self._section("Gestão comercial")); cl.addLayout(crm)
        cl.addWidget(self._section("Registrar contato")); cl.addLayout(contact_row); cl.addWidget(log_btn)
        cl.addWidget(self._section("Histórico de contatos")); cl.addWidget(self.history)
        scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setWidget(content)
        self.error = QLabel(); self.error.setWordWrap(True)
        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Close)
        buttons.button(QDialogButtonBox.Save).setText("Salvar"); buttons.button(QDialogButtonBox.Close).setText("Fechar")
        buttons.accepted.connect(self._save); buttons.rejected.connect(self.reject)
        root = QVBoxLayout(self)
        root.addWidget(scroll, 1); root.addWidget(self.error); root.addWidget(buttons)

    @staticmethod
    def _section(text: str) -> QLabel:
        lbl = QLabel(f"<b>{text}</b>"); lbl.setStyleSheet("margin-top: 10px; color: #8fb0ff;")
        return lbl

    def _site_summary(self) -> str:
        r = self.row
        parts = [site_label(r)]
        if r["site_checked_at"]:
            parts.append(f"confiança {confidence_label(r['site_confidence'])}")
            if r["site_state"]:
                parts.append("site " + SITE_STATE_LABELS.get(r["site_state"], r["site_state"]))
        return " — ".join(parts)

    def _reload_history(self) -> None:
        lines = [f"{fmt_local(c['contacted_at'])} — {c['channel'] or 'canal não informado'}"
                 + (f" — {c['note']}" if c["note"] else "") for c in self.repo.list_contacts(self.company_id)]
        self.history.setPlainText("\n".join(lines) if lines else "Nenhum contato registrado ainda.")

    def _log_contact(self) -> None:
        """Grava na hora (não depende do botão Salvar)."""
        self.repo.log_contact(self.company_id, self.channel.currentText(), self.contact_note.text().strip(), advance=True)
        self.row = self.repo.get(self.company_id)
        self.last_contact.setText(fmt_local(self.row["last_contact_at"]))
        self.lead_combo.setCurrentIndex(self.lead_combo.findData(self.row["lead_status"]))
        self.contact_note.clear(); self._reload_history()

    def _save(self) -> None:
        site_raw, ig_raw, fb_raw = (w.text().strip() for w in (self.site_edit, self.ig_edit, self.fb_edit))
        site = safe_url(site_raw)
        ig, fb = normalize_social(ig_raw, "https://instagram.com"), normalize_social(fb_raw, "https://facebook.com")
        for raw, parsed, name in ((site_raw, site, "site"), (ig_raw, ig, "Instagram"), (fb_raw, fb, "Facebook")):
            if raw and not parsed:
                self.error.setText(f"⚠ Endereço de {name} inválido. Use um link http(s) ou, no Instagram, @usuario.")
                return
        notes = self.notes_edit.toPlainText().strip()
        if len(notes) > MAX_NOTES:
            self.error.setText(f"⚠ As notas passam de {MAX_NOTES} caracteres ({len(notes)}). Reduza o texto.")
            return
        self.repo.set_links(self.company_id, site, ig, fb)
        choice = self.status_combo.currentData()
        if choice is None and site and not (self.row["website"] or "").strip():
            choice = SiteStatus.HAS_SITE      # o usuário acabou de informar um site
        if choice:
            self.repo.set_site_manual(self.company_id, choice)
        lead = LeadStatus(self.lead_combo.currentData())
        if lead.value != self.row["lead_status"]:
            self.repo.set_lead_status(self.company_id, lead)
        self.repo.set_favorite(self.company_id, self.fav_chk.isChecked())
        self.repo.set_notes(self.company_id, notes)
        self.accept()
