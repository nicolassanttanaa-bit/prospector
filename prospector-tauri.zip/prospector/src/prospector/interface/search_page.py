from __future__ import annotations

from dataclasses import replace
from pathlib import Path

from PySide6.QtCore import QThread, Signal
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDoubleSpinBox, QFormLayout, QHBoxLayout, QLabel,
                               QLineEdit, QPlainTextEdit, QProgressBar, QPushButton, QVBoxLayout, QWidget)

from prospector.config.prefs import Prefs
from prospector.integrations.base import SearchQuery
from prospector.integrations.cnae import CATEGORIES
from prospector.services.search_service import SearchResult, build_sources
from prospector.services.site_service import VerifyResult
from prospector.workers.search_worker import SearchWorker
from prospector.workers.verify_worker import VerifyWorker


class SearchPage(QWidget):
    search_finished = Signal()

    def __init__(self, db_path: Path, prefs: Prefs):
        super().__init__()
        self.db_path, self.prefs = db_path, prefs
        self._thread: QThread | None = None
        self._worker = None
        title = QLabel("Nova pesquisa"); title.setObjectName("title")
        self.city = QLineEdit(); self.city.setPlaceholderText("Ex.: Campinas, SP")
        self.category = QComboBox(); self.category.setEditable(True)
        self.category.addItems([c.name for c in CATEGORIES]); self.category.setCurrentIndex(-1)
        self.category.lineEdit().setPlaceholderText("Escolha ou digite (ou um CNAE, ex.: 5611-2/03)")
        self.city.setMaxLength(120); self.category.lineEdit().setMaxLength(60)
        self.radius = QDoubleSpinBox(); self.radius.setRange(0, 100); self.radius.setSuffix(" km")
        self.radius.setSpecialValueText("Cidade inteira")
        form = QFormLayout()
        form.addRow("Cidade:", self.city); form.addRow("Categoria:", self.category); form.addRow("Raio:", self.radius)
        self.note = QLabel(); self.note.setWordWrap(True)
        self.auto_verify = QCheckBox("Verificar os sites automaticamente após a pesquisa"); self.auto_verify.setChecked(True)
        self.start_btn = QPushButton("Iniciar pesquisa")
        self.verify_btn = QPushButton("Verificar sites pendentes")
        self.cancel_btn = QPushButton("Cancelar"); self.cancel_btn.setEnabled(False)
        self.start_btn.clicked.connect(self._start); self.verify_btn.clicked.connect(self._verify)
        self.cancel_btn.clicked.connect(self._cancel)
        buttons = QHBoxLayout()
        for b in (self.start_btn, self.verify_btn, self.cancel_btn):
            buttons.addWidget(b)
        buttons.addStretch()
        self.bar = QProgressBar(); self.bar.setRange(0, 100)
        self.found = QLabel("Empresas encontradas: 0"); self.status = QLabel("Pronto."); self.status.setWordWrap(True)
        self.log = QPlainTextEdit(); self.log.setReadOnly(True)
        root = QVBoxLayout(self)
        root.addWidget(title); root.addWidget(self.note); root.addLayout(form)
        root.addWidget(self.auto_verify); root.addLayout(buttons)
        for w in (self.bar, self.found, self.status, self.log):
            root.addWidget(w)
        self.refresh_note()

    def refresh_note(self) -> None:
        names = [s.label for s in build_sources(self.prefs)] or ["nenhuma (ative em Configurações)"]
        self.note.setText("Fontes ativas: " + ", ".join(names) + ". O raio só vale para o OpenStreetMap; a Receita "
                          "pesquisa a cidade inteira. Nenhuma fonte cobre todas as empresas.")

    def _set_running(self, running: bool) -> None:
        self.start_btn.setEnabled(not running); self.verify_btn.setEnabled(not running)
        self.cancel_btn.setEnabled(running)

    def _launch(self, worker, on_finished) -> None:
        self.log.clear(); self.bar.setRange(0, 100); self.bar.setValue(0); self._set_running(True)
        self._thread, self._worker = QThread(self), worker
        worker.moveToThread(self._thread)
        self._thread.started.connect(worker.run)
        worker.progress.connect(self._on_progress)
        worker.finished.connect(on_finished); worker.failed.connect(self._on_failed)
        worker.finished.connect(self._thread.quit); worker.failed.connect(self._thread.quit)
        self._thread.finished.connect(worker.deleteLater)
        self._thread.start()

    def _start(self) -> None:
        try:
            query = SearchQuery.parse(self.city.text(), self.category.currentText(), self.radius.value() or None)
        except ValueError as e:
            self.status.setText(f"⚠ {e}"); return
        self.found.setText("Empresas encontradas: 0"); self.status.setText("Iniciando…")
        self._launch(SearchWorker(self.db_path, query, replace(self.prefs)), self._on_search_finished)

    def _verify(self) -> None:
        self.status.setText("Iniciando verificação…")
        self._launch(VerifyWorker(self.db_path), self._on_verified)

    def shutdown(self, timeout_ms: int = 15000) -> bool:
        """Cancela a tarefa em andamento e espera a thread terminar. True se já está parada."""
        if self._thread is None or not self._thread.isRunning():
            return True
        if self._worker is not None:
            self._worker.cancel()
        self._thread.quit()
        return self._thread.wait(timeout_ms)

    def _cancel(self) -> None:
        if self._worker:
            self._worker.cancel(); self.status.setText("Cancelando…"); self.cancel_btn.setEnabled(False)

    def _on_progress(self, pct: int, msg: str, count: int) -> None:
        if pct < 0:
            self.bar.setRange(0, 0)
        else:
            self.bar.setRange(0, 100); self.bar.setValue(pct)
        self.status.setText(msg); self.found.setText(f"Processadas/encontradas: {count}")

    def _on_search_finished(self, r: SearchResult) -> None:
        self._set_running(False); self.bar.setRange(0, 100); self.bar.setValue(100)
        self.found.setText(f"Empresas encontradas: {r.found} ({r.new} novas)")
        self.status.setText("Pesquisa cancelada." if r.cancelled else "Pesquisa concluída.")
        for w in r.warnings:
            self.log.appendPlainText("⚠ " + w)
        for src, n in r.per_source.items():
            self.log.appendPlainText(f"{src}: {n} empresas")
        self.search_finished.emit()
        if self.auto_verify.isChecked() and not r.cancelled and r.found:
            self._thread.wait(2000)   # deixa a thread da pesquisa encerrar antes de iniciar a próxima
            self._verify()

    def _on_verified(self, r: VerifyResult) -> None:
        self._set_running(False); self.bar.setRange(0, 100); self.bar.setValue(100)
        self.status.setText("Verificação cancelada." if r.cancelled else "Verificação concluída.")
        self.found.setText(f"Verificadas: {r.done} de {r.total}")
        self.log.appendPlainText(f"Sem site identificado: {r.no_site} | Com site: {r.has_site} | "
                                 f"Inconclusivas: {r.inconclusive} | Erros: {r.errors}")
        self.search_finished.emit()

    def _on_failed(self, msg: str) -> None:
        self._set_running(False); self.bar.setRange(0, 100); self.status.setText(f"⚠ {msg}")
