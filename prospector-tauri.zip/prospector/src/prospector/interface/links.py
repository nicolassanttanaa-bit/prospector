"""Funções puras para montar e validar links. Abrir um link no navegador não é scraping."""
from __future__ import annotations

import re
from urllib.parse import quote_plus, urlsplit


def safe_url(raw: str | None) -> str | None:
    """Só aceita http/https com domínio; impede abrir file://, javascript:, etc."""
    if not raw or not raw.strip():
        return None
    url = raw.strip()
    if "://" not in url:
        url = "https://" + url
    parts = urlsplit(url)
    if parts.scheme not in ("http", "https") or not parts.hostname or "." not in parts.hostname:
        return None
    return url


def normalize_social(raw: str | None, base: str) -> str | None:
    """Aceita URL completa ou só o @usuário."""
    if not raw or not raw.strip():
        return None
    v = raw.strip()
    if re.fullmatch(r"@[A-Za-z0-9_.]+", v) or re.fullmatch(r"[A-Za-z0-9_]+", v):   # só o usuário
        return f"{base}/{v.lstrip('@')}"
    return safe_url(v)


def maps_url(name: str, city: str | None, state: str | None) -> str:
    query = " ".join(x for x in (name, city, state) if x)
    return "https://www.google.com/maps/search/?api=1&query=" + quote_plus(query)


def google_search_url(name: str, city: str | None) -> str:
    return "https://www.google.com/search?q=" + quote_plus(f'"{name}" {city or ""}'.strip())


def instagram_search_url(name: str, city: str | None) -> str:
    return "https://www.google.com/search?q=" + quote_plus(f'site:instagram.com "{name}" {city or ""}'.strip())
