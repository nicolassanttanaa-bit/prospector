from __future__ import annotations

import sqlite3
from pathlib import Path

SCHEMA_V1 = """
CREATE TABLE companies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source TEXT NOT NULL,
    source_id TEXT NOT NULL,
    name TEXT NOT NULL,
    category TEXT, address TEXT, city TEXT, state TEXT,
    phone TEXT, website TEXT, instagram TEXT, facebook TEXT, maps_url TEXT,
    rating REAL, rating_count INTEGER, lat REAL, lng REAL,
    site_status TEXT NOT NULL DEFAULT 'inconclusivo',
    site_confidence REAL,
    site_checked_at TEXT,
    discovered_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    lead_status TEXT NOT NULL DEFAULT 'novo_lead',
    favorite INTEGER NOT NULL DEFAULT 0,
    notes TEXT NOT NULL DEFAULT '',
    last_contact_at TEXT,
    UNIQUE (source, source_id)
);
CREATE INDEX idx_companies_site ON companies(site_status);
CREATE INDEX idx_companies_city ON companies(city);
CREATE TABLE contact_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    contacted_at TEXT NOT NULL,
    channel TEXT,
    note TEXT NOT NULL DEFAULT ''
);
CREATE TABLE search_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL,
    city TEXT NOT NULL, category TEXT NOT NULL, radius_km REAL,
    source TEXT NOT NULL, found INTEGER NOT NULL DEFAULT 0
);
"""
SCHEMA_V2 = """
ALTER TABLE companies ADD COLUMN site_state TEXT;
ALTER TABLE companies ADD COLUMN site_url TEXT;
ALTER TABLE companies ADD COLUMN site_evidence TEXT;
"""
SCHEMA_V3 = """
ALTER TABLE companies ADD COLUMN links_confirmed INTEGER NOT NULL DEFAULT 0;
"""
SCHEMA_V4 = """
ALTER TABLE companies ADD COLUMN brand_key TEXT;
ALTER TABLE companies ADD COLUMN city_key TEXT;
ALTER TABLE companies ADD COLUMN unit_count INTEGER NOT NULL DEFAULT 1;
CREATE INDEX idx_companies_brand ON companies(brand_key, city_key);
CREATE TABLE company_units (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    source TEXT NOT NULL, source_id TEXT NOT NULL,
    name TEXT, address TEXT, phone TEXT, lat REAL, lng REAL,
    UNIQUE (source, source_id)
);
CREATE INDEX idx_units_company ON company_units(company_id);
CREATE TABLE searches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL,
    city TEXT NOT NULL, state TEXT, category TEXT NOT NULL, radius_km REAL,
    found INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'running'
);
CREATE TABLE search_results (
    search_id INTEGER NOT NULL REFERENCES searches(id) ON DELETE CASCADE,
    company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    PRIMARY KEY (search_id, company_id)
);
"""


def _migrate_v4(conn: sqlite3.Connection) -> None:
    """Pesquisas com resultados próprios + unidades por empresa; une repetidas já existentes."""
    from prospector.database.dedupe import backfill_keys_and_units, merge_duplicates
    conn.executescript(SCHEMA_V4)
    backfill_keys_and_units(conn)
    merge_duplicates(conn)


MIGRATIONS = [SCHEMA_V1, SCHEMA_V2, SCHEMA_V3, _migrate_v4]   # texto SQL ou função(conn)  # índice i => versão i+1


def connect(path: Path | str) -> sqlite3.Connection:
    conn = sqlite3.connect(str(path), timeout=5.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA busy_timeout = 5000")
    conn.execute("PRAGMA journal_mode = WAL")   # a tela lê enquanto a pesquisa em segundo plano grava
    migrate(conn)
    return conn


def migrate(conn: sqlite3.Connection) -> None:
    version = conn.execute("PRAGMA user_version").fetchone()[0]
    for i, script in enumerate(MIGRATIONS[version:], start=version + 1):
        if callable(script):
            script(conn)
        else:
            conn.executescript(script)
        conn.execute(f"PRAGMA user_version = {i}")
    conn.commit()
