from __future__ import annotations

import sqlite3
from dataclasses import dataclass, fields
from datetime import datetime, timezone

from prospector.database.dedupe import recount_units
from prospector.integrations.textutil import normalize
from prospector.models.company import (CONTACTED, IN_PROGRESS, CompanyData,
                                       LeadStatus, SiteStatus)
from prospector.models.names import brand_key

# Campos que a fonte pode atualizar. Dados do usuário (status, notas, favorito) nunca são tocados.
SOURCE_FIELDS = [f.name for f in fields(CompanyData) if f.name not in ("source", "source_id")]


MAX_NOTES = 5000


def _like(text: str) -> str:
    """Padrão LIKE que trata % e _ digitados pelo usuário como texto comum (use com ESCAPE '\\')."""
    return "%" + text.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@dataclass
class CompanyFilter:
    text: str | None = None
    site_status: SiteStatus | None = None
    only_with_phone: bool = False
    only_with_instagram: bool = False
    min_rating: float | None = None
    category: str | None = None
    city: str | None = None
    contacted: bool | None = None       # None = tanto faz
    favorites_only: bool = False
    lead_status: LeadStatus | None = None
    site_checked: bool | None = None    # None = tanto faz


class CompanyRepository:
    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn

    def upsert(self, data: CompanyData, commit: bool = True) -> int:
        return self.upsert_ex(data, commit)[0]

    def upsert_ex(self, data: CompanyData, commit: bool = True) -> tuple[int, bool]:
        """Insere ou complementa. Devolve (id da empresa, se foi criada agora).
        A mesma loja não se repete: (fonte, id) iguais ou mesma marca + cidade (+ estado) viram UMA empresa;
        as demais ocorrências entram como "unidades". Dados do usuário e valores já preenchidos são preservados."""
        now = _now()
        bkey = brand_key(data.name)
        ckey = normalize(data.city) if data.city else None
        row = self.conn.execute("SELECT u.company_id, (c.source = u.source AND c.source_id = u.source_id) AS is_main "
                                "FROM company_units u JOIN companies c ON c.id = u.company_id "
                                "WHERE u.source=? AND u.source_id=?", (data.source, data.source_id)).fetchone()
        if row:                                                   # mesma fonte e mesmo id: atualização
            cid, created = row["company_id"], False
            self._save_unit(cid, data)
            self._update_company(cid, data, now, primary=bool(row["is_main"]))
        else:
            match = None
            if bkey and ckey:                                     # mesma marca na mesma cidade: outra unidade/fonte
                match = self.conn.execute(
                    "SELECT id FROM companies WHERE brand_key=? AND city_key=? AND (state IS NULL OR ? IS NULL OR state=?) "
                    "ORDER BY id LIMIT 1", (bkey, ckey, data.state, data.state)).fetchone()
            if match:
                cid, created = match["id"], False
                self._save_unit(cid, data)
                self._update_company(cid, data, now, primary=False)
                recount_units(self.conn, cid)
            else:
                cols = ["source", "source_id", *SOURCE_FIELDS]
                cur = self.conn.execute(
                    f"INSERT INTO companies ({', '.join(cols)}, brand_key, city_key, discovered_at, updated_at) "
                    f"VALUES ({', '.join('?' * len(cols))}, ?, ?, ?, ?)",
                    [*(getattr(data, c) for c in cols), bkey, ckey, now, now])
                cid, created = cur.lastrowid, True
                self._save_unit(cid, data)
        if commit:
            self.conn.commit()
        return cid, created

    def _save_unit(self, company_id: int, d: CompanyData) -> None:
        self.conn.execute(
            "INSERT INTO company_units (company_id, source, source_id, name, address, phone, lat, lng) "
            "VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(source, source_id) DO UPDATE SET "
            "name=COALESCE(excluded.name, name), address=COALESCE(excluded.address, address), "
            "phone=COALESCE(excluded.phone, phone), lat=COALESCE(excluded.lat, lat), lng=COALESCE(excluded.lng, lng)",
            (company_id, d.source, d.source_id, d.name, d.address, d.phone, d.lat, d.lng))

    def _update_company(self, cid: int, d: CompanyData, now: str, primary: bool) -> None:
        """Registro principal: valores novos substituem os antigos. Outras unidades/fontes só preenchem vazios
        (e trazem site/redes sociais). Links confirmados pelo usuário nunca são sobrescritos."""
        links = ("website", "instagram", "facebook")
        sets, params = [], []
        for f in SOURCE_FIELDS:
            val = getattr(d, f)
            if f in links:
                expr = (f"CASE WHEN links_confirmed=1 THEN {f} ELSE COALESCE(?, {f}) END" if primary
                        else f"CASE WHEN links_confirmed=1 THEN {f} ELSE COALESCE(NULLIF({f},''), ?) END")
            elif primary or f in ("rating", "rating_count"):
                expr = f"COALESCE(?, {f})"
            else:
                expr = f"COALESCE(NULLIF({f},''), ?)"
            sets.append(f"{f} = {expr}"); params.append(val)
        self.conn.execute(f"UPDATE companies SET {', '.join(sets)}, updated_at=? WHERE id=?", [*params, now, cid])

    def list_units(self, company_id: int) -> list[sqlite3.Row]:
        return self.conn.execute("SELECT * FROM company_units WHERE company_id=? ORDER BY id", (company_id,)).fetchall()

    # --- pesquisas: cada uma tem os seus resultados ---
    def create_search(self, city: str, state: str | None, category: str, radius_km: float | None) -> int:
        cur = self.conn.execute("INSERT INTO searches (created_at, city, state, category, radius_km) VALUES (?,?,?,?,?)",
                                (_now(), city, state, category, radius_km))
        self.conn.commit()
        return cur.lastrowid

    def finish_search(self, search_id: int, found: int, status: str) -> None:
        self.conn.execute("UPDATE searches SET found=?, status=? WHERE id=?", (found, status, search_id))
        self.conn.commit()

    def link_result(self, search_id: int, company_id: int) -> None:
        self.conn.execute("INSERT OR IGNORE INTO search_results (search_id, company_id) VALUES (?,?)",
                          (search_id, company_id))

    def list_searches(self, limit: int = 50) -> list[sqlite3.Row]:
        return self.conn.execute("SELECT * FROM searches ORDER BY id DESC LIMIT ?", (limit,)).fetchall()

    def get_search(self, search_id: int) -> sqlite3.Row | None:
        return self.conn.execute("SELECT * FROM searches WHERE id=?", (search_id,)).fetchone()

    def delete_search(self, search_id: int) -> None:
        """Remove a pesquisa do histórico. As empresas continuam salvas (com status, notas e contatos)."""
        self.conn.execute("DELETE FROM searches WHERE id=?", (search_id,))
        self.conn.commit()

    def search_companies(self, search_id: int) -> list[sqlite3.Row]:
        return self.conn.execute("SELECT c.* FROM companies c JOIN search_results r ON r.company_id=c.id "
                                 "WHERE r.search_id=? ORDER BY c.name COLLATE NOCASE", (search_id,)).fetchall()

    def get(self, company_id: int) -> sqlite3.Row | None:
        return self.conn.execute("SELECT * FROM companies WHERE id = ?", (company_id,)).fetchone()

    def search(self, f: CompanyFilter | None = None, order_by: str = "name") -> list[sqlite3.Row]:
        f = f or CompanyFilter()
        where, params = ["1=1"], []
        if f.text:
            where.append("(name LIKE ? ESCAPE '\\' OR category LIKE ? ESCAPE '\\' OR city LIKE ? ESCAPE '\\')")
            params += [_like(f.text)] * 3
        if f.site_status:
            where.append("site_status = ?"); params.append(f.site_status.value)
        if f.only_with_phone:
            where.append("phone IS NOT NULL AND phone != ''")
        if f.only_with_instagram:
            where.append("instagram IS NOT NULL AND instagram != ''")
        if f.min_rating is not None:
            where.append("rating >= ?"); params.append(f.min_rating)
        if f.category:
            where.append("category LIKE ? ESCAPE '\\'"); params.append(_like(f.category))
        if f.city:
            where.append("city LIKE ? ESCAPE '\\'"); params.append(_like(f.city))
        if f.favorites_only:
            where.append("favorite = 1")
        if f.site_checked is not None:
            where.append(f"site_checked_at IS {'NOT ' if f.site_checked else ''}NULL")
        if f.lead_status:
            where.append("lead_status = ?"); params.append(f.lead_status.value)
        if f.contacted is not None:
            marks = ",".join("?" * len(CONTACTED))
            where.append(f"lead_status {'IN' if f.contacted else 'NOT IN'} ({marks})")
            params += [s.value for s in CONTACTED]
        allowed = {"name", "city", "rating", "updated_at", "discovered_at", "lead_status"}
        order = order_by if order_by in allowed else "name"  # evita SQL injection no ORDER BY
        return self.conn.execute(
            f"SELECT * FROM companies WHERE {' AND '.join(where)} ORDER BY {order} COLLATE NOCASE", params
        ).fetchall()

    # --- dados do usuário ---
    def set_lead_status(self, company_id: int, status: LeadStatus) -> None:
        self.conn.execute("UPDATE companies SET lead_status=?, updated_at=? WHERE id=?",
                          (status.value, _now(), company_id))
        self.conn.commit()

    def set_favorite(self, company_id: int, favorite: bool) -> None:
        self.conn.execute("UPDATE companies SET favorite=? WHERE id=?", (int(favorite), company_id))
        self.conn.commit()

    def set_notes(self, company_id: int, notes: str) -> None:
        self.conn.execute("UPDATE companies SET notes=? WHERE id=?", (notes, company_id))
        self.conn.commit()

    def log_contact(self, company_id: int, channel: str = "", note: str = "", advance: bool = False) -> None:
        """Registra um contato. Com advance=True, "novo lead"/"ainda não contatado" viram "primeiro contato"."""
        now = _now()
        self.conn.execute("INSERT INTO contact_history (company_id, contacted_at, channel, note) VALUES (?,?,?,?)",
                          (company_id, now, channel, note))
        self.conn.execute("UPDATE companies SET last_contact_at=? WHERE id=?", (now, company_id))
        if advance:
            self.conn.execute("UPDATE companies SET lead_status=? WHERE id=? AND lead_status IN (?, ?)",
                              (LeadStatus.FIRST_CONTACT.value, company_id,
                               LeadStatus.NEW.value, LeadStatus.NOT_CONTACTED.value))
        self.conn.commit()

    def list_contacts(self, company_id: int) -> list[sqlite3.Row]:
        return self.conn.execute("SELECT * FROM contact_history WHERE company_id=? ORDER BY id DESC",
                                 (company_id,)).fetchall()

    def set_site_status(self, company_id: int, status: SiteStatus, confidence: float | None = None) -> None:
        self.conn.execute("UPDATE companies SET site_status=?, site_confidence=?, site_checked_at=? WHERE id=?",
                          (status.value, confidence, _now(), company_id))
        self.conn.commit()

    def stats(self) -> dict[str, int]:
        """Indicadores do dashboard, calculados só a partir do que está no banco."""
        q = lambda sql, p=(): self.conn.execute(sql, p).fetchone()[0]  # noqa: E731
        marks = lambda seq: ",".join("?" * len(seq))  # noqa: E731
        return {
            "total": q("SELECT COUNT(*) FROM companies"),
            "sem_site": q("SELECT COUNT(*) FROM companies WHERE site_status=?", (SiteStatus.NO_SITE.value,)),
            "com_site": q("SELECT COUNT(*) FROM companies WHERE site_status=?", (SiteStatus.HAS_SITE.value,)),
            "inconclusivo": q("SELECT COUNT(*) FROM companies WHERE site_status=? AND site_checked_at IS NOT NULL",
                              (SiteStatus.INCONCLUSIVE.value,)),
            "nao_verificadas": q("SELECT COUNT(*) FROM companies WHERE site_checked_at IS NULL"),
            "contatadas": q(f"SELECT COUNT(*) FROM companies WHERE lead_status IN ({marks(CONTACTED)})",
                            [s.value for s in CONTACTED]),
            "em_andamento": q(f"SELECT COUNT(*) FROM companies WHERE lead_status IN ({marks(IN_PROGRESS)})",
                              [s.value for s in IN_PROGRESS]),
        }

    def exists(self, source: str, source_id: str) -> bool:
        return self.conn.execute("SELECT 1 FROM company_units WHERE source=? AND source_id=?",
                                 (source, source_id)).fetchone() is not None

    def add_search_history(self, city: str, category: str, radius_km: float | None, source: str, found: int) -> None:
        self.conn.execute("INSERT INTO search_history (created_at, city, category, radius_km, source, found) "
                          "VALUES (?,?,?,?,?,?)", (_now(), city, category, radius_km, source, found))
        self.conn.commit()

    def list_search_history(self, limit: int = 200) -> list[sqlite3.Row]:
        return self.conn.execute("SELECT * FROM search_history ORDER BY id DESC LIMIT ?", (limit,)).fetchall()

    def companies_to_check(self, only_unchecked: bool = True, search_id: int | None = None) -> list[sqlite3.Row]:
        where, params = [], []
        if only_unchecked:
            where.append("site_checked_at IS NULL")
        if search_id is not None:
            where.append("id IN (SELECT company_id FROM search_results WHERE search_id=?)"); params.append(search_id)
        clause = ("WHERE " + " AND ".join(where)) if where else ""
        return self.conn.execute(f"SELECT * FROM companies {clause} ORDER BY id", params).fetchall()

    def save_site_check(self, company_id: int, status: SiteStatus, confidence: float, site_state: str | None,
                        site_url: str | None, evidence: str, instagram: str | None = None,
                        facebook: str | None = None, commit: bool = True) -> None:
        """Grava o resultado da verificação; só preenche redes sociais que ainda estão vazias."""
        self.conn.execute(
            "UPDATE companies SET site_status=?, site_confidence=?, site_checked_at=?, site_state=?, site_url=?, "
            "site_evidence=?, instagram=COALESCE(NULLIF(instagram,''), ?), facebook=COALESCE(NULLIF(facebook,''), ?) "
            "WHERE id=?", (status.value, confidence, _now(), site_state, site_url, evidence, instagram, facebook, company_id))
        if commit:
            self.conn.commit()

    def set_links(self, company_id: int, website: str | None, instagram: str | None, facebook: str | None) -> None:
        """Links informados pelo usuário: passam a valer sobre os das fontes."""
        self.conn.execute("UPDATE companies SET website=?, instagram=?, facebook=?, links_confirmed=1, updated_at=? WHERE id=?",
                          (website, instagram, facebook, _now(), company_id))
        self.conn.commit()

    def set_site_manual(self, company_id: int, status: SiteStatus) -> None:
        self.conn.execute("UPDATE companies SET site_status=?, site_confidence=1.0, site_checked_at=?, site_state=NULL, "
                          "site_evidence='Definido manualmente pelo usuário.' WHERE id=?",
                          (status.value, _now(), company_id))
        self.conn.commit()
