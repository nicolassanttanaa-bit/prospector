"""Une registros repetidos da mesma marca na mesma cidade (usado na migração do banco antigo)."""
from __future__ import annotations

import sqlite3

from prospector.integrations.textutil import normalize
from prospector.models.company import LeadStatus
from prospector.models.names import brand_key

LEAD_ORDER = [s.value for s in (LeadStatus.NEW, LeadStatus.NOT_CONTACTED, LeadStatus.NOT_INTERESTED,
                                LeadStatus.FIRST_CONTACT, LeadStatus.AWAITING, LeadStatus.INTERESTED,
                                LeadStatus.NEGOTIATING, LeadStatus.CLOSED_WON)]
FILL = ("category", "address", "city", "state", "phone", "website", "instagram", "facebook", "maps_url",
        "rating", "rating_count", "lat", "lng")


def recount_units(conn: sqlite3.Connection, company_id: int) -> None:
    """Nº de unidades = maior contagem por fonte (a mesma loja vinda de 2 fontes conta como 1)."""
    n = conn.execute("SELECT COALESCE(MAX(c), 1) FROM (SELECT COUNT(*) c FROM company_units WHERE company_id=? "
                     "GROUP BY source)", (company_id,)).fetchone()[0]
    conn.execute("UPDATE companies SET unit_count=? WHERE id=?", (n, company_id))


def backfill_keys_and_units(conn: sqlite3.Connection) -> None:
    for r in conn.execute("SELECT * FROM companies").fetchall():
        conn.execute("UPDATE companies SET brand_key=?, city_key=? WHERE id=?",
                     (brand_key(r["name"]), normalize(r["city"]) if r["city"] else None, r["id"]))
        conn.execute("INSERT OR IGNORE INTO company_units (company_id, source, source_id, name, address, phone, lat, lng) "
                     "VALUES (?,?,?,?,?,?,?,?)", (r["id"], r["source"], r["source_id"], r["name"], r["address"],
                                                   r["phone"], r["lat"], r["lng"]))
        recount_units(conn, r["id"])


def merge_duplicates(conn: sqlite3.Connection) -> int:
    """Funde empresas com a mesma marca, cidade e estado. Preserva status, notas, favoritos e contatos.
    Devolve quantos registros foram absorvidos."""
    groups = conn.execute("SELECT brand_key, city_key, COALESCE(state, '') st FROM companies "
                          "WHERE brand_key IS NOT NULL AND city_key IS NOT NULL "
                          "GROUP BY brand_key, city_key, st HAVING COUNT(*) > 1").fetchall()
    absorbed = 0
    for g in groups:
        rows = conn.execute("SELECT * FROM companies WHERE brand_key=? AND city_key=? AND COALESCE(state,'')=? "
                            "ORDER BY id", (g["brand_key"], g["city_key"], g["st"])).fetchall()
        main, others = rows[0], rows[1:]
        best_lead = max((r["lead_status"] for r in rows), key=lambda v: LEAD_ORDER.index(v) if v in LEAD_ORDER else 0)
        notes = "\n---\n".join(dict.fromkeys(r["notes"].strip() for r in rows if (r["notes"] or "").strip()))
        last = max((r["last_contact_at"] for r in rows if r["last_contact_at"]), default=None)
        checked = next((r for r in rows if r["site_checked_at"]), None)
        for r in others:
            conn.execute("UPDATE company_units SET company_id=? WHERE company_id=?", (main["id"], r["id"]))
            conn.execute("UPDATE contact_history SET company_id=? WHERE company_id=?", (main["id"], r["id"]))
            conn.execute("INSERT OR IGNORE INTO search_results (search_id, company_id) "
                         "SELECT search_id, ? FROM search_results WHERE company_id=?", (main["id"], r["id"]))
            for f in FILL:   # só preenche o que está vazio no registro principal
                conn.execute(f"UPDATE companies SET {f}=COALESCE(NULLIF({f},''), ?) WHERE id=?", (r[f], main["id"]))
            conn.execute("DELETE FROM companies WHERE id=?", (r["id"],))
            absorbed += 1
        conn.execute("UPDATE companies SET lead_status=?, notes=?, last_contact_at=?, "
                     "favorite=? WHERE id=?", (best_lead, notes, last, int(any(r["favorite"] for r in rows)), main["id"]))
        if main["site_checked_at"] is None and checked is not None:
            conn.execute("UPDATE companies SET site_status=?, site_confidence=?, site_checked_at=?, site_state=?, "
                         "site_url=?, site_evidence=? WHERE id=?",
                         (checked["site_status"], checked["site_confidence"], checked["site_checked_at"],
                          checked["site_state"], checked["site_url"], checked["site_evidence"], main["id"]))
        recount_units(conn, main["id"])
    return absorbed
