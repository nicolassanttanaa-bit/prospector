"""Fonte: OpenStreetMap (Nominatim para localizar a cidade, Overpass para listar estabelecimentos).
Dados sob licença ODbL: exibir a atribuição "© contribuidores do OpenStreetMap"."""
from __future__ import annotations

import time
from typing import Callable, Iterator

import httpx

from prospector.integrations.base import (STATES, Cancelled, Progress, SearchQuery, SourceError,
                                          SourceUnavailable)
from prospector.models.company import CompanyData

NOMINATIM_URL = "https://nominatim.openstreetmap.org/search"
OVERPASS_URL = "https://overpass-api.de/api/interpreter"
HEADERS = {"User-Agent": "Prospector/0.1 (desktop lead prospecting tool)"}
RETRY_STATUS = {429, 502, 503, 504}


def _social(value: str | None, base: str) -> str | None:
    if not value:
        return None
    value = value.strip()
    return value if value.startswith("http") else f"{base}/{value.lstrip('@/')}"


def parse_elements(elements: list[dict], query: SearchQuery) -> list[CompanyData]:
    out = []
    for el in elements:
        if not isinstance(el, dict) or "type" not in el or "id" not in el:
            continue
        t = el.get("tags") or {}
        if not isinstance(t, dict) or not t.get("name"):
            continue
        center = el.get("center") or {}
        street = " ".join(x for x in (t.get("addr:street"), t.get("addr:housenumber")) if x)
        parts = [street, t.get("addr:suburb", ""), f"CEP {t['addr:postcode']}" if t.get("addr:postcode") else ""]
        out.append(CompanyData(
            source="osm", source_id=f"{el['type']}/{el['id']}", name=t["name"],
            category=query.category.name, address=" - ".join(p for p in parts if p) or None,
            city=t.get("addr:city") or query.city, state=t.get("addr:state") or query.state,
            phone=t.get("phone") or t.get("contact:phone"),
            website=t.get("website") or t.get("contact:website"),
            instagram=_social(t.get("contact:instagram"), "https://instagram.com"),
            facebook=_social(t.get("contact:facebook"), "https://facebook.com"),
            lat=el.get("lat", center.get("lat")), lng=el.get("lon", center.get("lon"))))
    return out


class OsmSource:
    name = "osm"
    label = "OpenStreetMap"

    def __init__(self, client: httpx.Client | None = None, sleep: Callable[[float], None] = time.sleep):
        self._client, self._sleep = client, sleep

    def search(self, query: SearchQuery, progress: Progress, cancelled: Cancelled) -> Iterator[CompanyData]:
        if not query.category.osm:
            raise SourceError("esta categoria não tem equivalente no OpenStreetMap.")
        client = self._client or httpx.Client(timeout=120)
        try:
            progress(10, "OpenStreetMap: localizando a cidade…")
            place = self._geocode(client, query)
            if cancelled():
                return
            progress(40, "OpenStreetMap: buscando estabelecimentos (pode levar alguns segundos)…")
            elements = self._overpass(client, self._build_query(query, place))
            progress(90, f"OpenStreetMap: {len(elements)} registros recebidos")
        finally:
            if self._client is None:
                client.close()
        yield from parse_elements(elements, query)

    def _geocode(self, client: httpx.Client, q: SearchQuery) -> dict:
        text = ", ".join(x for x in (q.city, STATES.get(q.state or ""), "Brasil") if x)
        data = self._json(self._request(client, "GET", NOMINATIM_URL,
                                        params={"q": text, "format": "jsonv2", "limit": 1, "countrycodes": "br"}))
        if not data:
            raise SourceError(f"cidade '{q.city}' não encontrada no OpenStreetMap.")
        try:   # valida e converte: coordenadas viram números (nunca texto do servidor dentro da consulta)
            place = data[0]
            osm_id = int(place["osm_id"]) if place.get("osm_id") is not None else None
            return {"lat": float(place["lat"]), "lon": float(place["lon"]),
                    "osm_type": place.get("osm_type"), "osm_id": osm_id}
        except (KeyError, ValueError, TypeError, AttributeError, IndexError) as e:
            raise SourceError("resposta de localização inválida do OpenStreetMap.") from e

    @staticmethod
    def _build_query(q: SearchQuery, place: dict) -> str:
        lat, lon = place["lat"], place["lon"]
        if q.radius_km:
            decl, spatial = "", f"(around:{int(q.radius_km * 1000)},{lat},{lon})"
        elif place.get("osm_type") == "relation":
            decl, spatial = f"area(id:{3600000000 + int(place['osm_id'])})->.a;", "(area.a)"
        else:
            decl, spatial = "", f"(around:5000,{lat},{lon})"
        body = "".join(f"nwr{flt}{spatial};" for flt in q.category.osm)
        return f"[out:json][timeout:90];{decl}({body});out center tags;"

    @staticmethod
    def _json(resp: httpx.Response):
        try:
            return resp.json()
        except ValueError as e:
            raise SourceError("resposta inválida do serviço (não é JSON). Tente novamente mais tarde.") from e

    def _overpass(self, client, query: str) -> list[dict]:
        data = self._json(self._request(client, "POST", OVERPASS_URL, data={"data": query}))
        if not isinstance(data, dict):
            raise SourceError("resposta inválida do serviço.")
        if "runtime error" in str(data.get("remark", "")).lower():   # o Overpass responde 200 mesmo quando estoura o limite
            raise SourceError("a consulta excedeu o limite de tempo ou memória do serviço. "
                              "Tente um raio menor ou outra categoria.")
        elements = data.get("elements", [])
        return elements if isinstance(elements, list) else []

    def _request(self, client: httpx.Client, method: str, url: str, **kw) -> httpx.Response:
        for attempt in range(3):
            try:
                resp = client.request(method, url, headers=HEADERS, **kw)
            except httpx.HTTPError as e:
                raise SourceUnavailable(f"falha de conexão ({type(e).__name__}). Verifique sua internet.") from e
            if resp.status_code in RETRY_STATUS and attempt < 2:
                self._sleep(5 * (attempt + 1))
                continue
            if resp.status_code in RETRY_STATUS:
                raise SourceUnavailable("serviço temporariamente indisponível ou com limite de uso atingido. Tente mais tarde.")
            if resp.status_code >= 400:
                raise SourceError(f"resposta inesperada do serviço (HTTP {resp.status_code}).")
            return resp
        raise SourceUnavailable("serviço indisponível.")
