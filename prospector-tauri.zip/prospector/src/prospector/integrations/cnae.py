"""Categorias comerciais -> código CNAE (Receita) e filtros do OpenStreetMap.
Os códigos CNAE devem ser conferidos na tabela oficial da CONCLA/IBGE; para outras
atividades o usuário pode digitar o CNAE diretamente (ex.: 5611-2/03)."""
from __future__ import annotations

import re
from dataclasses import dataclass

from prospector.integrations.textutil import normalize


@dataclass(frozen=True)
class Category:
    name: str
    cnaes: tuple[str, ...] = ()
    osm: tuple[str, ...] = ()        # filtros Overpass, ex.: '["amenity"="fast_food"]'
    aliases: tuple[str, ...] = ()


CATEGORIES: tuple[Category, ...] = (
    Category("Lanchonetes", ("5611203",), ('["amenity"="fast_food"]',), ("lanche",)),
    Category("Restaurantes", ("5611201",), ('["amenity"="restaurant"]',)),
    Category("Pizzarias", ("5611201",), ('["amenity"="restaurant"]["cuisine"~"pizza"]',), ("pizza",)),
    Category("Barbearias", ("9602501",), ('["shop"="hairdresser"]',), ("barbeiro",)),
    Category("Salões de beleza", ("9602501", "9602502"), ('["shop"="hairdresser"]', '["shop"="beauty"]'),
             ("salao", "cabeleireiro", "estetica")),
    Category("Escritórios de advocacia", ("6911701",), ('["office"="lawyer"]',), ("advogado", "advocacia")),
    Category("Clínicas odontológicas", ("8630504",), ('["amenity"="dentist"]', '["healthcare"="dentist"]'),
             ("dentista", "odontologica")),
    Category("Academias", ("9313100",), ('["leisure"="fitness_centre"]',)),
    Category("Oficinas mecânicas", ("4520001",), ('["shop"="car_repair"]',), ("mecanica", "oficina")),
    Category("Pet shops", ("4789004",), ('["shop"="pet"]',), ("pet",)),
    Category("Lojas de roupas", ("4781400",), ('["shop"="clothes"]',), ("roupa", "vestuario")),
    Category("Imobiliárias", ("6821801", "6821802"), ('["office"="estate_agent"]',), ("imobiliaria",)),
    Category("Contabilidades", ("6920601",), ('["office"="accountant"]',), ("contador", "contabilidade")),
)


def _key(s: str) -> str:
    return normalize(s).rstrip("S")


def find_category(text: str) -> Category:
    text = text.strip()
    digits = re.sub(r"\D", "", text)
    if len(digits) == 7 and re.fullmatch(r"[\d\-/.\s]+", text):
        return Category(name=f"CNAE {text}", cnaes=(digits,))
    k = _key(text)
    if len(k) >= 3:
        for c in CATEGORIES:
            if k == _key(c.name) or k in _key(c.name) or any(k == _key(a) or k in _key(a) for a in c.aliases):
                return c
    names = ", ".join(c.name for c in CATEGORIES)
    raise ValueError(f"Categoria '{text}' não reconhecida. Use uma de: {names} — ou digite um código CNAE (ex.: 5611-2/03).")
