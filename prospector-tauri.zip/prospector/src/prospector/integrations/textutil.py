import unicodedata


def normalize(text: str) -> str:
    """Maiúsculas e sem acentos, para comparar nomes de cidades/categorias."""
    s = unicodedata.normalize("NFD", text)
    return "".join(c for c in s if unicodedata.category(c) != "Mn").upper().strip()
