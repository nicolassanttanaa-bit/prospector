from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Iterator, Protocol

from prospector.integrations.cnae import Category, find_category
from prospector.integrations.textutil import normalize
from prospector.models.company import CompanyData

STATES = {"AC": "Acre", "AL": "Alagoas", "AP": "Amapá", "AM": "Amazonas", "BA": "Bahia", "CE": "Ceará",
          "DF": "Distrito Federal", "ES": "Espírito Santo", "GO": "Goiás", "MA": "Maranhão",
          "MT": "Mato Grosso", "MS": "Mato Grosso do Sul", "MG": "Minas Gerais", "PA": "Pará",
          "PB": "Paraíba", "PR": "Paraná", "PE": "Pernambuco", "PI": "Piauí", "RJ": "Rio de Janeiro",
          "RN": "Rio Grande do Norte", "RS": "Rio Grande do Sul", "RO": "Rondônia", "RR": "Roraima",
          "SC": "Santa Catarina", "SP": "São Paulo", "SE": "Sergipe", "TO": "Tocantins"}

# progress(percentual 0-100 ou None se indeterminado, mensagem)
Progress = Callable[[int | None, str], None]
Cancelled = Callable[[], bool]


class SourceError(Exception):
    """Falha de uma fonte; a mensagem é mostrada ao usuário."""


class SourceUnavailable(SourceError):
    """Fonte indisponível/não configurada (rede, limite de uso, arquivos ausentes)."""


def _clean(text: str | None, field: str, max_len: int) -> str:
    t = (text or "").strip()
    if any(ord(c) < 32 for c in t):
        raise ValueError(f"{field} contém caracteres inválidos.")
    if len(t) > max_len:
        raise ValueError(f"{field} é longa demais (máximo {max_len} caracteres).")
    return t


@dataclass(frozen=True)
class SearchQuery:
    city: str
    state: str | None           # UF com 2 letras
    category: Category
    radius_km: float | None = None

    @classmethod
    def parse(cls, city_text: str, category_text: str, radius_km: float | None = None) -> "SearchQuery":
        parts = [p.strip() for p in _clean(city_text, "A cidade", 120).split(",")]
        city = parts[0]
        if len(city) < 2:
            raise ValueError("Informe a cidade (ex.: Campinas, SP).")
        state = None
        if len(parts) > 1 and parts[1]:
            raw = normalize(parts[1])
            state = next((uf for uf, n in STATES.items() if raw == uf or raw == normalize(n)), None)
            if state is None:
                raise ValueError(f"Estado '{parts[1]}' não reconhecido. Use a sigla (SP) ou o nome completo.")
        if radius_km is not None and not (0 < radius_km <= 100):
            raise ValueError("O raio deve estar entre 1 e 100 km (ou vazio para a cidade inteira).")
        return cls(city=city, state=state, category=find_category(_clean(category_text, "A categoria", 60)), radius_km=radius_km)


class CompanySource(Protocol):
    name: str
    label: str

    def search(self, query: SearchQuery, progress: Progress, cancelled: Cancelled) -> Iterator[CompanyData]: ...
