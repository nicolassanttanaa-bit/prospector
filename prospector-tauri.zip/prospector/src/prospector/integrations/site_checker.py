"""Verificação técnica e segura de endereços de sites.
Regras: só http/https; bloqueia endereços internos (anti-SSRF) em cada redirecionamento; limita tempo,
redirecionamentos e tamanho lido; NÃO tenta contornar CAPTCHA, login ou proteção anti-robô."""
from __future__ import annotations

import ipaddress
import socket
from dataclasses import dataclass
from enum import Enum
from typing import Callable
from urllib.parse import urljoin, urlsplit

import httpx

HEADERS = {"User-Agent": "Prospector/0.1 (desktop lead prospecting tool)"}
MAX_HOPS, MAX_BYTES = 5, 100_000
REDIRECTS = {301, 302, 303, 307, 308}
CHALLENGE = ("captcha", "cf-chk", "just a moment", "attention required", "access denied", "are you a robot")


class SiteState(str, Enum):
    WORKING = "funcionando"
    REDIRECTED = "redirecionado"
    UNAVAILABLE = "indisponivel"          # erro 5xx ou tempo esgotado
    CONNECTION_ERROR = "erro_de_conexao"
    INVALID_DOMAIN = "dominio_invalido"   # não existe, ou endereço bloqueado por segurança
    INCONCLUSIVE = "inconclusivo"         # proteção anti-robô, 4xx, laço de redirecionamentos


class DnsTemporaryError(Exception):
    """Falha de DNS que não prova inexistência do domínio."""


_NOT_FOUND = {getattr(socket, n) for n in ("EAI_NONAME", "EAI_NODATA") if hasattr(socket, n)} | {11001, 11004}


def default_resolver(host: str) -> list[str]:
    """Lista de IPs; lista vazia = domínio não existe."""
    try:
        infos = socket.getaddrinfo(host, None, type=socket.SOCK_STREAM)
    except socket.gaierror as e:
        if e.errno in _NOT_FOUND:
            return []
        raise DnsTemporaryError(str(e)) from e
    return sorted({i[4][0] for i in infos})


@dataclass
class FetchResult:
    state: SiteState
    final_url: str | None = None
    status: int | None = None
    text: str = ""


def _is_public(ip: str) -> bool:
    try:
        return ipaddress.ip_address(ip).is_global
    except ValueError:
        return False


def _port_ok(parts) -> bool:
    try:
        return parts.port in (None, 80, 443, 8080, 8443)   # evita usar o app para sondar outras portas
    except ValueError:
        return False


class SiteChecker:
    def __init__(self, client: httpx.Client | None = None, resolver: Callable[[str], list[str]] = default_resolver):
        self._own_client = client is None
        self._client = client or httpx.Client(timeout=8.0, headers=HEADERS, follow_redirects=False)
        self._resolver = resolver

    def close(self) -> None:
        if self._own_client:
            self._client.close()

    def has_internet(self) -> bool:
        for host in ("example.com", "www.google.com"):
            try:
                if self._resolver(host):
                    return True
            except DnsTemporaryError:
                continue
        return False

    def domain_exists(self, host: str) -> bool | None:
        """True/False, ou None quando a consulta de DNS falhou temporariamente."""
        try:
            return bool(self._resolver(host))
        except DnsTemporaryError:
            return None

    def fetch(self, url: str) -> FetchResult:
        current, hops = url, 0
        while True:
            parts = urlsplit(current)
            if parts.scheme not in ("http", "https") or not parts.hostname or not _port_ok(parts):
                return FetchResult(SiteState.INVALID_DOMAIN, current)
            try:
                ips = self._resolver(parts.hostname)
            except DnsTemporaryError:
                return FetchResult(SiteState.CONNECTION_ERROR, current)
            if not ips or not all(_is_public(ip) for ip in ips):
                return FetchResult(SiteState.INVALID_DOMAIN, current)
            try:
                with self._client.stream("GET", current) as resp:
                    status = resp.status_code
                    location = resp.headers.get("location")
                    if status in REDIRECTS and location:
                        hops += 1
                        if hops > MAX_HOPS:
                            return FetchResult(SiteState.INCONCLUSIVE, current, status)
                        current = urljoin(current, location)
                        continue
                    body = b""
                    for chunk in resp.iter_bytes():
                        body += chunk
                        if len(body) >= MAX_BYTES:
                            break
                    text = body[:MAX_BYTES].decode(resp.encoding or "utf-8", errors="replace").lower()
            except httpx.TimeoutException:
                return FetchResult(SiteState.UNAVAILABLE, current)
            except httpx.HTTPError:
                return FetchResult(SiteState.CONNECTION_ERROR, current)
            return FetchResult(self._interpret(status, text, hops), current, status, text)

    @staticmethod
    def _interpret(status: int, text: str, hops: int) -> SiteState:
        if 200 <= status < 300:
            return SiteState.REDIRECTED if hops else SiteState.WORKING
        if status in (401, 403, 429) or any(m in text for m in CHALLENGE):
            return SiteState.INCONCLUSIVE
        return SiteState.UNAVAILABLE if status >= 500 else SiteState.INCONCLUSIVE
