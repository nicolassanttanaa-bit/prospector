"""Fonte: Dados Abertos do CNPJ (Receita Federal), lidos de arquivos .zip baixados pelo usuário.
Sem scraping: são arquivos públicos oficiais. Layout (CSV, separador ';', sem cabeçalho):
Estabelecimentos: 0 CNPJ básico, 1 ordem, 2 DV, 4 nome fantasia, 5 situação (02 = ativa),
11 CNAE principal, 13-18 endereço, 19 UF, 20 município (código da Receita), 21-22 DDD/telefone 1.
Municipios: código;descrição.  Empresas: 0 CNPJ básico, 1 razão social."""
from __future__ import annotations

import csv
import fnmatch
import re
import zipfile
import zlib
from pathlib import Path
from typing import Iterator

from prospector.integrations.base import (Cancelled, Progress, SearchQuery, SourceError,
                                          SourceUnavailable)
from prospector.integrations.textutil import normalize
from prospector.models.company import CompanyData

ENCODING = "latin-1"
ATIVA = "02"
C_BASICO, C_ORDEM, C_DV, C_FANTASIA, C_SITUACAO, C_CNAE = 0, 1, 2, 4, 5, 11
C_TIPO, C_LOGR, C_NUM, C_COMPL, C_BAIRRO, C_CEP, C_UF, C_MUN, C_DDD, C_TEL = 13, 14, 15, 16, 17, 18, 19, 20, 21, 22
MIN_COLS = 23


def _find(folder: Path, pattern: str) -> list[Path]:
    return sorted(p for p in folder.iterdir() if fnmatch.fnmatch(p.name.lower(), pattern.lower()))


def _raw_lines(zip_path: Path) -> Iterator[bytes]:
    try:
        with zipfile.ZipFile(zip_path) as zf:
            names = zf.namelist()
            if not names:
                raise SourceError(f"o arquivo {zip_path.name} está vazio.")
            with zf.open(names[0]) as fh:
                yield from fh
    except (zipfile.BadZipFile, zlib.error, EOFError) as e:
        raise SourceError(f"o arquivo {zip_path.name} está corrompido ou incompleto; baixe-o novamente.") from e
    except OSError as e:
        raise SourceError(f"não foi possível ler {zip_path.name}: {e.strerror or e}.") from e


def _parse(line: bytes) -> list[str]:
    try:
        return next(csv.reader([line.decode(ENCODING, errors="replace")], delimiter=";", quotechar='"'), [])
    except csv.Error:
        return []   # linha malformada: ignorada, não derruba a pesquisa


def format_phone(ddd: str, tel: str) -> str | None:
    ddd, tel = re.sub(r"\D", "", ddd), re.sub(r"\D", "", tel)
    if not tel:
        return None
    local = f"{tel[:-4]}-{tel[-4:]}" if len(tel) > 4 else tel
    return f"({ddd}) {local}" if ddd else local


def clean_company_name(name: str) -> str:
    """Remove o CPF que a Receita acrescenta à razão social de MEI (dado pessoal desnecessário)."""
    return re.sub(r"\s+\d{11}$", "", name.strip())


class ReceitaSource:
    name = "receita_cnpj"
    label = "Receita Federal (CNPJ)"

    def __init__(self, data_dir: str | Path | None):
        self.data_dir = Path(data_dir) if data_dir else None

    @staticmethod
    def missing_files(data_dir: str | Path | None) -> list[str]:
        if not data_dir or not Path(data_dir).is_dir():
            return ["pasta com os arquivos da Receita (configure em Configurações)"]
        d, missing = Path(data_dir), []
        if not _find(d, "Municipios*.zip"):
            missing.append("Municipios.zip")
        if not _find(d, "Estabelecimentos*.zip"):
            missing.append("Estabelecimentos0.zip … Estabelecimentos9.zip")
        return missing

    def search(self, query: SearchQuery, progress: Progress, cancelled: Cancelled) -> Iterator[CompanyData]:
        missing = self.missing_files(self.data_dir)
        if missing:
            raise SourceUnavailable("arquivos ausentes: " + "; ".join(missing))
        if not query.category.cnaes:
            raise SourceError("esta categoria não tem CNAE associado.")
        folder = self.data_dir
        city_key = normalize(query.city)
        codes: set[str] = set()
        for line in _raw_lines(_find(folder, "Municipios*.zip")[0]):
            row = _parse(line)
            if len(row) >= 2 and normalize(row[1]) == city_key:
                codes.add(row[0])
        if not codes:
            raise SourceError(f"município '{query.city}' não encontrado em Municipios.zip.")
        markers = [f';"{c}";'.encode() for c in codes]
        cnaes = set(query.category.cnaes)
        files = _find(folder, "Estabelecimentos*.zip")
        rows: list[list[str]] = []
        stop = False
        for i, f in enumerate(files):
            if stop:
                break
            progress(int(100 * i / len(files)), f"Receita: lendo {f.name} ({i + 1}/{len(files)}) — {len(rows)} encontradas")
            for n, line in enumerate(_raw_lines(f)):
                if n % 100_000 == 0 and cancelled():
                    stop = True
                    break
                if not any(m in line for m in markers):   # filtro rápido antes de interpretar o CSV
                    continue
                row = _parse(line)
                if (len(row) >= MIN_COLS and row[C_SITUACAO] == ATIVA and row[C_CNAE] in cnaes
                        and row[C_MUN] in codes and (not query.state or row[C_UF] == query.state)):
                    rows.append(row)
        names = {} if stop else self._legal_names(folder, rows, progress, cancelled)
        for r in rows:
            basico = r[C_BASICO]
            name = r[C_FANTASIA].strip() or clean_company_name(names.get(basico, ""))
            cnpj = basico + r[C_ORDEM] + r[C_DV]
            street = " ".join(x for x in (r[C_TIPO].strip(), r[C_LOGR].strip()) if x)
            parts = [f"{street}, {r[C_NUM].strip()}".strip(", "), r[C_COMPL].strip(), r[C_BAIRRO].strip(),
                     f"CEP {r[C_CEP]}" if r[C_CEP].strip() else ""]
            yield CompanyData(
                source=self.name, source_id=cnpj,
                name=name or f"(sem nome cadastrado) CNPJ {cnpj}",
                category=query.category.name, address=" - ".join(p for p in parts if p) or None,
                city=query.city, state=r[C_UF] or query.state, phone=format_phone(r[C_DDD], r[C_TEL]))

    @staticmethod
    def _legal_names(folder: Path, rows, progress: Progress, cancelled: Cancelled) -> dict[str, str]:
        wanted = {r[C_BASICO] for r in rows if not r[C_FANTASIA].strip()}
        files = _find(folder, "Empresas*.zip")
        if not wanted or not files:
            return {}
        wanted_b = {w.encode() for w in wanted}
        found: dict[str, str] = {}
        for i, f in enumerate(files):
            progress(None, f"Receita: buscando razão social ({i + 1}/{len(files)})")
            for n, line in enumerate(_raw_lines(f)):
                if n % 100_000 == 0 and cancelled():
                    return found
                if line[:1] == b'"' and line[1:9] in wanted_b:
                    row = _parse(line)
                    if len(row) < 2:
                        continue
                    found[row[0]] = row[1]
                    if len(found) == len(wanted):
                        return found
        return found
