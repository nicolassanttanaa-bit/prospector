"""Autoteste: `Prospector.exe --self-test`. Confere, no programa já empacotado, que banco, exportações,
HTTPS (certificados), ícone e janela principal funcionam. Não toca nos seus dados (usa uma pasta temporária)."""
from __future__ import annotations

import platform
import sys
import tempfile
import traceback
from pathlib import Path

from prospector import __version__


def run_self_test(report_path: Path | None = None) -> int:
    report = Path(report_path) if report_path else Path(tempfile.gettempdir()) / "prospector-selftest.txt"
    lines = [f"Prospector {__version__} — autoteste",
             f"Python {platform.python_version()} em {platform.system()} | empacotado: {bool(getattr(sys, 'frozen', False))}"]
    ok = True

    def step(name: str, fn) -> None:
        nonlocal ok
        try:
            fn()
            lines.append(f"OK      {name}")
        except Exception as e:  # noqa: BLE001
            ok = False
            lines.append(f"FALHOU  {name}: {type(e).__name__}: {e}")
            lines.append(traceback.format_exc())

    with tempfile.TemporaryDirectory() as tmp_name:
        tmp = Path(tmp_name)
        state: dict = {}

        def database() -> None:
            from prospector.database.db import connect
            from prospector.database.repository import CompanyRepository
            from prospector.models.company import CompanyData
            state["conn"] = connect(tmp / "selftest.db")
            state["repo"] = CompanyRepository(state["conn"])
            state["repo"].upsert(CompanyData(source="autoteste", source_id="1", name="Registro de autoteste"))
            assert state["repo"].stats()["total"] == 1

        def exports() -> None:
            from openpyxl import load_workbook
            from prospector.exports.exporter import export_companies
            rows = state["repo"].search()
            for fmt, name in (("xlsx", "t.xlsx"), ("csv_semicolon", "t.csv"), ("json", "t.json")):
                export_companies(state["repo"], rows, tmp / name, fmt)
                assert (tmp / name).stat().st_size > 0, name
            assert load_workbook(tmp / "t.xlsx").sheetnames[0] == "Empresas"

        def https() -> None:
            import certifi
            import httpx
            httpx.Client().close()               # carrega o pacote de certificados HTTPS
            assert Path(certifi.where()).exists(), "pacote de certificados ausente"
            from prospector.integrations.site_checker import SiteChecker
            SiteChecker().close()

        def window() -> None:
            from PySide6.QtCore import QCoreApplication, QEvent
            from PySide6.QtGui import QIcon
            from PySide6.QtWidgets import QApplication
            from prospector.config.prefs import Prefs
            from prospector.config.settings import Settings
            from prospector.interface.main_window import MainWindow
            from prospector.resources import asset
            assert asset("icon.png").exists(), "ícone ausente"
            app = QApplication.instance() or QApplication(sys.argv[:1])
            assert not QIcon(str(asset("icon.png"))).isNull(), "ícone ilegível"
            win = MainWindow(state["repo"], Settings(data_dir=tmp), Prefs())
            win.show()
            app.processEvents()
            assert win.close()
            win.deleteLater()
            QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)

        step("banco de dados (SQLite)", database)
        if "repo" in state:
            step("exportação Excel, CSV e JSON", exports)
        step("HTTPS e certificados", https)
        if "repo" in state:
            step("janela principal e ícone", window)
        if "conn" in state:
            state["conn"].close()           # no Windows, o arquivo só pode ser apagado depois de fechado

    lines.append("RESULTADO: " + ("tudo certo." if ok else "HÁ FALHAS (veja acima)."))
    text = "\n".join(lines)
    try:
        report.write_text(text, encoding="utf-8")
    except OSError:
        pass
    print(text)
    return 0 if ok else 1
